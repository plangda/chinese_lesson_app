/**
 * HanPath - Core Application Engine (4-Stage Layout)
 */

const state = {
  userLevel: null,
  completedLessons: [],
  streakCount: 0,
  score: 0,
  timeSpentMinutes: 0,
  
  currentView: "welcome-view",
  currentLesson: null,
  currentPane: "vocab-pane",
  
  timerSeconds: 3600,
  timerInterval: null,
  
  vocabIndex: 0,
  
  quizIndex: 0,
  quizScore: 0,
  quizAnswers: [],
};

const timelineStages = ["vocab-pane", "grammar-pane", "dialogue-pane", "quiz-pane"];

// Speech Synthesis setup
let speechVoice = null;
function loadSpeechVoices() {
  if (typeof speechSynthesis === 'undefined') return;
  const voices = speechSynthesis.getVoices();
  speechVoice = voices.find(v => v.lang.includes('zh-CN') || v.lang.includes('zh-')) || null;
}
if (typeof speechSynthesis !== 'undefined') {
  if (speechSynthesis.onvoiceschanged !== undefined) {
    speechSynthesis.onvoiceschanged = loadSpeechVoices;
  }
  loadSpeechVoices();
}

function speakText(text) {
  if (typeof speechSynthesis === 'undefined') return;
  speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'zh-CN';
  utterance.rate = 0.85;
  if (speechVoice) utterance.voice = speechVoice;
  speechSynthesis.speak(utterance);
}

// HanziWriter instance
let writer = null;

document.addEventListener("DOMContentLoaded", () => {
  loadProgress();
  setupEventListeners();
  if (state.userLevel) {
    switchView("dashboard-view");
  } else {
    switchView("welcome-view");
  }
});

function loadProgress() {
  const saved = localStorage.getItem("hanpath_data_v2");
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      state.userLevel = parsed.userLevel;
      state.completedLessons = parsed.completedLessons || [];
      state.streakCount = parsed.streakCount || 0;
      state.score = parsed.score || 0;
      state.timeSpentMinutes = parsed.timeSpentMinutes || 0;
    } catch (e) {
      console.error(e);
    }
  }
}

function saveProgress() {
  localStorage.setItem("hanpath_data_v2", JSON.stringify({
    userLevel: state.userLevel,
    completedLessons: state.completedLessons,
    streakCount: state.streakCount,
    score: state.score,
    timeSpentMinutes: state.timeSpentMinutes
  }));
}

function switchView(viewId) {
  document.querySelectorAll('.view-section').forEach(el => el.classList.remove('active'));
  document.getElementById(viewId).classList.add('active');
  state.currentView = viewId;
  
  if (viewId === "dashboard-view") {
    renderDashboard();
  }
}

function setupEventListeners() {
  // Welcome & Level Select
  document.querySelectorAll('.manual-level-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      state.userLevel = e.target.getAttribute('data-level');
      saveProgress();
      switchView("dashboard-view");
    });
  });
  
  document.getElementById('change-level-select').addEventListener('change', (e) => {
    state.userLevel = e.target.value;
    saveProgress();
    renderDashboard();
  });
  
  document.getElementById('reset-progress-btn').addEventListener('click', () => {
    if (confirm("Reset all progress?")) {
      state.userLevel = null;
      state.completedLessons = [];
      state.score = 0;
      state.timeSpentMinutes = 0;
      saveProgress();
      switchView("welcome-view");
    }
  });

  // Lesson Nav
  document.getElementById('lesson-exit-btn').addEventListener('click', () => {
    if (confirm("Exit lesson? Progress will be lost.")) {
      clearInterval(state.timerInterval);
      switchView("dashboard-view");
    }
  });
  
  document.getElementById('pane-next-btn').addEventListener('click', () => {
    const idx = timelineStages.indexOf(state.currentPane);
    if (idx < timelineStages.length - 1) {
      switchPane(timelineStages[idx + 1]);
    }
  });
  document.getElementById('pane-back-btn').addEventListener('click', () => {
    const idx = timelineStages.indexOf(state.currentPane);
    if (idx > 0) {
      switchPane(timelineStages[idx - 1]);
    }
  });

  // Vocab Flashcards & Audio
  document.getElementById('vocab-flashcard').addEventListener('click', () => {
    document.getElementById('vocab-flashcard').classList.toggle('flipped');
  });
  document.getElementById('vocab-speak-btn').addEventListener('click', () => {
    const v = state.currentLesson.vocab[state.vocabIndex];
    if (v) speakText(v.character);
  });
  document.getElementById('vocab-ex-speak-btn').addEventListener('click', () => {
    const v = state.currentLesson.vocab[state.vocabIndex];
    if (v) speakText(v.exampleCn);
  });
  document.getElementById('vocab-next-btn').addEventListener('click', () => {
    if (state.vocabIndex < state.currentLesson.vocab.length - 1) {
      state.vocabIndex++;
      renderVocabPane();
    }
  });
  document.getElementById('vocab-prev-btn').addEventListener('click', () => {
    if (state.vocabIndex > 0) {
      state.vocabIndex--;
      renderVocabPane();
    }
  });
  
  // Writing Pad Controls
  document.getElementById('btn-writing-play').addEventListener('click', () => {
    if (writer) writer.animateCharacter();
  });
  document.getElementById('btn-writing-reset').addEventListener('click', () => {
    if (writer) {
      const char = state.currentLesson.vocab[state.vocabIndex].character;
      writer.setCharacter(char.charAt(0)); 
    }
  });
  document.getElementById('mode-animate-btn').addEventListener('click', (e) => {
    document.querySelectorAll('.btn-mode').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    document.getElementById('free-write-canvas').style.display = 'none';
    if(writer) { writer.cancelQuiz(); writer.animateCharacter(); }
  });
  document.getElementById('mode-trace-btn').addEventListener('click', (e) => {
    document.querySelectorAll('.btn-mode').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    document.getElementById('free-write-canvas').style.display = 'none';
    if(writer) writer.quiz({showHintAfterMisses: 1});
  });
  document.getElementById('mode-freewrite-btn').addEventListener('click', (e) => {
    document.querySelectorAll('.btn-mode').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    document.getElementById('free-write-canvas').style.display = 'block';
    if(writer) writer.cancelQuiz();
    initFreeWriteCanvas();
  });
  
  let isDrawing = false;
  let ctx = null;
  function initFreeWriteCanvas() {
    const canvas = document.getElementById('free-write-canvas');
    if(!ctx) {
      ctx = canvas.getContext('2d');
      ctx.lineWidth = 6;
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#ff3366';
      
      canvas.addEventListener('mousedown', startDraw);
      canvas.addEventListener('mousemove', draw);
      canvas.addEventListener('mouseup', endDraw);
      canvas.addEventListener('mouseout', endDraw);
      
      document.getElementById('btn-writing-clear').addEventListener('click', () => {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
      });
    }
    document.getElementById('btn-writing-clear').style.display = 'inline-block';
  }
  
  function startDraw(e) { isDrawing = true; draw(e); }
  function draw(e) {
    if(!isDrawing || !ctx) return;
    const rect = e.target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  }
  function endDraw() { isDrawing = false; if(ctx) ctx.beginPath(); }
  
  // Dialogue Audio & Toggles
  document.getElementById('dialogue-play-all-btn').addEventListener('click', () => {
    let fullText = state.currentLesson.dialogue.lines.map(l => l.cn).join(" ");
    speakText(fullText);
  });
  document.getElementById('pinyin-visibility-toggle').addEventListener('click', () => {
    const pyElements = document.querySelectorAll('.dialogue-py-text');
    pyElements.forEach(el => {
      el.style.display = (el.style.display === 'none') ? 'block' : 'none';
    });
  });

  // Quiz Navigation
  document.getElementById('lesson-quiz-next-btn').addEventListener('click', nextQuizQuestion);
  document.getElementById('finish-to-dashboard-btn').addEventListener('click', () => {
    switchView("dashboard-view");
  });
}

function renderDashboard() {
  document.getElementById('dashboard-level-badge').textContent = state.userLevel.toUpperCase();
  document.getElementById('change-level-select').value = state.userLevel;
  
  document.getElementById('stat-lessons-completed').textContent = state.completedLessons.length;
  document.getElementById('stat-time-spent').textContent = Math.round(state.timeSpentMinutes / 60) + "h";
  document.getElementById('score-val').textContent = state.score;
  
  const container = document.getElementById('dashboard-lessons-container');
  container.innerHTML = '';
  
  const lessons = CHINESE_LESSONS.lessons[state.userLevel] || [];
  
  lessons.forEach(l => {
    const isCompleted = state.completedLessons.includes(l.id);
    const div = document.createElement('div');
    div.className = `lesson-row ${isCompleted ? 'completed' : ''}`;
    div.innerHTML = `
      <div class="lesson-info">
        <h4 style="margin-bottom: 0.25rem;">${l.title}</h4>
        <div style="font-size: 0.85rem; color: var(--text-muted);">
          4 Stages • 60 Minutes
        </div>
      </div>
      <div>
        ${isCompleted ? 
          `<span style="color: var(--success); font-weight: bold;">✔ Done</span>` : 
          `<button class="btn btn-primary btn-sm start-lesson-btn" data-id="${l.id}">Start Lesson</button>`
        }
      </div>
    `;
    container.appendChild(div);
  });
  
  document.querySelectorAll('.start-lesson-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.target.getAttribute('data-id');
      startLesson(id);
    });
  });
}

function startLesson(id) {
  const lessons = CHINESE_LESSONS.lessons[state.userLevel];
  state.currentLesson = lessons.find(l => l.id === id);
  
  document.getElementById('lesson-level-badge').textContent = state.userLevel.toUpperCase();
  document.getElementById('lesson-title-display').textContent = state.currentLesson.title;
  
  state.timerSeconds = 3600;
  clearInterval(state.timerInterval);
  state.timerInterval = setInterval(() => {
    state.timerSeconds--;
    if(state.timerSeconds <= 0) clearInterval(state.timerInterval);
    const m = Math.floor(state.timerSeconds / 60);
    const s = state.timerSeconds % 60;
    document.getElementById('lesson-timer-display').textContent = `${m}:${s < 10 ? '0'+s : s}`;
  }, 1000);
  
  state.vocabIndex = 0;
  switchPane("vocab-pane");
  switchView("lesson-view");
}

function switchPane(paneId) {
  state.currentPane = paneId;
  document.querySelectorAll('.lesson-pane-content').forEach(el => el.style.display = 'none');
  document.getElementById(paneId).style.display = 'block';
  
  document.querySelectorAll('.timeline-step').forEach(el => el.classList.remove('active'));
  const stepEl = document.querySelector(`.timeline-step[data-pane="${paneId}"]`);
  if(stepEl) stepEl.classList.add('active');
  
  const idx = timelineStages.indexOf(paneId);
  document.getElementById('pane-back-btn').style.visibility = idx === 0 ? 'hidden' : 'visible';
  document.getElementById('pane-next-btn').style.display = idx === timelineStages.length - 1 ? 'none' : 'block';
  
  if (paneId === "vocab-pane") renderVocabPane();
  if (paneId === "grammar-pane") renderGrammarPane();
  if (paneId === "dialogue-pane") renderDialoguePane();
  if (paneId === "quiz-pane") renderQuizPane();
}

function renderVocabPane() {
  const v = state.currentLesson.vocab[state.vocabIndex];
  document.getElementById('vocab-char').textContent = v.character;
  document.getElementById('vocab-meaning').textContent = v.meaning;
  document.getElementById('vocab-pinyin').textContent = v.pinyin;
  
  document.getElementById('vocab-detail-pinyin').textContent = v.pinyin;
  document.getElementById('vocab-ex-cn').textContent = v.exampleCn;
  document.getElementById('vocab-ex-py').textContent = v.examplePy;
  document.getElementById('vocab-ex-en').textContent = v.exampleEn;
  document.getElementById('vocab-deconstruct-text').textContent = v.deconstruct || "Basic radical combination.";
  
  document.getElementById('vocab-flashcard').classList.remove('flipped');
  document.getElementById('vocab-index-indicator').textContent = `Word ${state.vocabIndex + 1} of ${state.currentLesson.vocab.length}`;
  
  // HanziWriter init
  if (typeof HanziWriter !== "undefined") {
    document.getElementById('hanzi-writer-target').innerHTML = '';
    writer = HanziWriter.create('hanzi-writer-target', v.character.charAt(0), {
      width: 200,
      height: 200,
      padding: 15,
      strokeColor: '#ff3366',
      radicalColor: '#00f5d4',
      delayBetweenStrokes: 150
    });
  }
}

function renderGrammarPane() {
  const container = document.getElementById('grammar-topics-container');
  container.innerHTML = '';
  
  state.currentLesson.grammar.forEach((g, idx) => {
    const div = document.createElement('div');
    div.className = 'glass-panel';
    div.style.padding = '1.5rem';
    div.style.marginBottom = '1.5rem';
    
    let html = `<h4 style="color: var(--accent); margin-bottom: 0.5rem; font-size: 1.1rem;">${g.title}</h4>`;
    html += `<p style="margin-bottom: 1rem;">${g.explanation}</p>`;
    
    g.examples.forEach(ex => {
      html += `<div class="example-box" style="margin-bottom: 0.5rem;">
        <div class="example-cn">${ex.cn}</div>
        <div class="example-py">${ex.py}</div>
        <div class="example-en">${ex.en}</div>
      </div>`;
    });
    
    if (g.practice && g.practice.prompt) {
       const pId = `grammar-prac-${idx}`;
       let wordsHtml = '';
       if(g.practice.words && g.practice.words.length > 0) {
         wordsHtml = `
           <div class="grammar-practice-area" id="${pId}-area">
             <div class="grammar-answer-box" id="${pId}-answer-box" style="min-height: 40px; padding: 0.5rem; margin: 0.5rem 0; border: 2px dashed var(--border-color); border-radius: 8px; display: flex; gap: 0.5rem; flex-wrap: wrap;"></div>
             <div class="grammar-word-bank" id="${pId}-word-bank" style="display: flex; gap: 0.5rem; flex-wrap: wrap; margin-bottom: 0.5rem;">
               ${g.practice.words.map((w, wIdx) => `<button class="btn btn-secondary btn-sm prac-word-btn" data-word="${w}">${w}</button>`).join('')}
             </div>
             <button class="btn btn-primary btn-sm check-prac-btn" data-pid="${pId}" data-answer='${JSON.stringify(g.practice.answer)}'>Check Answer</button>
             <span class="prac-feedback" id="${pId}-feedback" style="margin-left: 1rem; font-weight: bold;"></span>
           </div>
         `;
       }
       
       html += `
         <div style="margin-top: 1rem; padding: 1rem; background: rgba(0,245,212,0.05); border: 1px solid rgba(0,245,212,0.2); border-radius: 8px;">
           <strong style="color: var(--primary);">📝 ${g.practice.prompt}</strong>
           ${wordsHtml}
           <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.5rem;">Tap the words to build the correct sentence.</p>
         </div>
       `;
    }
    
    div.innerHTML = html;
    container.appendChild(div);
  });
  
  // Attach event listeners for practice areas
  document.querySelectorAll('.prac-word-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const b = e.target;
      const bank = b.closest('.grammar-practice-area').querySelector('.grammar-word-bank');
      const ansBox = b.closest('.grammar-practice-area').querySelector('.grammar-answer-box');
      if (b.parentElement === bank) {
        ansBox.appendChild(b);
      } else {
        bank.appendChild(b);
      }
    });
  });
  
  document.querySelectorAll('.check-prac-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const pId = e.target.getAttribute('data-pid');
      const ansArr = JSON.parse(e.target.getAttribute('data-answer'));
      const ansBox = document.getElementById(`${pId}-answer-box`);
      const feedback = document.getElementById(`${pId}-feedback`);
      
      const userArr = Array.from(ansBox.children).map(b => b.getAttribute('data-word'));
      
      if (userArr.join('') === ansArr.join('')) {
        feedback.textContent = '✅ Correct!';
        feedback.style.color = 'var(--success)';
      } else {
        feedback.textContent = '❌ Try again!';
        feedback.style.color = 'var(--danger)';
      }
    });
  });
}

function renderDialoguePane() {
  document.getElementById('dialogue-title-lbl').textContent = state.currentLesson.dialogue.title;
  const container = document.getElementById('dialogue-bubbles-container');
  container.innerHTML = '';
  
  state.currentLesson.dialogue.lines.forEach((l, idx) => {
    const isRight = idx % 2 !== 0;
    const alignClass = isRight ? "right" : "left";
    
    const div = document.createElement('div');
    div.style.display = 'flex';
    div.style.flexDirection = 'column';
    div.style.alignItems = isRight ? 'flex-end' : 'flex-start';
    div.style.marginBottom = '1.5rem';
    
    div.innerHTML = `
      <div style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 0.25rem; padding: 0 0.5rem;">${l.speaker}</div>
      <div class="glass-panel" style="padding: 1rem 1.5rem; max-width: 80%; border-color: ${isRight ? 'rgba(0, 245, 212, 0.3)' : 'var(--glass-border)'}; border-bottom-${isRight ? 'right' : 'left'}-radius: 4px;">
        <div style="font-size: 1.4rem; font-weight: 500; margin-bottom: 0.5rem;">${l.cn}</div>
        <div class="dialogue-py-text" style="color: var(--primary); font-size: 0.95rem; margin-bottom: 0.25rem;">${l.py}</div>
        <div style="color: var(--text-secondary); font-size: 0.9rem;">${l.en}</div>
      </div>
    `;
    container.appendChild(div);
  });
}

function renderQuizPane() {
  state.quizIndex = 0;
  state.quizScore = 0;
  state.quizAnswers = [];
  renderQuizQuestion();
}

function renderQuizQuestion() {
  const q = state.currentLesson.quiz[state.quizIndex];
  document.getElementById('lesson-quiz-question-lbl').innerHTML = `<span>Question ${state.quizIndex + 1} of ${state.currentLesson.quiz.length}</span>`;
  document.getElementById('lesson-quiz-text').textContent = q.question;
  
  const opts = document.getElementById('lesson-quiz-options');
  opts.innerHTML = '';
  document.getElementById('lesson-quiz-explanation-box').style.display = 'none';
  document.getElementById('lesson-quiz-next-btn').style.display = 'none';
  
  // Progress bar
  const pct = (state.quizIndex / state.currentLesson.quiz.length) * 100;
  document.getElementById('lesson-quiz-progress-fill').style.width = `${pct}%`;
  
  q.options.forEach(opt => {
    const btn = document.createElement('button');
    btn.className = 'btn btn-secondary';
    btn.style.width = '100%';
    btn.style.textAlign = 'left';
    btn.textContent = opt;
    btn.onclick = () => handleQuizAnswer(opt, btn);
    opts.appendChild(btn);
  });
}

function handleQuizAnswer(selectedOpt, btnEl) {
  const q = state.currentLesson.quiz[state.quizIndex];
  const isCorrect = selectedOpt === q.answer;
  
  const opts = document.getElementById('lesson-quiz-options').querySelectorAll('button');
  opts.forEach(b => {
    b.disabled = true;
    if (b.textContent === q.answer) b.style.borderColor = "var(--success)";
  });
  
  if (isCorrect) {
    btnEl.style.background = "rgba(0, 245, 212, 0.1)";
    state.quizScore++;
    document.getElementById('lesson-quiz-correctness').textContent = "Correct!";
    document.getElementById('lesson-quiz-correctness').style.color = "var(--success)";
  } else {
    btnEl.style.background = "rgba(255, 77, 109, 0.1)";
    btnEl.style.borderColor = "var(--error)";
    document.getElementById('lesson-quiz-correctness').textContent = "Incorrect";
    document.getElementById('lesson-quiz-correctness').style.color = "var(--error)";
  }
  
  document.getElementById('lesson-quiz-explanation-text').textContent = q.explanation;
  document.getElementById('lesson-quiz-explanation-box').style.display = 'block';
  
  const nextBtn = document.getElementById('lesson-quiz-next-btn');
  nextBtn.style.display = 'inline-block';
  if (state.quizIndex === state.currentLesson.quiz.length - 1) {
    nextBtn.textContent = "Finish Lesson ➔";
  } else {
    nextBtn.textContent = "Next Question ➔";
  }
}

function nextQuizQuestion() {
  if (state.quizIndex < state.currentLesson.quiz.length - 1) {
    state.quizIndex++;
    renderQuizQuestion();
  } else {
    finishLesson();
  }
}

function finishLesson() {
  clearInterval(state.timerInterval);
  const timeSpent = 3600 - state.timerSeconds;
  state.timeSpentMinutes += Math.round(timeSpent / 60);
  
  if (!state.completedLessons.includes(state.currentLesson.id)) {
    state.completedLessons.push(state.currentLesson.id);
    state.score += (state.quizScore * 10);
  }
  
  saveProgress();
  
  document.getElementById('congrats-quiz-score').textContent = `${state.quizScore} / ${state.currentLesson.quiz.length}`;
  document.getElementById('congrats-time').textContent = `${Math.floor(timeSpent/60)}m ${timeSpent%60}s`;
  
  switchView('congrats-view');
}
