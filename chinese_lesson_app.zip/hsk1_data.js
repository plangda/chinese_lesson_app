window.HSK1_CURRICULUM = [
  {
    "id": "hsk1_day1",
    "title": "Day 1: Vocabulary Range 1-17",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 1",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是爱吗？",
          "py": "Nǐ hǎo! Zhè shì ài ma?",
          "en": "Hello! Is this 爱?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是八。",
          "py": "Bú shì, zhè shì bā.",
          "en": "No, this is 八."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道爱在哪里吗？",
          "py": "Xièxie, nǐ zhīdào ài zài nǎlǐ ma?",
          "en": "Thank you, do you know where 爱 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢八吗？",
          "py": "Hǎo de. Nǐ xǐhuān bā ma?",
          "en": "Okay. Do you like 八?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"爱\"?",
        "options": [
          "restaurant",
          "very",
          "to love",
          "eight"
        ],
        "answer": "to love",
        "explanation": "\"爱\" (ài) means \"to love\"."
      },
      {
        "question": "What is the pinyin for \"八\" (eight)?",
        "options": [
          "bā",
          "duìbuqǐ",
          "dà",
          "dǎ diànhuà"
        ],
        "answer": "bā",
        "explanation": "The pinyin for \"八\" is bā."
      },
      {
        "question": "Select the character for \"father\":",
        "options": [
          "爸爸",
          "喝",
          "号",
          "电视"
        ],
        "answer": "爸爸",
        "explanation": "\"爸爸\" means father."
      },
      {
        "question": "What is the meaning of \"杯子\"?",
        "options": [
          "good",
          "how many",
          "cup",
          "possessive particle"
        ],
        "answer": "cup",
        "explanation": "\"杯子\" (bēizi) means \"cup\"."
      },
      {
        "question": "What is the pinyin for \"北京\" (Beijing)?",
        "options": [
          "Běijīng",
          "diànnǎo",
          "jīntiān",
          "diànyǐng"
        ],
        "answer": "Běijīng",
        "explanation": "The pinyin for \"北京\" is Běijīng."
      },
      {
        "question": "Select the character for \"measure word for books\":",
        "options": [
          "都",
          "本",
          "杯子",
          "东西"
        ],
        "answer": "本",
        "explanation": "\"本\" means measure word for books."
      },
      {
        "question": "What is the meaning of \"不客气\"?",
        "options": [
          "very",
          "you're welcome",
          "tea",
          "not"
        ],
        "answer": "you're welcome",
        "explanation": "\"不客气\" (bú kèqi) means \"you're welcome\"."
      },
      {
        "question": "What is the pinyin for \"不\" (not)?",
        "options": [
          "hào",
          "jīntiān",
          "jǐ",
          "bù"
        ],
        "answer": "bù",
        "explanation": "The pinyin for \"不\" is bù."
      },
      {
        "question": "Select the character for \"dish/vegetable\":",
        "options": [
          "电影",
          "菜",
          "会",
          "对不起"
        ],
        "answer": "菜",
        "explanation": "\"菜\" means dish/vegetable."
      },
      {
        "question": "What is the meaning of \"茶\"?",
        "options": [
          "son",
          "tea",
          "cup",
          "sorry"
        ],
        "answer": "tea",
        "explanation": "\"茶\" (chá) means \"tea\"."
      },
      {
        "question": "What is the pinyin for \"吃\" (to eat)?",
        "options": [
          "de",
          "chī",
          "dú",
          "ài"
        ],
        "answer": "chī",
        "explanation": "The pinyin for \"吃\" is chī."
      },
      {
        "question": "Select the character for \"taxi\":",
        "options": [
          "北京",
          "工作",
          "多",
          "出租车"
        ],
        "answer": "出租车",
        "explanation": "\"出租车\" means taxi."
      },
      {
        "question": "What is the meaning of \"打电话\"?",
        "options": [
          "nine",
          "two",
          "to make a phone call",
          "how many"
        ],
        "answer": "to make a phone call",
        "explanation": "\"打电话\" (dǎ diànhuà) means \"to make a phone call\"."
      },
      {
        "question": "What is the pinyin for \"大\" (big)?",
        "options": [
          "chūzūchē",
          "gāoxìng",
          "dà",
          "dōu"
        ],
        "answer": "dà",
        "explanation": "The pinyin for \"大\" is dà."
      },
      {
        "question": "Select the character for \"possessive particle\":",
        "options": [
          "东西",
          "对不起",
          "读",
          "的"
        ],
        "answer": "的",
        "explanation": "\"的\" means possessive particle."
      },
      {
        "question": "What is the meaning of \"点\"?",
        "options": [
          "o'clock / point",
          "television",
          "two",
          "restaurant"
        ],
        "answer": "o'clock / point",
        "explanation": "\"点\" (diǎn) means \"o'clock / point\"."
      },
      {
        "question": "What is the pinyin for \"电脑\" (computer)?",
        "options": [
          "diànnǎo",
          "bēizi",
          "diànyǐng",
          "gè"
        ],
        "answer": "diànnǎo",
        "explanation": "The pinyin for \"电脑\" is diànnǎo."
      },
      {
        "question": "Select the character for \"to love\":",
        "options": [
          "爱",
          "分钟",
          "回",
          "东西"
        ],
        "answer": "爱",
        "explanation": "\"爱\" means to love."
      },
      {
        "question": "Grammar Check: Question Particle 吗 (ma). Which sentence is grammatically correct based on 'Add 吗 at the end of a statement to make it a yes/no question.'?",
        "options": [
          "我茶喝。",
          "你好吗？",
          "吗你好？",
          "不我好。"
        ],
        "answer": "你好吗？",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question. Example: 你好吗？ (Nǐ hǎo ma?)"
      },
      {
        "question": "Translate this grammar example to English: 你好吗？",
        "options": [
          "Are you good?",
          "Where are you?",
          "This is a book.",
          "I don't know."
        ],
        "answer": "Are you good?",
        "explanation": "你好吗？ means Are you good?."
      }
    ]
  },
  {
    "id": "hsk1_day2",
    "title": "Day 2: Vocabulary Range 18-34",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 2",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是电视吗？",
          "py": "Nǐ hǎo! Zhè shì diànshì ma?",
          "en": "Hello! Is this 电视?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是电影。",
          "py": "Bú shì, zhè shì diànyǐng.",
          "en": "No, this is 电影."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道电视在哪里吗？",
          "py": "Xièxie, nǐ zhīdào diànshì zài nǎlǐ ma?",
          "en": "Thank you, do you know where 电视 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢电影吗？",
          "py": "Hǎo de. Nǐ xǐhuān diànyǐng ma?",
          "en": "Okay. Do you like 电影?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"电视\"?",
        "options": [
          "to open/drive",
          "can/will",
          "television",
          "restaurant"
        ],
        "answer": "television",
        "explanation": "\"电视\" (diànshì) means \"television\"."
      },
      {
        "question": "What is the pinyin for \"电影\" (movie)?",
        "options": [
          "huì",
          "diànyǐng",
          "bú kèqi",
          "Běijīng"
        ],
        "answer": "diànyǐng",
        "explanation": "The pinyin for \"电影\" is diànyǐng."
      },
      {
        "question": "Select the character for \"thing\":",
        "options": [
          "叫",
          "东西",
          "的",
          "号"
        ],
        "answer": "东西",
        "explanation": "\"东西\" means thing."
      },
      {
        "question": "What is the meaning of \"都\"?",
        "options": [
          "all/both",
          "television",
          "taxi",
          "tea"
        ],
        "answer": "all/both",
        "explanation": "\"都\" (dōu) means \"all/both\"."
      },
      {
        "question": "What is the pinyin for \"读\" (to read)?",
        "options": [
          "cài",
          "duōshao",
          "dú",
          "èr"
        ],
        "answer": "dú",
        "explanation": "The pinyin for \"读\" is dú."
      },
      {
        "question": "Select the character for \"sorry\":",
        "options": [
          "回",
          "飞机",
          "对不起",
          "九"
        ],
        "answer": "对不起",
        "explanation": "\"对不起\" means sorry."
      },
      {
        "question": "What is the meaning of \"多\"?",
        "options": [
          "many/much",
          "eight",
          "possessive particle",
          "to make a phone call"
        ],
        "answer": "many/much",
        "explanation": "\"多\" (duō) means \"many/much\"."
      },
      {
        "question": "What is the pinyin for \"多少\" (how much/many)?",
        "options": [
          "gōngzuò",
          "diànshì",
          "cài",
          "duōshao"
        ],
        "answer": "duōshao",
        "explanation": "The pinyin for \"多少\" is duōshao."
      },
      {
        "question": "Select the character for \"son\":",
        "options": [
          "爸爸",
          "家",
          "儿子",
          "回"
        ],
        "answer": "儿子",
        "explanation": "\"儿子\" means son."
      },
      {
        "question": "What is the meaning of \"二\"?",
        "options": [
          "two",
          "tea",
          "Chinese language",
          "thing"
        ],
        "answer": "two",
        "explanation": "\"二\" (èr) means \"two\"."
      },
      {
        "question": "What is the pinyin for \"饭店\" (restaurant)?",
        "options": [
          "fàndiàn",
          "Běijīng",
          "de",
          "chá"
        ],
        "answer": "fàndiàn",
        "explanation": "The pinyin for \"饭店\" is fàndiàn."
      },
      {
        "question": "Select the character for \"airplane\":",
        "options": [
          "飞机",
          "本",
          "开",
          "家"
        ],
        "answer": "飞机",
        "explanation": "\"飞机\" means airplane."
      },
      {
        "question": "What is the meaning of \"分钟\"?",
        "options": [
          "to be called",
          "minute",
          "how many",
          "many/much"
        ],
        "answer": "minute",
        "explanation": "\"分钟\" (fēnzhōng) means \"minute\"."
      },
      {
        "question": "What is the pinyin for \"高兴\" (happy)?",
        "options": [
          "diǎn",
          "huì",
          "gāoxìng",
          "dǎ diànhuà"
        ],
        "answer": "gāoxìng",
        "explanation": "The pinyin for \"高兴\" is gāoxìng."
      },
      {
        "question": "Select the character for \"measure word\":",
        "options": [
          "多",
          "个",
          "二",
          "打电话"
        ],
        "answer": "个",
        "explanation": "\"个\" means measure word."
      },
      {
        "question": "What is the meaning of \"工作\"?",
        "options": [
          "not",
          "dish/vegetable",
          "all/both",
          "job/work"
        ],
        "answer": "job/work",
        "explanation": "\"工作\" (gōngzuò) means \"job/work\"."
      },
      {
        "question": "What is the pinyin for \"狗\" (dog)?",
        "options": [
          "hé",
          "gǒu",
          "gōngzuò",
          "chá"
        ],
        "answer": "gǒu",
        "explanation": "The pinyin for \"狗\" is gǒu."
      },
      {
        "question": "Select the character for \"television\":",
        "options": [
          "家",
          "后面",
          "电视",
          "本"
        ],
        "answer": "电视",
        "explanation": "\"电视\" means television."
      },
      {
        "question": "Grammar Check: Negation with 不 (bù). Which sentence is grammatically correct based on 'Place 不 before the verb to negate it.'?",
        "options": [
          "不我好。",
          "我茶喝。",
          "我不去。",
          "吗你好？"
        ],
        "answer": "我不去。",
        "explanation": "Place 不 before the verb to negate it. Example: 我不去。 (Wǒ bú qù.)"
      },
      {
        "question": "Translate this grammar example to English: 我不去。",
        "options": [
          "I don't know.",
          "Where are you?",
          "This is a book.",
          "I am not going."
        ],
        "answer": "I am not going.",
        "explanation": "我不去。 means I am not going.."
      }
    ]
  },
  {
    "id": "hsk1_day3",
    "title": "Day 3: Vocabulary Range 35-51",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 3",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是汉语吗？",
          "py": "Nǐ hǎo! Zhè shì Hànyǔ ma?",
          "en": "Hello! Is this 汉语?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是好。",
          "py": "Bú shì, zhè shì hǎo.",
          "en": "No, this is 好."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道汉语在哪里吗？",
          "py": "Xièxie, nǐ zhīdào Hànyǔ zài nǎlǐ ma?",
          "en": "Thank you, do you know where 汉语 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢好吗？",
          "py": "Hǎo de. Nǐ xǐhuān hǎo ma?",
          "en": "Okay. Do you like 好?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"汉语\"?",
        "options": [
          "restaurant",
          "Chinese language",
          "can/will",
          "all/both"
        ],
        "answer": "Chinese language",
        "explanation": "\"汉语\" (Hànyǔ) means \"Chinese language\"."
      },
      {
        "question": "What is the pinyin for \"好\" (good)?",
        "options": [
          "jǐ",
          "chá",
          "de",
          "hǎo"
        ],
        "answer": "hǎo",
        "explanation": "The pinyin for \"好\" is hǎo."
      },
      {
        "question": "Select the character for \"number/day of month\":",
        "options": [
          "号",
          "二",
          "后面",
          "不客气"
        ],
        "answer": "号",
        "explanation": "\"号\" means number/day of month."
      },
      {
        "question": "What is the meaning of \"喝\"?",
        "options": [
          "to drink",
          "son",
          "to read",
          "television"
        ],
        "answer": "to drink",
        "explanation": "\"喝\" (hē) means \"to drink\"."
      },
      {
        "question": "What is the pinyin for \"和\" (and)?",
        "options": [
          "duìbuqǐ",
          "hé",
          "kàn",
          "bú kèqi"
        ],
        "answer": "hé",
        "explanation": "The pinyin for \"和\" is hé."
      },
      {
        "question": "Select the character for \"very\":",
        "options": [
          "不客气",
          "很",
          "不",
          "几"
        ],
        "answer": "很",
        "explanation": "\"很\" means very."
      },
      {
        "question": "What is the meaning of \"后面\"?",
        "options": [
          "eight",
          "behind",
          "television",
          "to open/drive"
        ],
        "answer": "behind",
        "explanation": "\"后面\" (hòumiàn) means \"behind\"."
      },
      {
        "question": "What is the pinyin for \"回\" (to return)?",
        "options": [
          "huí",
          "jiǔ",
          "dōngxi",
          "dú"
        ],
        "answer": "huí",
        "explanation": "The pinyin for \"回\" is huí."
      },
      {
        "question": "Select the character for \"can/will\":",
        "options": [
          "电脑",
          "爱",
          "会",
          "大"
        ],
        "answer": "会",
        "explanation": "\"会\" means can/will."
      },
      {
        "question": "What is the meaning of \"几\"?",
        "options": [
          "all/both",
          "Beijing",
          "how many",
          "to eat"
        ],
        "answer": "how many",
        "explanation": "\"几\" (jǐ) means \"how many\"."
      },
      {
        "question": "What is the pinyin for \"家\" (family/home)?",
        "options": [
          "jiā",
          "jīntiān",
          "hěn",
          "chá"
        ],
        "answer": "jiā",
        "explanation": "The pinyin for \"家\" is jiā."
      },
      {
        "question": "Select the character for \"to be called\":",
        "options": [
          "杯子",
          "电影",
          "叫",
          "回"
        ],
        "answer": "叫",
        "explanation": "\"叫\" means to be called."
      },
      {
        "question": "What is the meaning of \"今天\"?",
        "options": [
          "measure word for books",
          "how many",
          "today",
          "very"
        ],
        "answer": "today",
        "explanation": "\"今天\" (jīntiān) means \"today\"."
      },
      {
        "question": "What is the pinyin for \"九\" (nine)?",
        "options": [
          "jiǔ",
          "diànyǐng",
          "chī",
          "dōu"
        ],
        "answer": "jiǔ",
        "explanation": "The pinyin for \"九\" is jiǔ."
      },
      {
        "question": "Select the character for \"to open/drive\":",
        "options": [
          "分钟",
          "本",
          "回",
          "开"
        ],
        "answer": "开",
        "explanation": "\"开\" means to open/drive."
      },
      {
        "question": "What is the meaning of \"看\"?",
        "options": [
          "thing",
          "to look/read",
          "how many",
          "cup"
        ],
        "answer": "to look/read",
        "explanation": "\"看\" (kàn) means \"to look/read\"."
      },
      {
        "question": "What is the pinyin for \"爱\" (to love)?",
        "options": [
          "dú",
          "kāi",
          "ài",
          "bàba"
        ],
        "answer": "ài",
        "explanation": "The pinyin for \"爱\" is ài."
      },
      {
        "question": "Select the character for \"Chinese language\":",
        "options": [
          "汉语",
          "几",
          "出租车",
          "爱"
        ],
        "answer": "汉语",
        "explanation": "\"汉语\" means Chinese language."
      },
      {
        "question": "Grammar Check: Possessive particle 的 (de). Which sentence is grammatically correct based on 'Use 的 to indicate possession, similar to 's in English.'?",
        "options": [
          "我的书",
          "吗你好？",
          "不我好。",
          "我茶喝。"
        ],
        "answer": "我的书",
        "explanation": "Use 的 to indicate possession, similar to 's in English. Example: 我的书 (wǒ de shū)"
      },
      {
        "question": "Translate this grammar example to English: 我的书",
        "options": [
          "This is a book.",
          "my book",
          "I don't know.",
          "Where are you?"
        ],
        "answer": "my book",
        "explanation": "我的书 means my book."
      }
    ]
  },
  {
    "id": "hsk1_day4",
    "title": "Day 4: Vocabulary Range 52-68",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 4",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是八吗？",
          "py": "Nǐ hǎo! Zhè shì bā ma?",
          "en": "Hello! Is this 八?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是爸爸。",
          "py": "Bú shì, zhè shì bàba.",
          "en": "No, this is 爸爸."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道八在哪里吗？",
          "py": "Xièxie, nǐ zhīdào bā zài nǎlǐ ma?",
          "en": "Thank you, do you know where 八 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢爸爸吗？",
          "py": "Hǎo de. Nǐ xǐhuān bàba ma?",
          "en": "Okay. Do you like 爸爸?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"八\"?",
        "options": [
          "nine",
          "eight",
          "to open/drive",
          "restaurant"
        ],
        "answer": "eight",
        "explanation": "\"八\" (bā) means \"eight\"."
      },
      {
        "question": "What is the pinyin for \"爸爸\" (father)?",
        "options": [
          "bàba",
          "èr",
          "chūzūchē",
          "bā"
        ],
        "answer": "bàba",
        "explanation": "The pinyin for \"爸爸\" is bàba."
      },
      {
        "question": "Select the character for \"cup\":",
        "options": [
          "会",
          "点",
          "电脑",
          "杯子"
        ],
        "answer": "杯子",
        "explanation": "\"杯子\" means cup."
      },
      {
        "question": "What is the meaning of \"北京\"?",
        "options": [
          "measure word",
          "Beijing",
          "many/much",
          "father"
        ],
        "answer": "Beijing",
        "explanation": "\"北京\" (Běijīng) means \"Beijing\"."
      },
      {
        "question": "What is the pinyin for \"本\" (measure word for books)?",
        "options": [
          "běn",
          "kàn",
          "jiā",
          "diànyǐng"
        ],
        "answer": "běn",
        "explanation": "The pinyin for \"本\" is běn."
      },
      {
        "question": "Select the character for \"you're welcome\":",
        "options": [
          "茶",
          "不客气",
          "大",
          "开"
        ],
        "answer": "不客气",
        "explanation": "\"不客气\" means you're welcome."
      },
      {
        "question": "What is the meaning of \"不\"?",
        "options": [
          "to be called",
          "sorry",
          "computer",
          "not"
        ],
        "answer": "not",
        "explanation": "\"不\" (bù) means \"not\"."
      },
      {
        "question": "What is the pinyin for \"菜\" (dish/vegetable)?",
        "options": [
          "chá",
          "cài",
          "diànnǎo",
          "huí"
        ],
        "answer": "cài",
        "explanation": "The pinyin for \"菜\" is cài."
      },
      {
        "question": "Select the character for \"tea\":",
        "options": [
          "狗",
          "茶",
          "点",
          "个"
        ],
        "answer": "茶",
        "explanation": "\"茶\" means tea."
      },
      {
        "question": "What is the meaning of \"吃\"?",
        "options": [
          "to eat",
          "sorry",
          "restaurant",
          "behind"
        ],
        "answer": "to eat",
        "explanation": "\"吃\" (chī) means \"to eat\"."
      },
      {
        "question": "What is the pinyin for \"出租车\" (taxi)?",
        "options": [
          "chūzūchē",
          "gōngzuò",
          "huì",
          "bú kèqi"
        ],
        "answer": "chūzūchē",
        "explanation": "The pinyin for \"出租车\" is chūzūchē."
      },
      {
        "question": "Select the character for \"to make a phone call\":",
        "options": [
          "打电话",
          "多",
          "好",
          "茶"
        ],
        "answer": "打电话",
        "explanation": "\"打电话\" means to make a phone call."
      },
      {
        "question": "What is the meaning of \"大\"?",
        "options": [
          "airplane",
          "big",
          "Chinese language",
          "today"
        ],
        "answer": "big",
        "explanation": "\"大\" (dà) means \"big\"."
      },
      {
        "question": "What is the pinyin for \"的\" (possessive particle)?",
        "options": [
          "duìbuqǐ",
          "diànshì",
          "de",
          "bàba"
        ],
        "answer": "de",
        "explanation": "The pinyin for \"的\" is de."
      },
      {
        "question": "Select the character for \"o'clock / point\":",
        "options": [
          "本",
          "汉语",
          "点",
          "都"
        ],
        "answer": "点",
        "explanation": "\"点\" means o'clock / point."
      },
      {
        "question": "What is the meaning of \"电脑\"?",
        "options": [
          "thing",
          "computer",
          "tea",
          "sorry"
        ],
        "answer": "computer",
        "explanation": "\"电脑\" (diànnǎo) means \"computer\"."
      },
      {
        "question": "What is the pinyin for \"电视\" (television)?",
        "options": [
          "diànshì",
          "hěn",
          "fēnzhōng",
          "gǒu"
        ],
        "answer": "diànshì",
        "explanation": "The pinyin for \"电视\" is diànshì."
      },
      {
        "question": "Select the character for \"eight\":",
        "options": [
          "八",
          "几",
          "东西",
          "电脑"
        ],
        "answer": "八",
        "explanation": "\"八\" means eight."
      },
      {
        "question": "Grammar Check: Adverb 也 (yě). Which sentence is grammatically correct based on '也 means 'also' or 'too' and goes before the verb.'?",
        "options": [
          "我也去。",
          "不我好。",
          "吗你好？",
          "我茶喝。"
        ],
        "answer": "我也去。",
        "explanation": "也 means 'also' or 'too' and goes before the verb. Example: 我也去。 (Wǒ yě qù.)"
      },
      {
        "question": "Translate this grammar example to English: 我也去。",
        "options": [
          "I don't know.",
          "Where are you?",
          "This is a book.",
          "I also go."
        ],
        "answer": "I also go.",
        "explanation": "我也去。 means I also go.."
      }
    ]
  },
  {
    "id": "hsk1_day5",
    "title": "Day 5: Vocabulary Range 69-85",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 5",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是电影吗？",
          "py": "Nǐ hǎo! Zhè shì diànyǐng ma?",
          "en": "Hello! Is this 电影?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是东西。",
          "py": "Bú shì, zhè shì dōngxi.",
          "en": "No, this is 东西."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道电影在哪里吗？",
          "py": "Xièxie, nǐ zhīdào diànyǐng zài nǎlǐ ma?",
          "en": "Thank you, do you know where 电影 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢东西吗？",
          "py": "Hǎo de. Nǐ xǐhuān dōngxi ma?",
          "en": "Okay. Do you like 东西?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"电影\"?",
        "options": [
          "how much/many",
          "thing",
          "to make a phone call",
          "movie"
        ],
        "answer": "movie",
        "explanation": "\"电影\" (diànyǐng) means \"movie\"."
      },
      {
        "question": "What is the pinyin for \"东西\" (thing)?",
        "options": [
          "duōshao",
          "dōngxi",
          "huì",
          "bā"
        ],
        "answer": "dōngxi",
        "explanation": "The pinyin for \"东西\" is dōngxi."
      },
      {
        "question": "Select the character for \"all/both\":",
        "options": [
          "二",
          "儿子",
          "飞机",
          "都"
        ],
        "answer": "都",
        "explanation": "\"都\" means all/both."
      },
      {
        "question": "What is the meaning of \"读\"?",
        "options": [
          "to read",
          "television",
          "computer",
          "many/much"
        ],
        "answer": "to read",
        "explanation": "\"读\" (dú) means \"to read\"."
      },
      {
        "question": "What is the pinyin for \"对不起\" (sorry)?",
        "options": [
          "kāi",
          "Běijīng",
          "jiào",
          "duìbuqǐ"
        ],
        "answer": "duìbuqǐ",
        "explanation": "The pinyin for \"对不起\" is duìbuqǐ."
      },
      {
        "question": "Select the character for \"many/much\":",
        "options": [
          "好",
          "多",
          "几",
          "不客气"
        ],
        "answer": "多",
        "explanation": "\"多\" means many/much."
      },
      {
        "question": "What is the meaning of \"多少\"?",
        "options": [
          "to be called",
          "dog",
          "good",
          "how much/many"
        ],
        "answer": "how much/many",
        "explanation": "\"多少\" (duōshao) means \"how much/many\"."
      },
      {
        "question": "What is the pinyin for \"儿子\" (son)?",
        "options": [
          "dǎ diànhuà",
          "chī",
          "kāi",
          "érzi"
        ],
        "answer": "érzi",
        "explanation": "The pinyin for \"儿子\" is érzi."
      },
      {
        "question": "Select the character for \"two\":",
        "options": [
          "后面",
          "汉语",
          "叫",
          "二"
        ],
        "answer": "二",
        "explanation": "\"二\" means two."
      },
      {
        "question": "What is the meaning of \"饭店\"?",
        "options": [
          "measure word for books",
          "restaurant",
          "number/day of month",
          "minute"
        ],
        "answer": "restaurant",
        "explanation": "\"饭店\" (fàndiàn) means \"restaurant\"."
      },
      {
        "question": "What is the pinyin for \"飞机\" (airplane)?",
        "options": [
          "fēijī",
          "huì",
          "dú",
          "Běijīng"
        ],
        "answer": "fēijī",
        "explanation": "The pinyin for \"飞机\" is fēijī."
      },
      {
        "question": "Select the character for \"minute\":",
        "options": [
          "分钟",
          "今天",
          "好",
          "读"
        ],
        "answer": "分钟",
        "explanation": "\"分钟\" means minute."
      },
      {
        "question": "What is the meaning of \"高兴\"?",
        "options": [
          "taxi",
          "to open/drive",
          "eight",
          "happy"
        ],
        "answer": "happy",
        "explanation": "\"高兴\" (gāoxìng) means \"happy\"."
      },
      {
        "question": "What is the pinyin for \"个\" (measure word)?",
        "options": [
          "gōngzuò",
          "gè",
          "dà",
          "fēnzhōng"
        ],
        "answer": "gè",
        "explanation": "The pinyin for \"个\" is gè."
      },
      {
        "question": "Select the character for \"job/work\":",
        "options": [
          "爱",
          "后面",
          "工作",
          "个"
        ],
        "answer": "工作",
        "explanation": "\"工作\" means job/work."
      },
      {
        "question": "What is the meaning of \"狗\"?",
        "options": [
          "to drink",
          "dog",
          "many/much",
          "measure word"
        ],
        "answer": "dog",
        "explanation": "\"狗\" (gǒu) means \"dog\"."
      },
      {
        "question": "What is the pinyin for \"汉语\" (Chinese language)?",
        "options": [
          "kàn",
          "duōshao",
          "Hànyǔ",
          "dōngxi"
        ],
        "answer": "Hànyǔ",
        "explanation": "The pinyin for \"汉语\" is Hànyǔ."
      },
      {
        "question": "Select the character for \"movie\":",
        "options": [
          "电影",
          "北京",
          "后面",
          "叫"
        ],
        "answer": "电影",
        "explanation": "\"电影\" means movie."
      },
      {
        "question": "Grammar Check: Adverb 很 (hěn). Which sentence is grammatically correct based on '很 means 'very' and is often used to link nouns to adjectives instead of 'is'.'?",
        "options": [
          "我很好。",
          "不我好。",
          "我茶喝。",
          "吗你好？"
        ],
        "answer": "我很好。",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'. Example: 我很好。 (Wǒ hěn hǎo.)"
      },
      {
        "question": "Translate this grammar example to English: 我很好。",
        "options": [
          "Where are you?",
          "I am very good.",
          "This is a book.",
          "I don't know."
        ],
        "answer": "I am very good.",
        "explanation": "我很好。 means I am very good.."
      }
    ]
  },
  {
    "id": "hsk1_day6",
    "title": "Day 6: Vocabulary Range 86-102",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 6",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是好吗？",
          "py": "Nǐ hǎo! Zhè shì hǎo ma?",
          "en": "Hello! Is this 好?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是号。",
          "py": "Bú shì, zhè shì hào.",
          "en": "No, this is 号."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道好在哪里吗？",
          "py": "Xièxie, nǐ zhīdào hǎo zài nǎlǐ ma?",
          "en": "Thank you, do you know where 好 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢号吗？",
          "py": "Hǎo de. Nǐ xǐhuān hào ma?",
          "en": "Okay. Do you like 号?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"好\"?",
        "options": [
          "good",
          "measure word",
          "son",
          "can/will"
        ],
        "answer": "good",
        "explanation": "\"好\" (hǎo) means \"good\"."
      },
      {
        "question": "What is the pinyin for \"号\" (number/day of month)?",
        "options": [
          "hào",
          "běn",
          "jiǔ",
          "huì"
        ],
        "answer": "hào",
        "explanation": "The pinyin for \"号\" is hào."
      },
      {
        "question": "Select the character for \"to drink\":",
        "options": [
          "喝",
          "会",
          "八",
          "汉语"
        ],
        "answer": "喝",
        "explanation": "\"喝\" means to drink."
      },
      {
        "question": "What is the meaning of \"和\"?",
        "options": [
          "o'clock / point",
          "good",
          "restaurant",
          "and"
        ],
        "answer": "and",
        "explanation": "\"和\" (hé) means \"and\"."
      },
      {
        "question": "What is the pinyin for \"很\" (very)?",
        "options": [
          "èr",
          "bā",
          "hěn",
          "diǎn"
        ],
        "answer": "hěn",
        "explanation": "The pinyin for \"很\" is hěn."
      },
      {
        "question": "Select the character for \"behind\":",
        "options": [
          "后面",
          "吃",
          "和",
          "几"
        ],
        "answer": "后面",
        "explanation": "\"后面\" means behind."
      },
      {
        "question": "What is the meaning of \"回\"?",
        "options": [
          "can/will",
          "you're welcome",
          "to return",
          "happy"
        ],
        "answer": "to return",
        "explanation": "\"回\" (huí) means \"to return\"."
      },
      {
        "question": "What is the pinyin for \"会\" (can/will)?",
        "options": [
          "bā",
          "dōu",
          "chī",
          "huì"
        ],
        "answer": "huì",
        "explanation": "The pinyin for \"会\" is huì."
      },
      {
        "question": "Select the character for \"how many\":",
        "options": [
          "多少",
          "电脑",
          "好",
          "几"
        ],
        "answer": "几",
        "explanation": "\"几\" means how many."
      },
      {
        "question": "What is the meaning of \"家\"?",
        "options": [
          "how much/many",
          "computer",
          "number/day of month",
          "family/home"
        ],
        "answer": "family/home",
        "explanation": "\"家\" (jiā) means \"family/home\"."
      },
      {
        "question": "What is the pinyin for \"叫\" (to be called)?",
        "options": [
          "gōngzuò",
          "duōshao",
          "jiào",
          "fēnzhōng"
        ],
        "answer": "jiào",
        "explanation": "The pinyin for \"叫\" is jiào."
      },
      {
        "question": "Select the character for \"today\":",
        "options": [
          "不客气",
          "不",
          "今天",
          "的"
        ],
        "answer": "今天",
        "explanation": "\"今天\" means today."
      },
      {
        "question": "What is the meaning of \"九\"?",
        "options": [
          "nine",
          "measure word",
          "son",
          "to look/read"
        ],
        "answer": "nine",
        "explanation": "\"九\" (jiǔ) means \"nine\"."
      },
      {
        "question": "What is the pinyin for \"开\" (to open/drive)?",
        "options": [
          "kāi",
          "duōshao",
          "dú",
          "bā"
        ],
        "answer": "kāi",
        "explanation": "The pinyin for \"开\" is kāi."
      },
      {
        "question": "Select the character for \"to look/read\":",
        "options": [
          "北京",
          "看",
          "工作",
          "今天"
        ],
        "answer": "看",
        "explanation": "\"看\" means to look/read."
      },
      {
        "question": "What is the meaning of \"爱\"?",
        "options": [
          "can/will",
          "to love",
          "computer",
          "restaurant"
        ],
        "answer": "to love",
        "explanation": "\"爱\" (ài) means \"to love\"."
      },
      {
        "question": "What is the pinyin for \"八\" (eight)?",
        "options": [
          "gè",
          "chá",
          "bā",
          "huí"
        ],
        "answer": "bā",
        "explanation": "The pinyin for \"八\" is bā."
      },
      {
        "question": "Select the character for \"good\":",
        "options": [
          "点",
          "的",
          "读",
          "好"
        ],
        "answer": "好",
        "explanation": "\"好\" means good."
      },
      {
        "question": "Grammar Check: Question Word 几 (jǐ). Which sentence is grammatically correct based on '几 is used to ask 'how many' for numbers typically under 10.'?",
        "options": [
          "我茶喝。",
          "几个人？",
          "吗你好？",
          "不我好。"
        ],
        "answer": "几个人？",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10. Example: 几个人？ (Jǐ gè rén?)"
      },
      {
        "question": "Translate this grammar example to English: 几个人？",
        "options": [
          "This is a book.",
          "I don't know.",
          "Where are you?",
          "How many people?"
        ],
        "answer": "How many people?",
        "explanation": "几个人？ means How many people?."
      }
    ]
  },
  {
    "id": "hsk1_day7",
    "title": "Day 7: Vocabulary Range 103-119",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 7",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是爸爸吗？",
          "py": "Nǐ hǎo! Zhè shì bàba ma?",
          "en": "Hello! Is this 爸爸?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是杯子。",
          "py": "Bú shì, zhè shì bēizi.",
          "en": "No, this is 杯子."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道爸爸在哪里吗？",
          "py": "Xièxie, nǐ zhīdào bàba zài nǎlǐ ma?",
          "en": "Thank you, do you know where 爸爸 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢杯子吗？",
          "py": "Hǎo de. Nǐ xǐhuān bēizi ma?",
          "en": "Okay. Do you like 杯子?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"爸爸\"?",
        "options": [
          "to drink",
          "how much/many",
          "number/day of month",
          "father"
        ],
        "answer": "father",
        "explanation": "\"爸爸\" (bàba) means \"father\"."
      },
      {
        "question": "What is the pinyin for \"杯子\" (cup)?",
        "options": [
          "èr",
          "gǒu",
          "bēizi",
          "Běijīng"
        ],
        "answer": "bēizi",
        "explanation": "The pinyin for \"杯子\" is bēizi."
      },
      {
        "question": "Select the character for \"Beijing\":",
        "options": [
          "北京",
          "不客气",
          "好",
          "茶"
        ],
        "answer": "北京",
        "explanation": "\"北京\" means Beijing."
      },
      {
        "question": "What is the meaning of \"本\"?",
        "options": [
          "not",
          "measure word for books",
          "father",
          "television"
        ],
        "answer": "measure word for books",
        "explanation": "\"本\" (běn) means \"measure word for books\"."
      },
      {
        "question": "What is the pinyin for \"不客气\" (you're welcome)?",
        "options": [
          "bú kèqi",
          "hē",
          "bēizi",
          "diànnǎo"
        ],
        "answer": "bú kèqi",
        "explanation": "The pinyin for \"不客气\" is bú kèqi."
      },
      {
        "question": "Select the character for \"not\":",
        "options": [
          "不",
          "电视",
          "汉语",
          "分钟"
        ],
        "answer": "不",
        "explanation": "\"不\" means not."
      },
      {
        "question": "What is the meaning of \"菜\"?",
        "options": [
          "dish/vegetable",
          "restaurant",
          "airplane",
          "to open/drive"
        ],
        "answer": "dish/vegetable",
        "explanation": "\"菜\" (cài) means \"dish/vegetable\"."
      },
      {
        "question": "What is the pinyin for \"茶\" (tea)?",
        "options": [
          "chá",
          "kāi",
          "jīntiān",
          "jǐ"
        ],
        "answer": "chá",
        "explanation": "The pinyin for \"茶\" is chá."
      },
      {
        "question": "Select the character for \"to eat\":",
        "options": [
          "家",
          "吃",
          "和",
          "狗"
        ],
        "answer": "吃",
        "explanation": "\"吃\" means to eat."
      },
      {
        "question": "What is the meaning of \"出租车\"?",
        "options": [
          "taxi",
          "not",
          "o'clock / point",
          "movie"
        ],
        "answer": "taxi",
        "explanation": "\"出租车\" (chūzūchē) means \"taxi\"."
      },
      {
        "question": "What is the pinyin for \"打电话\" (to make a phone call)?",
        "options": [
          "èr",
          "jǐ",
          "dǎ diànhuà",
          "dà"
        ],
        "answer": "dǎ diànhuà",
        "explanation": "The pinyin for \"打电话\" is dǎ diànhuà."
      },
      {
        "question": "Select the character for \"big\":",
        "options": [
          "今天",
          "杯子",
          "汉语",
          "大"
        ],
        "answer": "大",
        "explanation": "\"大\" means big."
      },
      {
        "question": "What is the meaning of \"的\"?",
        "options": [
          "airplane",
          "possessive particle",
          "dog",
          "can/will"
        ],
        "answer": "possessive particle",
        "explanation": "\"的\" (de) means \"possessive particle\"."
      },
      {
        "question": "What is the pinyin for \"点\" (o'clock / point)?",
        "options": [
          "diǎn",
          "huì",
          "ài",
          "huí"
        ],
        "answer": "diǎn",
        "explanation": "The pinyin for \"点\" is diǎn."
      },
      {
        "question": "Select the character for \"computer\":",
        "options": [
          "电脑",
          "很",
          "读",
          "和"
        ],
        "answer": "电脑",
        "explanation": "\"电脑\" means computer."
      },
      {
        "question": "What is the meaning of \"电视\"?",
        "options": [
          "to return",
          "father",
          "television",
          "many/much"
        ],
        "answer": "television",
        "explanation": "\"电视\" (diànshì) means \"television\"."
      },
      {
        "question": "What is the pinyin for \"电影\" (movie)?",
        "options": [
          "Hànyǔ",
          "diànyǐng",
          "gāoxìng",
          "diǎn"
        ],
        "answer": "diànyǐng",
        "explanation": "The pinyin for \"电影\" is diànyǐng."
      },
      {
        "question": "Select the character for \"father\":",
        "options": [
          "高兴",
          "汉语",
          "好",
          "爸爸"
        ],
        "answer": "爸爸",
        "explanation": "\"爸爸\" means father."
      },
      {
        "question": "Grammar Check: Location marker 在 (zài). Which sentence is grammatically correct based on '在 indicates location (at, in, on).'?",
        "options": [
          "我在家。",
          "不我好。",
          "我茶喝。",
          "吗你好？"
        ],
        "answer": "我在家。",
        "explanation": "在 indicates location (at, in, on). Example: 我在家。 (Wǒ zài jiā.)"
      },
      {
        "question": "Translate this grammar example to English: 我在家。",
        "options": [
          "I don't know.",
          "I am at home.",
          "This is a book.",
          "Where are you?"
        ],
        "answer": "I am at home.",
        "explanation": "我在家。 means I am at home.."
      }
    ]
  },
  {
    "id": "hsk1_day8",
    "title": "Day 8: Vocabulary Range 120-136",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 8",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是东西吗？",
          "py": "Nǐ hǎo! Zhè shì dōngxi ma?",
          "en": "Hello! Is this 东西?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是都。",
          "py": "Bú shì, zhè shì dōu.",
          "en": "No, this is 都."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道东西在哪里吗？",
          "py": "Xièxie, nǐ zhīdào dōngxi zài nǎlǐ ma?",
          "en": "Thank you, do you know where 东西 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢都吗？",
          "py": "Hǎo de. Nǐ xǐhuān dōu ma?",
          "en": "Okay. Do you like 都?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"东西\"?",
        "options": [
          "dish/vegetable",
          "thing",
          "cup",
          "measure word"
        ],
        "answer": "thing",
        "explanation": "\"东西\" (dōngxi) means \"thing\"."
      },
      {
        "question": "What is the pinyin for \"都\" (all/both)?",
        "options": [
          "fàndiàn",
          "jiā",
          "chūzūchē",
          "dōu"
        ],
        "answer": "dōu",
        "explanation": "The pinyin for \"都\" is dōu."
      },
      {
        "question": "Select the character for \"to read\":",
        "options": [
          "茶",
          "读",
          "对不起",
          "好"
        ],
        "answer": "读",
        "explanation": "\"读\" means to read."
      },
      {
        "question": "What is the meaning of \"对不起\"?",
        "options": [
          "Beijing",
          "very",
          "cup",
          "sorry"
        ],
        "answer": "sorry",
        "explanation": "\"对不起\" (duìbuqǐ) means \"sorry\"."
      },
      {
        "question": "What is the pinyin for \"多\" (many/much)?",
        "options": [
          "dōngxi",
          "duō",
          "dú",
          "diànshì"
        ],
        "answer": "duō",
        "explanation": "The pinyin for \"多\" is duō."
      },
      {
        "question": "Select the character for \"how much/many\":",
        "options": [
          "多少",
          "工作",
          "家",
          "八"
        ],
        "answer": "多少",
        "explanation": "\"多少\" means how much/many."
      },
      {
        "question": "What is the meaning of \"儿子\"?",
        "options": [
          "son",
          "can/will",
          "to return",
          "how many"
        ],
        "answer": "son",
        "explanation": "\"儿子\" (érzi) means \"son\"."
      },
      {
        "question": "What is the pinyin for \"二\" (two)?",
        "options": [
          "hào",
          "èr",
          "diànyǐng",
          "duìbuqǐ"
        ],
        "answer": "èr",
        "explanation": "The pinyin for \"二\" is èr."
      },
      {
        "question": "Select the character for \"restaurant\":",
        "options": [
          "饭店",
          "儿子",
          "八",
          "很"
        ],
        "answer": "饭店",
        "explanation": "\"饭店\" means restaurant."
      },
      {
        "question": "What is the meaning of \"飞机\"?",
        "options": [
          "all/both",
          "minute",
          "to open/drive",
          "airplane"
        ],
        "answer": "airplane",
        "explanation": "\"飞机\" (fēijī) means \"airplane\"."
      },
      {
        "question": "What is the pinyin for \"分钟\" (minute)?",
        "options": [
          "cài",
          "érzi",
          "fēnzhōng",
          "hòumiàn"
        ],
        "answer": "fēnzhōng",
        "explanation": "The pinyin for \"分钟\" is fēnzhōng."
      },
      {
        "question": "Select the character for \"happy\":",
        "options": [
          "的",
          "高兴",
          "菜",
          "喝"
        ],
        "answer": "高兴",
        "explanation": "\"高兴\" means happy."
      },
      {
        "question": "What is the meaning of \"个\"?",
        "options": [
          "very",
          "big",
          "measure word",
          "possessive particle"
        ],
        "answer": "measure word",
        "explanation": "\"个\" (gè) means \"measure word\"."
      },
      {
        "question": "What is the pinyin for \"工作\" (job/work)?",
        "options": [
          "dà",
          "hē",
          "dōu",
          "gōngzuò"
        ],
        "answer": "gōngzuò",
        "explanation": "The pinyin for \"工作\" is gōngzuò."
      },
      {
        "question": "Select the character for \"dog\":",
        "options": [
          "狗",
          "电脑",
          "和",
          "都"
        ],
        "answer": "狗",
        "explanation": "\"狗\" means dog."
      },
      {
        "question": "What is the meaning of \"汉语\"?",
        "options": [
          "Chinese language",
          "good",
          "to return",
          "very"
        ],
        "answer": "Chinese language",
        "explanation": "\"汉语\" (Hànyǔ) means \"Chinese language\"."
      },
      {
        "question": "What is the pinyin for \"好\" (good)?",
        "options": [
          "bā",
          "duìbuqǐ",
          "Běijīng",
          "hǎo"
        ],
        "answer": "hǎo",
        "explanation": "The pinyin for \"好\" is hǎo."
      },
      {
        "question": "Select the character for \"thing\":",
        "options": [
          "对不起",
          "个",
          "打电话",
          "东西"
        ],
        "answer": "东西",
        "explanation": "\"东西\" means thing."
      },
      {
        "question": "Grammar Check: Verb 会 (huì) for ability. Which sentence is grammatically correct based on '会 means 'can' or 'know how to' for acquired skills.'?",
        "options": [
          "不我好。",
          "我会说汉语。",
          "吗你好？",
          "我茶喝。"
        ],
        "answer": "我会说汉语。",
        "explanation": "会 means 'can' or 'know how to' for acquired skills. Example: 我会说汉语。 (Wǒ huì shuō Hànyǔ.)"
      },
      {
        "question": "Translate this grammar example to English: 我会说汉语。",
        "options": [
          "I don't know.",
          "I can speak Chinese.",
          "This is a book.",
          "Where are you?"
        ],
        "answer": "I can speak Chinese.",
        "explanation": "我会说汉语。 means I can speak Chinese.."
      }
    ]
  },
  {
    "id": "hsk1_day9",
    "title": "Day 9: Vocabulary Range 137-153",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 9",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是号吗？",
          "py": "Nǐ hǎo! Zhè shì hào ma?",
          "en": "Hello! Is this 号?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是喝。",
          "py": "Bú shì, zhè shì hē.",
          "en": "No, this is 喝."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道号在哪里吗？",
          "py": "Xièxie, nǐ zhīdào hào zài nǎlǐ ma?",
          "en": "Thank you, do you know where 号 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢喝吗？",
          "py": "Hǎo de. Nǐ xǐhuān hē ma?",
          "en": "Okay. Do you like 喝?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"号\"?",
        "options": [
          "television",
          "job/work",
          "possessive particle",
          "number/day of month"
        ],
        "answer": "number/day of month",
        "explanation": "\"号\" (hào) means \"number/day of month\"."
      },
      {
        "question": "What is the pinyin for \"喝\" (to drink)?",
        "options": [
          "hē",
          "duìbuqǐ",
          "gōngzuò",
          "bēizi"
        ],
        "answer": "hē",
        "explanation": "The pinyin for \"喝\" is hē."
      },
      {
        "question": "Select the character for \"and\":",
        "options": [
          "和",
          "吃",
          "本",
          "多"
        ],
        "answer": "和",
        "explanation": "\"和\" means and."
      },
      {
        "question": "What is the meaning of \"很\"?",
        "options": [
          "to make a phone call",
          "very",
          "sorry",
          "to return"
        ],
        "answer": "very",
        "explanation": "\"很\" (hěn) means \"very\"."
      },
      {
        "question": "What is the pinyin for \"后面\" (behind)?",
        "options": [
          "gāoxìng",
          "hòumiàn",
          "kāi",
          "huì"
        ],
        "answer": "hòumiàn",
        "explanation": "The pinyin for \"后面\" is hòumiàn."
      },
      {
        "question": "Select the character for \"to return\":",
        "options": [
          "东西",
          "回",
          "菜",
          "出租车"
        ],
        "answer": "回",
        "explanation": "\"回\" means to return."
      },
      {
        "question": "What is the meaning of \"会\"?",
        "options": [
          "son",
          "can/will",
          "to drink",
          "behind"
        ],
        "answer": "can/will",
        "explanation": "\"会\" (huì) means \"can/will\"."
      },
      {
        "question": "What is the pinyin for \"几\" (how many)?",
        "options": [
          "duìbuqǐ",
          "jǐ",
          "gè",
          "érzi"
        ],
        "answer": "jǐ",
        "explanation": "The pinyin for \"几\" is jǐ."
      },
      {
        "question": "Select the character for \"family/home\":",
        "options": [
          "家",
          "开",
          "很",
          "高兴"
        ],
        "answer": "家",
        "explanation": "\"家\" means family/home."
      },
      {
        "question": "What is the meaning of \"叫\"?",
        "options": [
          "Beijing",
          "son",
          "restaurant",
          "to be called"
        ],
        "answer": "to be called",
        "explanation": "\"叫\" (jiào) means \"to be called\"."
      },
      {
        "question": "What is the pinyin for \"今天\" (today)?",
        "options": [
          "jīntiān",
          "jiǔ",
          "hé",
          "gōngzuò"
        ],
        "answer": "jīntiān",
        "explanation": "The pinyin for \"今天\" is jīntiān."
      },
      {
        "question": "Select the character for \"nine\":",
        "options": [
          "很",
          "九",
          "电脑",
          "爱"
        ],
        "answer": "九",
        "explanation": "\"九\" means nine."
      },
      {
        "question": "What is the meaning of \"开\"?",
        "options": [
          "to open/drive",
          "to be called",
          "to look/read",
          "you're welcome"
        ],
        "answer": "to open/drive",
        "explanation": "\"开\" (kāi) means \"to open/drive\"."
      },
      {
        "question": "What is the pinyin for \"看\" (to look/read)?",
        "options": [
          "hào",
          "duìbuqǐ",
          "kàn",
          "fàndiàn"
        ],
        "answer": "kàn",
        "explanation": "The pinyin for \"看\" is kàn."
      },
      {
        "question": "Select the character for \"to love\":",
        "options": [
          "爱",
          "爸爸",
          "不",
          "后面"
        ],
        "answer": "爱",
        "explanation": "\"爱\" means to love."
      },
      {
        "question": "What is the meaning of \"八\"?",
        "options": [
          "eight",
          "to love",
          "behind",
          "big"
        ],
        "answer": "eight",
        "explanation": "\"八\" (bā) means \"eight\"."
      },
      {
        "question": "What is the pinyin for \"爸爸\" (father)?",
        "options": [
          "dà",
          "diànshì",
          "bàba",
          "bú kèqi"
        ],
        "answer": "bàba",
        "explanation": "The pinyin for \"爸爸\" is bàba."
      },
      {
        "question": "Select the character for \"number/day of month\":",
        "options": [
          "号",
          "汉语",
          "看",
          "回"
        ],
        "answer": "号",
        "explanation": "\"号\" means number/day of month."
      },
      {
        "question": "Grammar Check: Asking 'What' with 什么 (shénme). Which sentence is grammatically correct based on '什么 is used to ask 'what'.'?",
        "options": [
          "我茶喝。",
          "这是什么？",
          "吗你好？",
          "不我好。"
        ],
        "answer": "这是什么？",
        "explanation": "什么 is used to ask 'what'. Example: 这是什么？ (Zhè shì shénme?)"
      },
      {
        "question": "Translate this grammar example to English: 这是什么？",
        "options": [
          "This is a book.",
          "Where are you?",
          "I don't know.",
          "What is this?"
        ],
        "answer": "What is this?",
        "explanation": "这是什么？ means What is this?."
      }
    ]
  },
  {
    "id": "hsk1_day10",
    "title": "Day 10: Vocabulary Range 154-170",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 10",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是杯子吗？",
          "py": "Nǐ hǎo! Zhè shì bēizi ma?",
          "en": "Hello! Is this 杯子?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是北京。",
          "py": "Bú shì, zhè shì Běijīng.",
          "en": "No, this is 北京."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道杯子在哪里吗？",
          "py": "Xièxie, nǐ zhīdào bēizi zài nǎlǐ ma?",
          "en": "Thank you, do you know where 杯子 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢北京吗？",
          "py": "Hǎo de. Nǐ xǐhuān Běijīng ma?",
          "en": "Okay. Do you like 北京?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"杯子\"?",
        "options": [
          "minute",
          "two",
          "cup",
          "to drink"
        ],
        "answer": "cup",
        "explanation": "\"杯子\" (bēizi) means \"cup\"."
      },
      {
        "question": "What is the pinyin for \"北京\" (Beijing)?",
        "options": [
          "chūzūchē",
          "gōngzuò",
          "Běijīng",
          "běn"
        ],
        "answer": "Běijīng",
        "explanation": "The pinyin for \"北京\" is Běijīng."
      },
      {
        "question": "Select the character for \"measure word for books\":",
        "options": [
          "多少",
          "点",
          "本",
          "北京"
        ],
        "answer": "本",
        "explanation": "\"本\" means measure word for books."
      },
      {
        "question": "What is the meaning of \"不客气\"?",
        "options": [
          "thing",
          "Beijing",
          "you're welcome",
          "tea"
        ],
        "answer": "you're welcome",
        "explanation": "\"不客气\" (bú kèqi) means \"you're welcome\"."
      },
      {
        "question": "What is the pinyin for \"不\" (not)?",
        "options": [
          "chī",
          "bù",
          "jīntiān",
          "diǎn"
        ],
        "answer": "bù",
        "explanation": "The pinyin for \"不\" is bù."
      },
      {
        "question": "Select the character for \"dish/vegetable\":",
        "options": [
          "飞机",
          "菜",
          "吃",
          "号"
        ],
        "answer": "菜",
        "explanation": "\"菜\" means dish/vegetable."
      },
      {
        "question": "What is the meaning of \"茶\"?",
        "options": [
          "television",
          "tea",
          "dog",
          "how many"
        ],
        "answer": "tea",
        "explanation": "\"茶\" (chá) means \"tea\"."
      },
      {
        "question": "What is the pinyin for \"吃\" (to eat)?",
        "options": [
          "ài",
          "chī",
          "kāi",
          "hē"
        ],
        "answer": "chī",
        "explanation": "The pinyin for \"吃\" is chī."
      },
      {
        "question": "Select the character for \"taxi\":",
        "options": [
          "叫",
          "对不起",
          "爱",
          "出租车"
        ],
        "answer": "出租车",
        "explanation": "\"出租车\" means taxi."
      },
      {
        "question": "What is the meaning of \"打电话\"?",
        "options": [
          "to look/read",
          "to make a phone call",
          "minute",
          "two"
        ],
        "answer": "to make a phone call",
        "explanation": "\"打电话\" (dǎ diànhuà) means \"to make a phone call\"."
      },
      {
        "question": "What is the pinyin for \"大\" (big)?",
        "options": [
          "jīntiān",
          "érzi",
          "dà",
          "hào"
        ],
        "answer": "dà",
        "explanation": "The pinyin for \"大\" is dà."
      },
      {
        "question": "Select the character for \"possessive particle\":",
        "options": [
          "爸爸",
          "工作",
          "叫",
          "的"
        ],
        "answer": "的",
        "explanation": "\"的\" means possessive particle."
      },
      {
        "question": "What is the meaning of \"点\"?",
        "options": [
          "to be called",
          "o'clock / point",
          "to return",
          "family/home"
        ],
        "answer": "o'clock / point",
        "explanation": "\"点\" (diǎn) means \"o'clock / point\"."
      },
      {
        "question": "What is the pinyin for \"电脑\" (computer)?",
        "options": [
          "gè",
          "kàn",
          "diànnǎo",
          "dǎ diànhuà"
        ],
        "answer": "diànnǎo",
        "explanation": "The pinyin for \"电脑\" is diànnǎo."
      },
      {
        "question": "Select the character for \"television\":",
        "options": [
          "今天",
          "个",
          "点",
          "电视"
        ],
        "answer": "电视",
        "explanation": "\"电视\" means television."
      },
      {
        "question": "What is the meaning of \"电影\"?",
        "options": [
          "nine",
          "behind",
          "eight",
          "movie"
        ],
        "answer": "movie",
        "explanation": "\"电影\" (diànyǐng) means \"movie\"."
      },
      {
        "question": "What is the pinyin for \"东西\" (thing)?",
        "options": [
          "dōngxi",
          "hòumiàn",
          "diànnǎo",
          "bú kèqi"
        ],
        "answer": "dōngxi",
        "explanation": "The pinyin for \"东西\" is dōngxi."
      },
      {
        "question": "Select the character for \"cup\":",
        "options": [
          "电脑",
          "点",
          "杯子",
          "不客气"
        ],
        "answer": "杯子",
        "explanation": "\"杯子\" means cup."
      },
      {
        "question": "Grammar Check: Subject-Verb-Object. Which sentence is grammatically correct based on 'The basic sentence structure.'?",
        "options": [
          "我茶喝。",
          "吗你好？",
          "我喝茶。",
          "不我好。"
        ],
        "answer": "我喝茶。",
        "explanation": "The basic sentence structure. Example: 我喝茶。 (Wǒ hē chá.)"
      },
      {
        "question": "Translate this grammar example to English: 我喝茶。",
        "options": [
          "Where are you?",
          "This is a book.",
          "I drink tea.",
          "I don't know."
        ],
        "answer": "I drink tea.",
        "explanation": "我喝茶。 means I drink tea.."
      }
    ]
  },
  {
    "id": "hsk1_day11",
    "title": "Day 11: Vocabulary Range 171-187",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 11",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是都吗？",
          "py": "Nǐ hǎo! Zhè shì dōu ma?",
          "en": "Hello! Is this 都?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是读。",
          "py": "Bú shì, zhè shì dú.",
          "en": "No, this is 读."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道都在哪里吗？",
          "py": "Xièxie, nǐ zhīdào dōu zài nǎlǐ ma?",
          "en": "Thank you, do you know where 都 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢读吗？",
          "py": "Hǎo de. Nǐ xǐhuān dú ma?",
          "en": "Okay. Do you like 读?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"都\"?",
        "options": [
          "computer",
          "all/both",
          "today",
          "happy"
        ],
        "answer": "all/both",
        "explanation": "\"都\" (dōu) means \"all/both\"."
      },
      {
        "question": "What is the pinyin for \"读\" (to read)?",
        "options": [
          "jiǔ",
          "kāi",
          "diànshì",
          "dú"
        ],
        "answer": "dú",
        "explanation": "The pinyin for \"读\" is dú."
      },
      {
        "question": "Select the character for \"sorry\":",
        "options": [
          "对不起",
          "都",
          "看",
          "喝"
        ],
        "answer": "对不起",
        "explanation": "\"对不起\" means sorry."
      },
      {
        "question": "What is the meaning of \"多\"?",
        "options": [
          "son",
          "many/much",
          "Beijing",
          "family/home"
        ],
        "answer": "many/much",
        "explanation": "\"多\" (duō) means \"many/much\"."
      },
      {
        "question": "What is the pinyin for \"多少\" (how much/many)?",
        "options": [
          "huí",
          "kāi",
          "dōu",
          "duōshao"
        ],
        "answer": "duōshao",
        "explanation": "The pinyin for \"多少\" is duōshao."
      },
      {
        "question": "Select the character for \"son\":",
        "options": [
          "出租车",
          "号",
          "电脑",
          "儿子"
        ],
        "answer": "儿子",
        "explanation": "\"儿子\" means son."
      },
      {
        "question": "What is the meaning of \"二\"?",
        "options": [
          "job/work",
          "behind",
          "two",
          "nine"
        ],
        "answer": "two",
        "explanation": "\"二\" (èr) means \"two\"."
      },
      {
        "question": "What is the pinyin for \"饭店\" (restaurant)?",
        "options": [
          "fàndiàn",
          "bàba",
          "èr",
          "hǎo"
        ],
        "answer": "fàndiàn",
        "explanation": "The pinyin for \"饭店\" is fàndiàn."
      },
      {
        "question": "Select the character for \"airplane\":",
        "options": [
          "工作",
          "读",
          "多少",
          "飞机"
        ],
        "answer": "飞机",
        "explanation": "\"飞机\" means airplane."
      },
      {
        "question": "What is the meaning of \"分钟\"?",
        "options": [
          "happy",
          "minute",
          "o'clock / point",
          "to be called"
        ],
        "answer": "minute",
        "explanation": "\"分钟\" (fēnzhōng) means \"minute\"."
      },
      {
        "question": "What is the pinyin for \"高兴\" (happy)?",
        "options": [
          "duìbuqǐ",
          "Hànyǔ",
          "gāoxìng",
          "diànshì"
        ],
        "answer": "gāoxìng",
        "explanation": "The pinyin for \"高兴\" is gāoxìng."
      },
      {
        "question": "Select the character for \"measure word\":",
        "options": [
          "东西",
          "电脑",
          "北京",
          "个"
        ],
        "answer": "个",
        "explanation": "\"个\" means measure word."
      },
      {
        "question": "What is the meaning of \"工作\"?",
        "options": [
          "dish/vegetable",
          "cup",
          "job/work",
          "family/home"
        ],
        "answer": "job/work",
        "explanation": "\"工作\" (gōngzuò) means \"job/work\"."
      },
      {
        "question": "What is the pinyin for \"狗\" (dog)?",
        "options": [
          "dú",
          "dōu",
          "èr",
          "gǒu"
        ],
        "answer": "gǒu",
        "explanation": "The pinyin for \"狗\" is gǒu."
      },
      {
        "question": "Select the character for \"Chinese language\":",
        "options": [
          "八",
          "杯子",
          "看",
          "汉语"
        ],
        "answer": "汉语",
        "explanation": "\"汉语\" means Chinese language."
      },
      {
        "question": "What is the meaning of \"好\"?",
        "options": [
          "to make a phone call",
          "good",
          "eight",
          "sorry"
        ],
        "answer": "good",
        "explanation": "\"好\" (hǎo) means \"good\"."
      },
      {
        "question": "What is the pinyin for \"号\" (number/day of month)?",
        "options": [
          "hào",
          "jiào",
          "duōshao",
          "bàba"
        ],
        "answer": "hào",
        "explanation": "The pinyin for \"号\" is hào."
      },
      {
        "question": "Select the character for \"all/both\":",
        "options": [
          "都",
          "北京",
          "喝",
          "本"
        ],
        "answer": "都",
        "explanation": "\"都\" means all/both."
      },
      {
        "question": "Grammar Check: Question Particle 吗 (ma). Which sentence is grammatically correct based on 'Add 吗 at the end of a statement to make it a yes/no question.'?",
        "options": [
          "不我好。",
          "吗你好？",
          "你好吗？",
          "我茶喝。"
        ],
        "answer": "你好吗？",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question. Example: 你好吗？ (Nǐ hǎo ma?)"
      },
      {
        "question": "Translate this grammar example to English: 你好吗？",
        "options": [
          "Where are you?",
          "I don't know.",
          "This is a book.",
          "Are you good?"
        ],
        "answer": "Are you good?",
        "explanation": "你好吗？ means Are you good?."
      }
    ]
  },
  {
    "id": "hsk1_day12",
    "title": "Day 12: Vocabulary Range 188-204",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 12",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是喝吗？",
          "py": "Nǐ hǎo! Zhè shì hē ma?",
          "en": "Hello! Is this 喝?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是和。",
          "py": "Bú shì, zhè shì hé.",
          "en": "No, this is 和."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道喝在哪里吗？",
          "py": "Xièxie, nǐ zhīdào hē zài nǎlǐ ma?",
          "en": "Thank you, do you know where 喝 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢和吗？",
          "py": "Hǎo de. Nǐ xǐhuān hé ma?",
          "en": "Okay. Do you like 和?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"喝\"?",
        "options": [
          "to love",
          "to drink",
          "Chinese language",
          "restaurant"
        ],
        "answer": "to drink",
        "explanation": "\"喝\" (hē) means \"to drink\"."
      },
      {
        "question": "What is the pinyin for \"和\" (and)?",
        "options": [
          "Běijīng",
          "gè",
          "hé",
          "ài"
        ],
        "answer": "hé",
        "explanation": "The pinyin for \"和\" is hé."
      },
      {
        "question": "Select the character for \"very\":",
        "options": [
          "好",
          "东西",
          "很",
          "电视"
        ],
        "answer": "很",
        "explanation": "\"很\" means very."
      },
      {
        "question": "What is the meaning of \"后面\"?",
        "options": [
          "cup",
          "behind",
          "to return",
          "television"
        ],
        "answer": "behind",
        "explanation": "\"后面\" (hòumiàn) means \"behind\"."
      },
      {
        "question": "What is the pinyin for \"回\" (to return)?",
        "options": [
          "duō",
          "chūzūchē",
          "hé",
          "huí"
        ],
        "answer": "huí",
        "explanation": "The pinyin for \"回\" is huí."
      },
      {
        "question": "Select the character for \"can/will\":",
        "options": [
          "号",
          "会",
          "大",
          "茶"
        ],
        "answer": "会",
        "explanation": "\"会\" means can/will."
      },
      {
        "question": "What is the meaning of \"几\"?",
        "options": [
          "job/work",
          "how many",
          "you're welcome",
          "and"
        ],
        "answer": "how many",
        "explanation": "\"几\" (jǐ) means \"how many\"."
      },
      {
        "question": "What is the pinyin for \"家\" (family/home)?",
        "options": [
          "chūzūchē",
          "gāoxìng",
          "diànshì",
          "jiā"
        ],
        "answer": "jiā",
        "explanation": "The pinyin for \"家\" is jiā."
      },
      {
        "question": "Select the character for \"to be called\":",
        "options": [
          "儿子",
          "点",
          "高兴",
          "叫"
        ],
        "answer": "叫",
        "explanation": "\"叫\" means to be called."
      },
      {
        "question": "What is the meaning of \"今天\"?",
        "options": [
          "many/much",
          "not",
          "today",
          "and"
        ],
        "answer": "today",
        "explanation": "\"今天\" (jīntiān) means \"today\"."
      },
      {
        "question": "What is the pinyin for \"九\" (nine)?",
        "options": [
          "gè",
          "érzi",
          "chūzūchē",
          "jiǔ"
        ],
        "answer": "jiǔ",
        "explanation": "The pinyin for \"九\" is jiǔ."
      },
      {
        "question": "Select the character for \"to open/drive\":",
        "options": [
          "开",
          "吃",
          "飞机",
          "很"
        ],
        "answer": "开",
        "explanation": "\"开\" means to open/drive."
      },
      {
        "question": "What is the meaning of \"看\"?",
        "options": [
          "tea",
          "eight",
          "measure word for books",
          "to look/read"
        ],
        "answer": "to look/read",
        "explanation": "\"看\" (kàn) means \"to look/read\"."
      },
      {
        "question": "What is the pinyin for \"爱\" (to love)?",
        "options": [
          "ài",
          "bā",
          "jiā",
          "dà"
        ],
        "answer": "ài",
        "explanation": "The pinyin for \"爱\" is ài."
      },
      {
        "question": "Select the character for \"eight\":",
        "options": [
          "饭店",
          "开",
          "个",
          "八"
        ],
        "answer": "八",
        "explanation": "\"八\" means eight."
      },
      {
        "question": "What is the meaning of \"爸爸\"?",
        "options": [
          "to drink",
          "all/both",
          "father",
          "possessive particle"
        ],
        "answer": "father",
        "explanation": "\"爸爸\" (bàba) means \"father\"."
      },
      {
        "question": "What is the pinyin for \"杯子\" (cup)?",
        "options": [
          "bēizi",
          "duō",
          "ài",
          "Běijīng"
        ],
        "answer": "bēizi",
        "explanation": "The pinyin for \"杯子\" is bēizi."
      },
      {
        "question": "Select the character for \"to drink\":",
        "options": [
          "电影",
          "都",
          "大",
          "喝"
        ],
        "answer": "喝",
        "explanation": "\"喝\" means to drink."
      },
      {
        "question": "Grammar Check: Negation with 不 (bù). Which sentence is grammatically correct based on 'Place 不 before the verb to negate it.'?",
        "options": [
          "不我好。",
          "我茶喝。",
          "我不去。",
          "吗你好？"
        ],
        "answer": "我不去。",
        "explanation": "Place 不 before the verb to negate it. Example: 我不去。 (Wǒ bú qù.)"
      },
      {
        "question": "Translate this grammar example to English: 我不去。",
        "options": [
          "I don't know.",
          "Where are you?",
          "I am not going.",
          "This is a book."
        ],
        "answer": "I am not going.",
        "explanation": "我不去。 means I am not going.."
      }
    ]
  },
  {
    "id": "hsk1_day13",
    "title": "Day 13: Vocabulary Range 205-221",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 13",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是北京吗？",
          "py": "Nǐ hǎo! Zhè shì Běijīng ma?",
          "en": "Hello! Is this 北京?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是本。",
          "py": "Bú shì, zhè shì běn.",
          "en": "No, this is 本."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道北京在哪里吗？",
          "py": "Xièxie, nǐ zhīdào Běijīng zài nǎlǐ ma?",
          "en": "Thank you, do you know where 北京 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢本吗？",
          "py": "Hǎo de. Nǐ xǐhuān běn ma?",
          "en": "Okay. Do you like 本?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"北京\"?",
        "options": [
          "computer",
          "Beijing",
          "o'clock / point",
          "son"
        ],
        "answer": "Beijing",
        "explanation": "\"北京\" (Běijīng) means \"Beijing\"."
      },
      {
        "question": "What is the pinyin for \"本\" (measure word for books)?",
        "options": [
          "bú kèqi",
          "diànnǎo",
          "jǐ",
          "běn"
        ],
        "answer": "běn",
        "explanation": "The pinyin for \"本\" is běn."
      },
      {
        "question": "Select the character for \"you're welcome\":",
        "options": [
          "飞机",
          "电脑",
          "不客气",
          "出租车"
        ],
        "answer": "不客气",
        "explanation": "\"不客气\" means you're welcome."
      },
      {
        "question": "What is the meaning of \"不\"?",
        "options": [
          "measure word for books",
          "not",
          "Chinese language",
          "to return"
        ],
        "answer": "not",
        "explanation": "\"不\" (bù) means \"not\"."
      },
      {
        "question": "What is the pinyin for \"菜\" (dish/vegetable)?",
        "options": [
          "běn",
          "hěn",
          "gōngzuò",
          "cài"
        ],
        "answer": "cài",
        "explanation": "The pinyin for \"菜\" is cài."
      },
      {
        "question": "Select the character for \"tea\":",
        "options": [
          "多",
          "东西",
          "茶",
          "汉语"
        ],
        "answer": "茶",
        "explanation": "\"茶\" means tea."
      },
      {
        "question": "What is the meaning of \"吃\"?",
        "options": [
          "and",
          "how many",
          "big",
          "to eat"
        ],
        "answer": "to eat",
        "explanation": "\"吃\" (chī) means \"to eat\"."
      },
      {
        "question": "What is the pinyin for \"出租车\" (taxi)?",
        "options": [
          "gǒu",
          "jīntiān",
          "chūzūchē",
          "dōngxi"
        ],
        "answer": "chūzūchē",
        "explanation": "The pinyin for \"出租车\" is chūzūchē."
      },
      {
        "question": "Select the character for \"to make a phone call\":",
        "options": [
          "八",
          "打电话",
          "北京",
          "开"
        ],
        "answer": "打电话",
        "explanation": "\"打电话\" means to make a phone call."
      },
      {
        "question": "What is the meaning of \"大\"?",
        "options": [
          "two",
          "airplane",
          "o'clock / point",
          "big"
        ],
        "answer": "big",
        "explanation": "\"大\" (dà) means \"big\"."
      },
      {
        "question": "What is the pinyin for \"的\" (possessive particle)?",
        "options": [
          "chī",
          "bú kèqi",
          "běn",
          "de"
        ],
        "answer": "de",
        "explanation": "The pinyin for \"的\" is de."
      },
      {
        "question": "Select the character for \"o'clock / point\":",
        "options": [
          "工作",
          "都",
          "点",
          "北京"
        ],
        "answer": "点",
        "explanation": "\"点\" means o'clock / point."
      },
      {
        "question": "What is the meaning of \"电脑\"?",
        "options": [
          "eight",
          "computer",
          "Beijing",
          "cup"
        ],
        "answer": "computer",
        "explanation": "\"电脑\" (diànnǎo) means \"computer\"."
      },
      {
        "question": "What is the pinyin for \"电视\" (television)?",
        "options": [
          "dǎ diànhuà",
          "bàba",
          "diànshì",
          "èr"
        ],
        "answer": "diànshì",
        "explanation": "The pinyin for \"电视\" is diànshì."
      },
      {
        "question": "Select the character for \"movie\":",
        "options": [
          "电影",
          "九",
          "工作",
          "北京"
        ],
        "answer": "电影",
        "explanation": "\"电影\" means movie."
      },
      {
        "question": "What is the meaning of \"东西\"?",
        "options": [
          "airplane",
          "thing",
          "and",
          "measure word for books"
        ],
        "answer": "thing",
        "explanation": "\"东西\" (dōngxi) means \"thing\"."
      },
      {
        "question": "What is the pinyin for \"都\" (all/both)?",
        "options": [
          "bàba",
          "dōu",
          "běn",
          "diànshì"
        ],
        "answer": "dōu",
        "explanation": "The pinyin for \"都\" is dōu."
      },
      {
        "question": "Select the character for \"Beijing\":",
        "options": [
          "爱",
          "狗",
          "北京",
          "读"
        ],
        "answer": "北京",
        "explanation": "\"北京\" means Beijing."
      },
      {
        "question": "Grammar Check: Possessive particle 的 (de). Which sentence is grammatically correct based on 'Use 的 to indicate possession, similar to 's in English.'?",
        "options": [
          "我的书",
          "不我好。",
          "我茶喝。",
          "吗你好？"
        ],
        "answer": "我的书",
        "explanation": "Use 的 to indicate possession, similar to 's in English. Example: 我的书 (wǒ de shū)"
      },
      {
        "question": "Translate this grammar example to English: 我的书",
        "options": [
          "This is a book.",
          "Where are you?",
          "I don't know.",
          "my book"
        ],
        "answer": "my book",
        "explanation": "我的书 means my book."
      }
    ]
  },
  {
    "id": "hsk1_day14",
    "title": "Day 14: Vocabulary Range 222-238",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 14",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是读吗？",
          "py": "Nǐ hǎo! Zhè shì dú ma?",
          "en": "Hello! Is this 读?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是对不起。",
          "py": "Bú shì, zhè shì duìbuqǐ.",
          "en": "No, this is 对不起."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道读在哪里吗？",
          "py": "Xièxie, nǐ zhīdào dú zài nǎlǐ ma?",
          "en": "Thank you, do you know where 读 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢对不起吗？",
          "py": "Hǎo de. Nǐ xǐhuān duìbuqǐ ma?",
          "en": "Okay. Do you like 对不起?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"读\"?",
        "options": [
          "restaurant",
          "can/will",
          "measure word",
          "to read"
        ],
        "answer": "to read",
        "explanation": "\"读\" (dú) means \"to read\"."
      },
      {
        "question": "What is the pinyin for \"对不起\" (sorry)?",
        "options": [
          "hǎo",
          "fēijī",
          "duìbuqǐ",
          "dǎ diànhuà"
        ],
        "answer": "duìbuqǐ",
        "explanation": "The pinyin for \"对不起\" is duìbuqǐ."
      },
      {
        "question": "Select the character for \"many/much\":",
        "options": [
          "叫",
          "多",
          "菜",
          "对不起"
        ],
        "answer": "多",
        "explanation": "\"多\" means many/much."
      },
      {
        "question": "What is the meaning of \"多少\"?",
        "options": [
          "to eat",
          "measure word",
          "how much/many",
          "tea"
        ],
        "answer": "how much/many",
        "explanation": "\"多少\" (duōshao) means \"how much/many\"."
      },
      {
        "question": "What is the pinyin for \"儿子\" (son)?",
        "options": [
          "diànnǎo",
          "de",
          "hào",
          "érzi"
        ],
        "answer": "érzi",
        "explanation": "The pinyin for \"儿子\" is érzi."
      },
      {
        "question": "Select the character for \"two\":",
        "options": [
          "本",
          "会",
          "点",
          "二"
        ],
        "answer": "二",
        "explanation": "\"二\" means two."
      },
      {
        "question": "What is the meaning of \"饭店\"?",
        "options": [
          "two",
          "restaurant",
          "Chinese language",
          "to make a phone call"
        ],
        "answer": "restaurant",
        "explanation": "\"饭店\" (fàndiàn) means \"restaurant\"."
      },
      {
        "question": "What is the pinyin for \"飞机\" (airplane)?",
        "options": [
          "èr",
          "jiǔ",
          "hǎo",
          "fēijī"
        ],
        "answer": "fēijī",
        "explanation": "The pinyin for \"飞机\" is fēijī."
      },
      {
        "question": "Select the character for \"minute\":",
        "options": [
          "个",
          "看",
          "大",
          "分钟"
        ],
        "answer": "分钟",
        "explanation": "\"分钟\" means minute."
      },
      {
        "question": "What is the meaning of \"高兴\"?",
        "options": [
          "happy",
          "son",
          "Chinese language",
          "you're welcome"
        ],
        "answer": "happy",
        "explanation": "\"高兴\" (gāoxìng) means \"happy\"."
      },
      {
        "question": "What is the pinyin for \"个\" (measure word)?",
        "options": [
          "fēnzhōng",
          "běn",
          "huì",
          "gè"
        ],
        "answer": "gè",
        "explanation": "The pinyin for \"个\" is gè."
      },
      {
        "question": "Select the character for \"job/work\":",
        "options": [
          "后面",
          "几",
          "工作",
          "个"
        ],
        "answer": "工作",
        "explanation": "\"工作\" means job/work."
      },
      {
        "question": "What is the meaning of \"狗\"?",
        "options": [
          "to open/drive",
          "tea",
          "possessive particle",
          "dog"
        ],
        "answer": "dog",
        "explanation": "\"狗\" (gǒu) means \"dog\"."
      },
      {
        "question": "What is the pinyin for \"汉语\" (Chinese language)?",
        "options": [
          "jiào",
          "hé",
          "Hànyǔ",
          "jiā"
        ],
        "answer": "Hànyǔ",
        "explanation": "The pinyin for \"汉语\" is Hànyǔ."
      },
      {
        "question": "Select the character for \"good\":",
        "options": [
          "家",
          "多",
          "个",
          "好"
        ],
        "answer": "好",
        "explanation": "\"好\" means good."
      },
      {
        "question": "What is the meaning of \"号\"?",
        "options": [
          "to open/drive",
          "number/day of month",
          "job/work",
          "possessive particle"
        ],
        "answer": "number/day of month",
        "explanation": "\"号\" (hào) means \"number/day of month\"."
      },
      {
        "question": "What is the pinyin for \"喝\" (to drink)?",
        "options": [
          "hē",
          "bēizi",
          "kàn",
          "hǎo"
        ],
        "answer": "hē",
        "explanation": "The pinyin for \"喝\" is hē."
      },
      {
        "question": "Select the character for \"to read\":",
        "options": [
          "东西",
          "和",
          "电脑",
          "读"
        ],
        "answer": "读",
        "explanation": "\"读\" means to read."
      },
      {
        "question": "Grammar Check: Adverb 也 (yě). Which sentence is grammatically correct based on '也 means 'also' or 'too' and goes before the verb.'?",
        "options": [
          "吗你好？",
          "我也去。",
          "不我好。",
          "我茶喝。"
        ],
        "answer": "我也去。",
        "explanation": "也 means 'also' or 'too' and goes before the verb. Example: 我也去。 (Wǒ yě qù.)"
      },
      {
        "question": "Translate this grammar example to English: 我也去。",
        "options": [
          "I also go.",
          "Where are you?",
          "I don't know.",
          "This is a book."
        ],
        "answer": "I also go.",
        "explanation": "我也去。 means I also go.."
      }
    ]
  },
  {
    "id": "hsk1_day15",
    "title": "Day 15: Vocabulary Range 239-255",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 15",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是和吗？",
          "py": "Nǐ hǎo! Zhè shì hé ma?",
          "en": "Hello! Is this 和?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是很。",
          "py": "Bú shì, zhè shì hěn.",
          "en": "No, this is 很."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道和在哪里吗？",
          "py": "Xièxie, nǐ zhīdào hé zài nǎlǐ ma?",
          "en": "Thank you, do you know where 和 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢很吗？",
          "py": "Hǎo de. Nǐ xǐhuān hěn ma?",
          "en": "Okay. Do you like 很?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"和\"?",
        "options": [
          "happy",
          "son",
          "many/much",
          "and"
        ],
        "answer": "and",
        "explanation": "\"和\" (hé) means \"and\"."
      },
      {
        "question": "What is the pinyin for \"很\" (very)?",
        "options": [
          "Běijīng",
          "hěn",
          "dà",
          "dú"
        ],
        "answer": "hěn",
        "explanation": "The pinyin for \"很\" is hěn."
      },
      {
        "question": "Select the character for \"behind\":",
        "options": [
          "后面",
          "喝",
          "回",
          "会"
        ],
        "answer": "后面",
        "explanation": "\"后面\" means behind."
      },
      {
        "question": "What is the meaning of \"回\"?",
        "options": [
          "to be called",
          "job/work",
          "today",
          "to return"
        ],
        "answer": "to return",
        "explanation": "\"回\" (huí) means \"to return\"."
      },
      {
        "question": "What is the pinyin for \"会\" (can/will)?",
        "options": [
          "jīntiān",
          "fēnzhōng",
          "huì",
          "hǎo"
        ],
        "answer": "huì",
        "explanation": "The pinyin for \"会\" is huì."
      },
      {
        "question": "Select the character for \"how many\":",
        "options": [
          "几",
          "会",
          "工作",
          "的"
        ],
        "answer": "几",
        "explanation": "\"几\" means how many."
      },
      {
        "question": "What is the meaning of \"家\"?",
        "options": [
          "happy",
          "family/home",
          "all/both",
          "job/work"
        ],
        "answer": "family/home",
        "explanation": "\"家\" (jiā) means \"family/home\"."
      },
      {
        "question": "What is the pinyin for \"叫\" (to be called)?",
        "options": [
          "dōu",
          "jiào",
          "hào",
          "Běijīng"
        ],
        "answer": "jiào",
        "explanation": "The pinyin for \"叫\" is jiào."
      },
      {
        "question": "Select the character for \"today\":",
        "options": [
          "今天",
          "工作",
          "出租车",
          "家"
        ],
        "answer": "今天",
        "explanation": "\"今天\" means today."
      },
      {
        "question": "What is the meaning of \"九\"?",
        "options": [
          "airplane",
          "dish/vegetable",
          "nine",
          "son"
        ],
        "answer": "nine",
        "explanation": "\"九\" (jiǔ) means \"nine\"."
      },
      {
        "question": "What is the pinyin for \"开\" (to open/drive)?",
        "options": [
          "kāi",
          "dǎ diànhuà",
          "jiào",
          "diànyǐng"
        ],
        "answer": "kāi",
        "explanation": "The pinyin for \"开\" is kāi."
      },
      {
        "question": "Select the character for \"to look/read\":",
        "options": [
          "看",
          "大",
          "电影",
          "好"
        ],
        "answer": "看",
        "explanation": "\"看\" means to look/read."
      },
      {
        "question": "What is the meaning of \"爱\"?",
        "options": [
          "thing",
          "to drink",
          "all/both",
          "to love"
        ],
        "answer": "to love",
        "explanation": "\"爱\" (ài) means \"to love\"."
      },
      {
        "question": "What is the pinyin for \"八\" (eight)?",
        "options": [
          "jiào",
          "bā",
          "hǎo",
          "jiǔ"
        ],
        "answer": "bā",
        "explanation": "The pinyin for \"八\" is bā."
      },
      {
        "question": "Select the character for \"father\":",
        "options": [
          "大",
          "爸爸",
          "工作",
          "后面"
        ],
        "answer": "爸爸",
        "explanation": "\"爸爸\" means father."
      },
      {
        "question": "What is the meaning of \"杯子\"?",
        "options": [
          "restaurant",
          "cup",
          "tea",
          "behind"
        ],
        "answer": "cup",
        "explanation": "\"杯子\" (bēizi) means \"cup\"."
      },
      {
        "question": "What is the pinyin for \"北京\" (Beijing)?",
        "options": [
          "bàba",
          "hòumiàn",
          "Běijīng",
          "dōngxi"
        ],
        "answer": "Běijīng",
        "explanation": "The pinyin for \"北京\" is Běijīng."
      },
      {
        "question": "Select the character for \"and\":",
        "options": [
          "二",
          "会",
          "狗",
          "和"
        ],
        "answer": "和",
        "explanation": "\"和\" means and."
      },
      {
        "question": "Grammar Check: Adverb 很 (hěn). Which sentence is grammatically correct based on '很 means 'very' and is often used to link nouns to adjectives instead of 'is'.'?",
        "options": [
          "我很好。",
          "不我好。",
          "我茶喝。",
          "吗你好？"
        ],
        "answer": "我很好。",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'. Example: 我很好。 (Wǒ hěn hǎo.)"
      },
      {
        "question": "Translate this grammar example to English: 我很好。",
        "options": [
          "I am very good.",
          "Where are you?",
          "I don't know.",
          "This is a book."
        ],
        "answer": "I am very good.",
        "explanation": "我很好。 means I am very good.."
      }
    ]
  },
  {
    "id": "hsk1_day16",
    "title": "Day 16: Vocabulary Range 256-272",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 16",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是本吗？",
          "py": "Nǐ hǎo! Zhè shì běn ma?",
          "en": "Hello! Is this 本?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是不客气。",
          "py": "Bú shì, zhè shì bú kèqi.",
          "en": "No, this is 不客气."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道本在哪里吗？",
          "py": "Xièxie, nǐ zhīdào běn zài nǎlǐ ma?",
          "en": "Thank you, do you know where 本 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢不客气吗？",
          "py": "Hǎo de. Nǐ xǐhuān bú kèqi ma?",
          "en": "Okay. Do you like 不客气?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"本\"?",
        "options": [
          "behind",
          "Beijing",
          "to return",
          "measure word for books"
        ],
        "answer": "measure word for books",
        "explanation": "\"本\" (běn) means \"measure word for books\"."
      },
      {
        "question": "What is the pinyin for \"不客气\" (you're welcome)?",
        "options": [
          "bú kèqi",
          "dà",
          "bēizi",
          "diànnǎo"
        ],
        "answer": "bú kèqi",
        "explanation": "The pinyin for \"不客气\" is bú kèqi."
      },
      {
        "question": "Select the character for \"not\":",
        "options": [
          "读",
          "不",
          "杯子",
          "茶"
        ],
        "answer": "不",
        "explanation": "\"不\" means not."
      },
      {
        "question": "What is the meaning of \"菜\"?",
        "options": [
          "dish/vegetable",
          "cup",
          "television",
          "nine"
        ],
        "answer": "dish/vegetable",
        "explanation": "\"菜\" (cài) means \"dish/vegetable\"."
      },
      {
        "question": "What is the pinyin for \"茶\" (tea)?",
        "options": [
          "chá",
          "cài",
          "huí",
          "hào"
        ],
        "answer": "chá",
        "explanation": "The pinyin for \"茶\" is chá."
      },
      {
        "question": "Select the character for \"to eat\":",
        "options": [
          "后面",
          "吃",
          "叫",
          "电脑"
        ],
        "answer": "吃",
        "explanation": "\"吃\" means to eat."
      },
      {
        "question": "What is the meaning of \"出租车\"?",
        "options": [
          "taxi",
          "today",
          "computer",
          "how many"
        ],
        "answer": "taxi",
        "explanation": "\"出租车\" (chūzūchē) means \"taxi\"."
      },
      {
        "question": "What is the pinyin for \"打电话\" (to make a phone call)?",
        "options": [
          "bēizi",
          "jīntiān",
          "chī",
          "dǎ diànhuà"
        ],
        "answer": "dǎ diànhuà",
        "explanation": "The pinyin for \"打电话\" is dǎ diànhuà."
      },
      {
        "question": "Select the character for \"big\":",
        "options": [
          "杯子",
          "都",
          "叫",
          "大"
        ],
        "answer": "大",
        "explanation": "\"大\" means big."
      },
      {
        "question": "What is the meaning of \"的\"?",
        "options": [
          "job/work",
          "eight",
          "measure word",
          "possessive particle"
        ],
        "answer": "possessive particle",
        "explanation": "\"的\" (de) means \"possessive particle\"."
      },
      {
        "question": "What is the pinyin for \"点\" (o'clock / point)?",
        "options": [
          "huí",
          "diǎn",
          "de",
          "hē"
        ],
        "answer": "diǎn",
        "explanation": "The pinyin for \"点\" is diǎn."
      },
      {
        "question": "Select the character for \"computer\":",
        "options": [
          "电脑",
          "喝",
          "会",
          "儿子"
        ],
        "answer": "电脑",
        "explanation": "\"电脑\" means computer."
      },
      {
        "question": "What is the meaning of \"电视\"?",
        "options": [
          "to drink",
          "television",
          "to love",
          "airplane"
        ],
        "answer": "television",
        "explanation": "\"电视\" (diànshì) means \"television\"."
      },
      {
        "question": "What is the pinyin for \"电影\" (movie)?",
        "options": [
          "ài",
          "gè",
          "hǎo",
          "diànyǐng"
        ],
        "answer": "diànyǐng",
        "explanation": "The pinyin for \"电影\" is diànyǐng."
      },
      {
        "question": "Select the character for \"thing\":",
        "options": [
          "点",
          "东西",
          "爱",
          "爸爸"
        ],
        "answer": "东西",
        "explanation": "\"东西\" means thing."
      },
      {
        "question": "What is the meaning of \"都\"?",
        "options": [
          "restaurant",
          "all/both",
          "how many",
          "to return"
        ],
        "answer": "all/both",
        "explanation": "\"都\" (dōu) means \"all/both\"."
      },
      {
        "question": "What is the pinyin for \"读\" (to read)?",
        "options": [
          "dú",
          "fēijī",
          "bàba",
          "dà"
        ],
        "answer": "dú",
        "explanation": "The pinyin for \"读\" is dú."
      },
      {
        "question": "Select the character for \"measure word for books\":",
        "options": [
          "九",
          "对不起",
          "电影",
          "本"
        ],
        "answer": "本",
        "explanation": "\"本\" means measure word for books."
      },
      {
        "question": "Grammar Check: Question Word 几 (jǐ). Which sentence is grammatically correct based on '几 is used to ask 'how many' for numbers typically under 10.'?",
        "options": [
          "吗你好？",
          "我茶喝。",
          "几个人？",
          "不我好。"
        ],
        "answer": "几个人？",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10. Example: 几个人？ (Jǐ gè rén?)"
      },
      {
        "question": "Translate this grammar example to English: 几个人？",
        "options": [
          "Where are you?",
          "This is a book.",
          "How many people?",
          "I don't know."
        ],
        "answer": "How many people?",
        "explanation": "几个人？ means How many people?."
      }
    ]
  },
  {
    "id": "hsk1_day17",
    "title": "Day 17: Vocabulary Range 273-289",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 17",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是对不起吗？",
          "py": "Nǐ hǎo! Zhè shì duìbuqǐ ma?",
          "en": "Hello! Is this 对不起?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是多。",
          "py": "Bú shì, zhè shì duō.",
          "en": "No, this is 多."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道对不起在哪里吗？",
          "py": "Xièxie, nǐ zhīdào duìbuqǐ zài nǎlǐ ma?",
          "en": "Thank you, do you know where 对不起 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢多吗？",
          "py": "Hǎo de. Nǐ xǐhuān duō ma?",
          "en": "Okay. Do you like 多?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"对不起\"?",
        "options": [
          "minute",
          "sorry",
          "measure word for books",
          "tea"
        ],
        "answer": "sorry",
        "explanation": "\"对不起\" (duìbuqǐ) means \"sorry\"."
      },
      {
        "question": "What is the pinyin for \"多\" (many/much)?",
        "options": [
          "cài",
          "duō",
          "hǎo",
          "bú kèqi"
        ],
        "answer": "duō",
        "explanation": "The pinyin for \"多\" is duō."
      },
      {
        "question": "Select the character for \"how much/many\":",
        "options": [
          "儿子",
          "杯子",
          "不",
          "多少"
        ],
        "answer": "多少",
        "explanation": "\"多少\" means how much/many."
      },
      {
        "question": "What is the meaning of \"儿子\"?",
        "options": [
          "to return",
          "behind",
          "son",
          "possessive particle"
        ],
        "answer": "son",
        "explanation": "\"儿子\" (érzi) means \"son\"."
      },
      {
        "question": "What is the pinyin for \"二\" (two)?",
        "options": [
          "duìbuqǐ",
          "èr",
          "Hànyǔ",
          "hěn"
        ],
        "answer": "èr",
        "explanation": "The pinyin for \"二\" is èr."
      },
      {
        "question": "Select the character for \"restaurant\":",
        "options": [
          "菜",
          "饭店",
          "多",
          "大"
        ],
        "answer": "饭店",
        "explanation": "\"饭店\" means restaurant."
      },
      {
        "question": "What is the meaning of \"飞机\"?",
        "options": [
          "airplane",
          "big",
          "son",
          "family/home"
        ],
        "answer": "airplane",
        "explanation": "\"飞机\" (fēijī) means \"airplane\"."
      },
      {
        "question": "What is the pinyin for \"分钟\" (minute)?",
        "options": [
          "diǎn",
          "hěn",
          "chūzūchē",
          "fēnzhōng"
        ],
        "answer": "fēnzhōng",
        "explanation": "The pinyin for \"分钟\" is fēnzhōng."
      },
      {
        "question": "Select the character for \"happy\":",
        "options": [
          "出租车",
          "杯子",
          "电影",
          "高兴"
        ],
        "answer": "高兴",
        "explanation": "\"高兴\" means happy."
      },
      {
        "question": "What is the meaning of \"个\"?",
        "options": [
          "movie",
          "cup",
          "measure word",
          "to be called"
        ],
        "answer": "measure word",
        "explanation": "\"个\" (gè) means \"measure word\"."
      },
      {
        "question": "What is the pinyin for \"工作\" (job/work)?",
        "options": [
          "gōngzuò",
          "fēnzhōng",
          "jiào",
          "hào"
        ],
        "answer": "gōngzuò",
        "explanation": "The pinyin for \"工作\" is gōngzuò."
      },
      {
        "question": "Select the character for \"dog\":",
        "options": [
          "狗",
          "九",
          "电影",
          "杯子"
        ],
        "answer": "狗",
        "explanation": "\"狗\" means dog."
      },
      {
        "question": "What is the meaning of \"汉语\"?",
        "options": [
          "many/much",
          "Chinese language",
          "minute",
          "sorry"
        ],
        "answer": "Chinese language",
        "explanation": "\"汉语\" (Hànyǔ) means \"Chinese language\"."
      },
      {
        "question": "What is the pinyin for \"好\" (good)?",
        "options": [
          "fàndiàn",
          "bā",
          "kàn",
          "hǎo"
        ],
        "answer": "hǎo",
        "explanation": "The pinyin for \"好\" is hǎo."
      },
      {
        "question": "Select the character for \"number/day of month\":",
        "options": [
          "号",
          "和",
          "吃",
          "电视"
        ],
        "answer": "号",
        "explanation": "\"号\" means number/day of month."
      },
      {
        "question": "What is the meaning of \"喝\"?",
        "options": [
          "measure word",
          "to drink",
          "number/day of month",
          "movie"
        ],
        "answer": "to drink",
        "explanation": "\"喝\" (hē) means \"to drink\"."
      },
      {
        "question": "What is the pinyin for \"和\" (and)?",
        "options": [
          "duō",
          "hé",
          "hǎo",
          "gǒu"
        ],
        "answer": "hé",
        "explanation": "The pinyin for \"和\" is hé."
      },
      {
        "question": "Select the character for \"sorry\":",
        "options": [
          "不",
          "菜",
          "开",
          "对不起"
        ],
        "answer": "对不起",
        "explanation": "\"对不起\" means sorry."
      },
      {
        "question": "Grammar Check: Location marker 在 (zài). Which sentence is grammatically correct based on '在 indicates location (at, in, on).'?",
        "options": [
          "我茶喝。",
          "吗你好？",
          "不我好。",
          "我在家。"
        ],
        "answer": "我在家。",
        "explanation": "在 indicates location (at, in, on). Example: 我在家。 (Wǒ zài jiā.)"
      },
      {
        "question": "Translate this grammar example to English: 我在家。",
        "options": [
          "This is a book.",
          "I am at home.",
          "Where are you?",
          "I don't know."
        ],
        "answer": "I am at home.",
        "explanation": "我在家。 means I am at home.."
      }
    ]
  },
  {
    "id": "hsk1_day18",
    "title": "Day 18: Vocabulary Range 290-306",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 18",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是很吗？",
          "py": "Nǐ hǎo! Zhè shì hěn ma?",
          "en": "Hello! Is this 很?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是后面。",
          "py": "Bú shì, zhè shì hòumiàn.",
          "en": "No, this is 后面."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道很在哪里吗？",
          "py": "Xièxie, nǐ zhīdào hěn zài nǎlǐ ma?",
          "en": "Thank you, do you know where 很 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢后面吗？",
          "py": "Hǎo de. Nǐ xǐhuān hòumiàn ma?",
          "en": "Okay. Do you like 后面?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"很\"?",
        "options": [
          "you're welcome",
          "to drink",
          "minute",
          "very"
        ],
        "answer": "very",
        "explanation": "\"很\" (hěn) means \"very\"."
      },
      {
        "question": "What is the pinyin for \"后面\" (behind)?",
        "options": [
          "fàndiàn",
          "fēijī",
          "hòumiàn",
          "bù"
        ],
        "answer": "hòumiàn",
        "explanation": "The pinyin for \"后面\" is hòumiàn."
      },
      {
        "question": "Select the character for \"to return\":",
        "options": [
          "饭店",
          "回",
          "大",
          "狗"
        ],
        "answer": "回",
        "explanation": "\"回\" means to return."
      },
      {
        "question": "What is the meaning of \"会\"?",
        "options": [
          "how much/many",
          "can/will",
          "to look/read",
          "big"
        ],
        "answer": "can/will",
        "explanation": "\"会\" (huì) means \"can/will\"."
      },
      {
        "question": "What is the pinyin for \"几\" (how many)?",
        "options": [
          "jīntiān",
          "jǐ",
          "fēijī",
          "gǒu"
        ],
        "answer": "jǐ",
        "explanation": "The pinyin for \"几\" is jǐ."
      },
      {
        "question": "Select the character for \"family/home\":",
        "options": [
          "回",
          "家",
          "分钟",
          "个"
        ],
        "answer": "家",
        "explanation": "\"家\" means family/home."
      },
      {
        "question": "What is the meaning of \"叫\"?",
        "options": [
          "Beijing",
          "to be called",
          "airplane",
          "you're welcome"
        ],
        "answer": "to be called",
        "explanation": "\"叫\" (jiào) means \"to be called\"."
      },
      {
        "question": "What is the pinyin for \"今天\" (today)?",
        "options": [
          "chī",
          "hē",
          "kàn",
          "jīntiān"
        ],
        "answer": "jīntiān",
        "explanation": "The pinyin for \"今天\" is jīntiān."
      },
      {
        "question": "Select the character for \"nine\":",
        "options": [
          "电脑",
          "今天",
          "本",
          "九"
        ],
        "answer": "九",
        "explanation": "\"九\" means nine."
      },
      {
        "question": "What is the meaning of \"开\"?",
        "options": [
          "to open/drive",
          "minute",
          "to drink",
          "sorry"
        ],
        "answer": "to open/drive",
        "explanation": "\"开\" (kāi) means \"to open/drive\"."
      },
      {
        "question": "What is the pinyin for \"看\" (to look/read)?",
        "options": [
          "huì",
          "diǎn",
          "kāi",
          "kàn"
        ],
        "answer": "kàn",
        "explanation": "The pinyin for \"看\" is kàn."
      },
      {
        "question": "Select the character for \"to love\":",
        "options": [
          "打电话",
          "爱",
          "后面",
          "工作"
        ],
        "answer": "爱",
        "explanation": "\"爱\" means to love."
      },
      {
        "question": "What is the meaning of \"八\"?",
        "options": [
          "good",
          "son",
          "to open/drive",
          "eight"
        ],
        "answer": "eight",
        "explanation": "\"八\" (bā) means \"eight\"."
      },
      {
        "question": "What is the pinyin for \"爸爸\" (father)?",
        "options": [
          "gōngzuò",
          "bàba",
          "èr",
          "huí"
        ],
        "answer": "bàba",
        "explanation": "The pinyin for \"爸爸\" is bàba."
      },
      {
        "question": "Select the character for \"cup\":",
        "options": [
          "本",
          "杯子",
          "家",
          "东西"
        ],
        "answer": "杯子",
        "explanation": "\"杯子\" means cup."
      },
      {
        "question": "What is the meaning of \"北京\"?",
        "options": [
          "and",
          "restaurant",
          "job/work",
          "Beijing"
        ],
        "answer": "Beijing",
        "explanation": "\"北京\" (Běijīng) means \"Beijing\"."
      },
      {
        "question": "What is the pinyin for \"本\" (measure word for books)?",
        "options": [
          "hǎo",
          "jīntiān",
          "běn",
          "duō"
        ],
        "answer": "běn",
        "explanation": "The pinyin for \"本\" is běn."
      },
      {
        "question": "Select the character for \"very\":",
        "options": [
          "很",
          "大",
          "家",
          "杯子"
        ],
        "answer": "很",
        "explanation": "\"很\" means very."
      },
      {
        "question": "Grammar Check: Verb 会 (huì) for ability. Which sentence is grammatically correct based on '会 means 'can' or 'know how to' for acquired skills.'?",
        "options": [
          "我茶喝。",
          "吗你好？",
          "不我好。",
          "我会说汉语。"
        ],
        "answer": "我会说汉语。",
        "explanation": "会 means 'can' or 'know how to' for acquired skills. Example: 我会说汉语。 (Wǒ huì shuō Hànyǔ.)"
      },
      {
        "question": "Translate this grammar example to English: 我会说汉语。",
        "options": [
          "I don't know.",
          "This is a book.",
          "I can speak Chinese.",
          "Where are you?"
        ],
        "answer": "I can speak Chinese.",
        "explanation": "我会说汉语。 means I can speak Chinese.."
      }
    ]
  },
  {
    "id": "hsk1_day19",
    "title": "Day 19: Vocabulary Range 307-323",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 19",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是不客气吗？",
          "py": "Nǐ hǎo! Zhè shì bú kèqi ma?",
          "en": "Hello! Is this 不客气?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是不。",
          "py": "Bú shì, zhè shì bù.",
          "en": "No, this is 不."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道不客气在哪里吗？",
          "py": "Xièxie, nǐ zhīdào bú kèqi zài nǎlǐ ma?",
          "en": "Thank you, do you know where 不客气 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢不吗？",
          "py": "Hǎo de. Nǐ xǐhuān bù ma?",
          "en": "Okay. Do you like 不?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"不客气\"?",
        "options": [
          "you're welcome",
          "possessive particle",
          "job/work",
          "how much/many"
        ],
        "answer": "you're welcome",
        "explanation": "\"不客气\" (bú kèqi) means \"you're welcome\"."
      },
      {
        "question": "What is the pinyin for \"不\" (not)?",
        "options": [
          "bù",
          "ài",
          "dǎ diànhuà",
          "fēnzhōng"
        ],
        "answer": "bù",
        "explanation": "The pinyin for \"不\" is bù."
      },
      {
        "question": "Select the character for \"dish/vegetable\":",
        "options": [
          "菜",
          "几",
          "看",
          "杯子"
        ],
        "answer": "菜",
        "explanation": "\"菜\" means dish/vegetable."
      },
      {
        "question": "What is the meaning of \"茶\"?",
        "options": [
          "not",
          "possessive particle",
          "airplane",
          "tea"
        ],
        "answer": "tea",
        "explanation": "\"茶\" (chá) means \"tea\"."
      },
      {
        "question": "What is the pinyin for \"吃\" (to eat)?",
        "options": [
          "jiǔ",
          "fēijī",
          "jīntiān",
          "chī"
        ],
        "answer": "chī",
        "explanation": "The pinyin for \"吃\" is chī."
      },
      {
        "question": "Select the character for \"taxi\":",
        "options": [
          "今天",
          "出租车",
          "工作",
          "儿子"
        ],
        "answer": "出租车",
        "explanation": "\"出租车\" means taxi."
      },
      {
        "question": "What is the meaning of \"打电话\"?",
        "options": [
          "to read",
          "Beijing",
          "can/will",
          "to make a phone call"
        ],
        "answer": "to make a phone call",
        "explanation": "\"打电话\" (dǎ diànhuà) means \"to make a phone call\"."
      },
      {
        "question": "What is the pinyin for \"大\" (big)?",
        "options": [
          "hào",
          "diànnǎo",
          "dà",
          "jiā"
        ],
        "answer": "dà",
        "explanation": "The pinyin for \"大\" is dà."
      },
      {
        "question": "Select the character for \"possessive particle\":",
        "options": [
          "和",
          "分钟",
          "都",
          "的"
        ],
        "answer": "的",
        "explanation": "\"的\" means possessive particle."
      },
      {
        "question": "What is the meaning of \"点\"?",
        "options": [
          "two",
          "how many",
          "o'clock / point",
          "Beijing"
        ],
        "answer": "o'clock / point",
        "explanation": "\"点\" (diǎn) means \"o'clock / point\"."
      },
      {
        "question": "What is the pinyin for \"电脑\" (computer)?",
        "options": [
          "dà",
          "duō",
          "jiǔ",
          "diànnǎo"
        ],
        "answer": "diànnǎo",
        "explanation": "The pinyin for \"电脑\" is diànnǎo."
      },
      {
        "question": "Select the character for \"television\":",
        "options": [
          "电脑",
          "汉语",
          "电视",
          "狗"
        ],
        "answer": "电视",
        "explanation": "\"电视\" means television."
      },
      {
        "question": "What is the meaning of \"电影\"?",
        "options": [
          "movie",
          "Chinese language",
          "two",
          "and"
        ],
        "answer": "movie",
        "explanation": "\"电影\" (diànyǐng) means \"movie\"."
      },
      {
        "question": "What is the pinyin for \"东西\" (thing)?",
        "options": [
          "bā",
          "bēizi",
          "dōngxi",
          "chá"
        ],
        "answer": "dōngxi",
        "explanation": "The pinyin for \"东西\" is dōngxi."
      },
      {
        "question": "Select the character for \"all/both\":",
        "options": [
          "后面",
          "对不起",
          "都",
          "本"
        ],
        "answer": "都",
        "explanation": "\"都\" means all/both."
      },
      {
        "question": "What is the meaning of \"读\"?",
        "options": [
          "minute",
          "to read",
          "happy",
          "nine"
        ],
        "answer": "to read",
        "explanation": "\"读\" (dú) means \"to read\"."
      },
      {
        "question": "What is the pinyin for \"对不起\" (sorry)?",
        "options": [
          "diànyǐng",
          "duìbuqǐ",
          "de",
          "gè"
        ],
        "answer": "duìbuqǐ",
        "explanation": "The pinyin for \"对不起\" is duìbuqǐ."
      },
      {
        "question": "Select the character for \"you're welcome\":",
        "options": [
          "今天",
          "二",
          "和",
          "不客气"
        ],
        "answer": "不客气",
        "explanation": "\"不客气\" means you're welcome."
      },
      {
        "question": "Grammar Check: Asking 'What' with 什么 (shénme). Which sentence is grammatically correct based on '什么 is used to ask 'what'.'?",
        "options": [
          "我茶喝。",
          "不我好。",
          "吗你好？",
          "这是什么？"
        ],
        "answer": "这是什么？",
        "explanation": "什么 is used to ask 'what'. Example: 这是什么？ (Zhè shì shénme?)"
      },
      {
        "question": "Translate this grammar example to English: 这是什么？",
        "options": [
          "This is a book.",
          "I don't know.",
          "Where are you?",
          "What is this?"
        ],
        "answer": "What is this?",
        "explanation": "这是什么？ means What is this?."
      }
    ]
  },
  {
    "id": "hsk1_day20",
    "title": "Day 20: Vocabulary Range 324-340",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 20",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是多吗？",
          "py": "Nǐ hǎo! Zhè shì duō ma?",
          "en": "Hello! Is this 多?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是多少。",
          "py": "Bú shì, zhè shì duōshao.",
          "en": "No, this is 多少."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道多在哪里吗？",
          "py": "Xièxie, nǐ zhīdào duō zài nǎlǐ ma?",
          "en": "Thank you, do you know where 多 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢多少吗？",
          "py": "Hǎo de. Nǐ xǐhuān duōshao ma?",
          "en": "Okay. Do you like 多少?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"多\"?",
        "options": [
          "many/much",
          "son",
          "minute",
          "thing"
        ],
        "answer": "many/much",
        "explanation": "\"多\" (duō) means \"many/much\"."
      },
      {
        "question": "What is the pinyin for \"多少\" (how much/many)?",
        "options": [
          "dà",
          "duō",
          "duōshao",
          "hē"
        ],
        "answer": "duōshao",
        "explanation": "The pinyin for \"多少\" is duōshao."
      },
      {
        "question": "Select the character for \"son\":",
        "options": [
          "儿子",
          "喝",
          "对不起",
          "不客气"
        ],
        "answer": "儿子",
        "explanation": "\"儿子\" means son."
      },
      {
        "question": "What is the meaning of \"二\"?",
        "options": [
          "to make a phone call",
          "family/home",
          "two",
          "not"
        ],
        "answer": "two",
        "explanation": "\"二\" (èr) means \"two\"."
      },
      {
        "question": "What is the pinyin for \"饭店\" (restaurant)?",
        "options": [
          "dǎ diànhuà",
          "diànyǐng",
          "fàndiàn",
          "dōu"
        ],
        "answer": "fàndiàn",
        "explanation": "The pinyin for \"饭店\" is fàndiàn."
      },
      {
        "question": "Select the character for \"airplane\":",
        "options": [
          "很",
          "出租车",
          "多少",
          "飞机"
        ],
        "answer": "飞机",
        "explanation": "\"飞机\" means airplane."
      },
      {
        "question": "What is the meaning of \"分钟\"?",
        "options": [
          "to make a phone call",
          "family/home",
          "very",
          "minute"
        ],
        "answer": "minute",
        "explanation": "\"分钟\" (fēnzhōng) means \"minute\"."
      },
      {
        "question": "What is the pinyin for \"高兴\" (happy)?",
        "options": [
          "kāi",
          "hào",
          "dú",
          "gāoxìng"
        ],
        "answer": "gāoxìng",
        "explanation": "The pinyin for \"高兴\" is gāoxìng."
      },
      {
        "question": "Select the character for \"measure word\":",
        "options": [
          "的",
          "吃",
          "个",
          "很"
        ],
        "answer": "个",
        "explanation": "\"个\" means measure word."
      },
      {
        "question": "What is the meaning of \"工作\"?",
        "options": [
          "Beijing",
          "tea",
          "cup",
          "job/work"
        ],
        "answer": "job/work",
        "explanation": "\"工作\" (gōngzuò) means \"job/work\"."
      },
      {
        "question": "What is the pinyin for \"狗\" (dog)?",
        "options": [
          "gǒu",
          "hǎo",
          "bā",
          "hào"
        ],
        "answer": "gǒu",
        "explanation": "The pinyin for \"狗\" is gǒu."
      },
      {
        "question": "Select the character for \"Chinese language\":",
        "options": [
          "汉语",
          "工作",
          "本",
          "分钟"
        ],
        "answer": "汉语",
        "explanation": "\"汉语\" means Chinese language."
      },
      {
        "question": "What is the meaning of \"好\"?",
        "options": [
          "good",
          "airplane",
          "dog",
          "measure word for books"
        ],
        "answer": "good",
        "explanation": "\"好\" (hǎo) means \"good\"."
      },
      {
        "question": "What is the pinyin for \"号\" (number/day of month)?",
        "options": [
          "hǎo",
          "hào",
          "hé",
          "huí"
        ],
        "answer": "hào",
        "explanation": "The pinyin for \"号\" is hào."
      },
      {
        "question": "Select the character for \"to drink\":",
        "options": [
          "喝",
          "后面",
          "今天",
          "狗"
        ],
        "answer": "喝",
        "explanation": "\"喝\" means to drink."
      },
      {
        "question": "What is the meaning of \"和\"?",
        "options": [
          "sorry",
          "and",
          "minute",
          "to return"
        ],
        "answer": "and",
        "explanation": "\"和\" (hé) means \"and\"."
      },
      {
        "question": "What is the pinyin for \"很\" (very)?",
        "options": [
          "diànyǐng",
          "hěn",
          "jīntiān",
          "de"
        ],
        "answer": "hěn",
        "explanation": "The pinyin for \"很\" is hěn."
      },
      {
        "question": "Select the character for \"many/much\":",
        "options": [
          "不",
          "东西",
          "多",
          "分钟"
        ],
        "answer": "多",
        "explanation": "\"多\" means many/much."
      },
      {
        "question": "Grammar Check: Subject-Verb-Object. Which sentence is grammatically correct based on 'The basic sentence structure.'?",
        "options": [
          "我喝茶。",
          "我茶喝。",
          "不我好。",
          "吗你好？"
        ],
        "answer": "我喝茶。",
        "explanation": "The basic sentence structure. Example: 我喝茶。 (Wǒ hē chá.)"
      },
      {
        "question": "Translate this grammar example to English: 我喝茶。",
        "options": [
          "This is a book.",
          "I don't know.",
          "Where are you?",
          "I drink tea."
        ],
        "answer": "I drink tea.",
        "explanation": "我喝茶。 means I drink tea.."
      }
    ]
  },
  {
    "id": "hsk1_day21",
    "title": "Day 21: Vocabulary Range 341-357",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 21",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是后面吗？",
          "py": "Nǐ hǎo! Zhè shì hòumiàn ma?",
          "en": "Hello! Is this 后面?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是回。",
          "py": "Bú shì, zhè shì huí.",
          "en": "No, this is 回."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道后面在哪里吗？",
          "py": "Xièxie, nǐ zhīdào hòumiàn zài nǎlǐ ma?",
          "en": "Thank you, do you know where 后面 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢回吗？",
          "py": "Hǎo de. Nǐ xǐhuān huí ma?",
          "en": "Okay. Do you like 回?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"后面\"?",
        "options": [
          "to open/drive",
          "today",
          "cup",
          "behind"
        ],
        "answer": "behind",
        "explanation": "\"后面\" (hòumiàn) means \"behind\"."
      },
      {
        "question": "What is the pinyin for \"回\" (to return)?",
        "options": [
          "jiā",
          "Hànyǔ",
          "gōngzuò",
          "huí"
        ],
        "answer": "huí",
        "explanation": "The pinyin for \"回\" is huí."
      },
      {
        "question": "Select the character for \"can/will\":",
        "options": [
          "点",
          "九",
          "东西",
          "会"
        ],
        "answer": "会",
        "explanation": "\"会\" means can/will."
      },
      {
        "question": "What is the meaning of \"几\"?",
        "options": [
          "all/both",
          "sorry",
          "how many",
          "behind"
        ],
        "answer": "how many",
        "explanation": "\"几\" (jǐ) means \"how many\"."
      },
      {
        "question": "What is the pinyin for \"家\" (family/home)?",
        "options": [
          "jīntiān",
          "jiā",
          "diǎn",
          "jiǔ"
        ],
        "answer": "jiā",
        "explanation": "The pinyin for \"家\" is jiā."
      },
      {
        "question": "Select the character for \"to be called\":",
        "options": [
          "开",
          "喝",
          "叫",
          "和"
        ],
        "answer": "叫",
        "explanation": "\"叫\" means to be called."
      },
      {
        "question": "What is the meaning of \"今天\"?",
        "options": [
          "to return",
          "job/work",
          "can/will",
          "today"
        ],
        "answer": "today",
        "explanation": "\"今天\" (jīntiān) means \"today\"."
      },
      {
        "question": "What is the pinyin for \"九\" (nine)?",
        "options": [
          "jiā",
          "de",
          "hěn",
          "jiǔ"
        ],
        "answer": "jiǔ",
        "explanation": "The pinyin for \"九\" is jiǔ."
      },
      {
        "question": "Select the character for \"to open/drive\":",
        "options": [
          "开",
          "汉语",
          "九",
          "八"
        ],
        "answer": "开",
        "explanation": "\"开\" means to open/drive."
      },
      {
        "question": "What is the meaning of \"看\"?",
        "options": [
          "all/both",
          "very",
          "restaurant",
          "to look/read"
        ],
        "answer": "to look/read",
        "explanation": "\"看\" (kàn) means \"to look/read\"."
      },
      {
        "question": "What is the pinyin for \"爱\" (to love)?",
        "options": [
          "èr",
          "jǐ",
          "ài",
          "jiào"
        ],
        "answer": "ài",
        "explanation": "The pinyin for \"爱\" is ài."
      },
      {
        "question": "Select the character for \"eight\":",
        "options": [
          "后面",
          "茶",
          "爱",
          "八"
        ],
        "answer": "八",
        "explanation": "\"八\" means eight."
      },
      {
        "question": "What is the meaning of \"爸爸\"?",
        "options": [
          "behind",
          "father",
          "happy",
          "to read"
        ],
        "answer": "father",
        "explanation": "\"爸爸\" (bàba) means \"father\"."
      },
      {
        "question": "What is the pinyin for \"杯子\" (cup)?",
        "options": [
          "bēizi",
          "hē",
          "duìbuqǐ",
          "cài"
        ],
        "answer": "bēizi",
        "explanation": "The pinyin for \"杯子\" is bēizi."
      },
      {
        "question": "Select the character for \"Beijing\":",
        "options": [
          "汉语",
          "爱",
          "高兴",
          "北京"
        ],
        "answer": "北京",
        "explanation": "\"北京\" means Beijing."
      },
      {
        "question": "What is the meaning of \"本\"?",
        "options": [
          "measure word for books",
          "airplane",
          "big",
          "today"
        ],
        "answer": "measure word for books",
        "explanation": "\"本\" (běn) means \"measure word for books\"."
      },
      {
        "question": "What is the pinyin for \"不客气\" (you're welcome)?",
        "options": [
          "huì",
          "hào",
          "bú kèqi",
          "dōngxi"
        ],
        "answer": "bú kèqi",
        "explanation": "The pinyin for \"不客气\" is bú kèqi."
      },
      {
        "question": "Select the character for \"behind\":",
        "options": [
          "九",
          "北京",
          "茶",
          "后面"
        ],
        "answer": "后面",
        "explanation": "\"后面\" means behind."
      },
      {
        "question": "Grammar Check: Question Particle 吗 (ma). Which sentence is grammatically correct based on 'Add 吗 at the end of a statement to make it a yes/no question.'?",
        "options": [
          "你好吗？",
          "不我好。",
          "吗你好？",
          "我茶喝。"
        ],
        "answer": "你好吗？",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question. Example: 你好吗？ (Nǐ hǎo ma?)"
      },
      {
        "question": "Translate this grammar example to English: 你好吗？",
        "options": [
          "This is a book.",
          "Are you good?",
          "Where are you?",
          "I don't know."
        ],
        "answer": "Are you good?",
        "explanation": "你好吗？ means Are you good?."
      }
    ]
  },
  {
    "id": "hsk1_day22",
    "title": "Day 22: Vocabulary Range 358-374",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 22",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是不吗？",
          "py": "Nǐ hǎo! Zhè shì bù ma?",
          "en": "Hello! Is this 不?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是菜。",
          "py": "Bú shì, zhè shì cài.",
          "en": "No, this is 菜."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道不在哪里吗？",
          "py": "Xièxie, nǐ zhīdào bù zài nǎlǐ ma?",
          "en": "Thank you, do you know where 不 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢菜吗？",
          "py": "Hǎo de. Nǐ xǐhuān cài ma?",
          "en": "Okay. Do you like 菜?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"不\"?",
        "options": [
          "to return",
          "not",
          "family/home",
          "computer"
        ],
        "answer": "not",
        "explanation": "\"不\" (bù) means \"not\"."
      },
      {
        "question": "What is the pinyin for \"菜\" (dish/vegetable)?",
        "options": [
          "duìbuqǐ",
          "kàn",
          "běn",
          "cài"
        ],
        "answer": "cài",
        "explanation": "The pinyin for \"菜\" is cài."
      },
      {
        "question": "Select the character for \"tea\":",
        "options": [
          "茶",
          "九",
          "狗",
          "大"
        ],
        "answer": "茶",
        "explanation": "\"茶\" means tea."
      },
      {
        "question": "What is the meaning of \"吃\"?",
        "options": [
          "to eat",
          "how much/many",
          "thing",
          "to be called"
        ],
        "answer": "to eat",
        "explanation": "\"吃\" (chī) means \"to eat\"."
      },
      {
        "question": "What is the pinyin for \"出租车\" (taxi)?",
        "options": [
          "jiào",
          "dǎ diànhuà",
          "chūzūchē",
          "kāi"
        ],
        "answer": "chūzūchē",
        "explanation": "The pinyin for \"出租车\" is chūzūchē."
      },
      {
        "question": "Select the character for \"to make a phone call\":",
        "options": [
          "东西",
          "打电话",
          "电影",
          "看"
        ],
        "answer": "打电话",
        "explanation": "\"打电话\" means to make a phone call."
      },
      {
        "question": "What is the meaning of \"大\"?",
        "options": [
          "big",
          "measure word for books",
          "how much/many",
          "o'clock / point"
        ],
        "answer": "big",
        "explanation": "\"大\" (dà) means \"big\"."
      },
      {
        "question": "What is the pinyin for \"的\" (possessive particle)?",
        "options": [
          "chūzūchē",
          "gè",
          "bàba",
          "de"
        ],
        "answer": "de",
        "explanation": "The pinyin for \"的\" is de."
      },
      {
        "question": "Select the character for \"o'clock / point\":",
        "options": [
          "汉语",
          "点",
          "电视",
          "几"
        ],
        "answer": "点",
        "explanation": "\"点\" means o'clock / point."
      },
      {
        "question": "What is the meaning of \"电脑\"?",
        "options": [
          "computer",
          "Chinese language",
          "number/day of month",
          "can/will"
        ],
        "answer": "computer",
        "explanation": "\"电脑\" (diànnǎo) means \"computer\"."
      },
      {
        "question": "What is the pinyin for \"电视\" (television)?",
        "options": [
          "duō",
          "cài",
          "gōngzuò",
          "diànshì"
        ],
        "answer": "diànshì",
        "explanation": "The pinyin for \"电视\" is diànshì."
      },
      {
        "question": "Select the character for \"movie\":",
        "options": [
          "工作",
          "电影",
          "家",
          "会"
        ],
        "answer": "电影",
        "explanation": "\"电影\" means movie."
      },
      {
        "question": "What is the meaning of \"东西\"?",
        "options": [
          "thing",
          "cup",
          "nine",
          "movie"
        ],
        "answer": "thing",
        "explanation": "\"东西\" (dōngxi) means \"thing\"."
      },
      {
        "question": "What is the pinyin for \"都\" (all/both)?",
        "options": [
          "dōu",
          "dà",
          "jiā",
          "èr"
        ],
        "answer": "dōu",
        "explanation": "The pinyin for \"都\" is dōu."
      },
      {
        "question": "Select the character for \"to read\":",
        "options": [
          "看",
          "对不起",
          "出租车",
          "读"
        ],
        "answer": "读",
        "explanation": "\"读\" means to read."
      },
      {
        "question": "What is the meaning of \"对不起\"?",
        "options": [
          "sorry",
          "Chinese language",
          "measure word",
          "to be called"
        ],
        "answer": "sorry",
        "explanation": "\"对不起\" (duìbuqǐ) means \"sorry\"."
      },
      {
        "question": "What is the pinyin for \"多\" (many/much)?",
        "options": [
          "diànshì",
          "dǎ diànhuà",
          "gāoxìng",
          "duō"
        ],
        "answer": "duō",
        "explanation": "The pinyin for \"多\" is duō."
      },
      {
        "question": "Select the character for \"not\":",
        "options": [
          "多少",
          "不",
          "高兴",
          "二"
        ],
        "answer": "不",
        "explanation": "\"不\" means not."
      },
      {
        "question": "Grammar Check: Negation with 不 (bù). Which sentence is grammatically correct based on 'Place 不 before the verb to negate it.'?",
        "options": [
          "不我好。",
          "我茶喝。",
          "我不去。",
          "吗你好？"
        ],
        "answer": "我不去。",
        "explanation": "Place 不 before the verb to negate it. Example: 我不去。 (Wǒ bú qù.)"
      },
      {
        "question": "Translate this grammar example to English: 我不去。",
        "options": [
          "I am not going.",
          "I don't know.",
          "This is a book.",
          "Where are you?"
        ],
        "answer": "I am not going.",
        "explanation": "我不去。 means I am not going.."
      }
    ]
  },
  {
    "id": "hsk1_day23",
    "title": "Day 23: Vocabulary Range 375-391",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Possessive particle 的 (de)",
        "explanation": "Use 的 to indicate possession, similar to 's in English.",
        "examples": [
          {
            "cn": "我的书",
            "py": "wǒ de shū",
            "en": "my book"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'my book'",
          "words": [
            "书",
            "的",
            "我"
          ],
          "answer": [
            "我",
            "的",
            "书"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 23",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是多少吗？",
          "py": "Nǐ hǎo! Zhè shì duōshao ma?",
          "en": "Hello! Is this 多少?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是儿子。",
          "py": "Bú shì, zhè shì érzi.",
          "en": "No, this is 儿子."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道多少在哪里吗？",
          "py": "Xièxie, nǐ zhīdào duōshao zài nǎlǐ ma?",
          "en": "Thank you, do you know where 多少 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢儿子吗？",
          "py": "Hǎo de. Nǐ xǐhuān érzi ma?",
          "en": "Okay. Do you like 儿子?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"多少\"?",
        "options": [
          "to look/read",
          "son",
          "happy",
          "how much/many"
        ],
        "answer": "how much/many",
        "explanation": "\"多少\" (duōshao) means \"how much/many\"."
      },
      {
        "question": "What is the pinyin for \"儿子\" (son)?",
        "options": [
          "diànyǐng",
          "dǎ diànhuà",
          "érzi",
          "hào"
        ],
        "answer": "érzi",
        "explanation": "The pinyin for \"儿子\" is érzi."
      },
      {
        "question": "Select the character for \"two\":",
        "options": [
          "会",
          "二",
          "多",
          "回"
        ],
        "answer": "二",
        "explanation": "\"二\" means two."
      },
      {
        "question": "What is the meaning of \"饭店\"?",
        "options": [
          "job/work",
          "to be called",
          "restaurant",
          "thing"
        ],
        "answer": "restaurant",
        "explanation": "\"饭店\" (fàndiàn) means \"restaurant\"."
      },
      {
        "question": "What is the pinyin for \"飞机\" (airplane)?",
        "options": [
          "fēijī",
          "chūzūchē",
          "běn",
          "hé"
        ],
        "answer": "fēijī",
        "explanation": "The pinyin for \"飞机\" is fēijī."
      },
      {
        "question": "Select the character for \"minute\":",
        "options": [
          "分钟",
          "东西",
          "北京",
          "好"
        ],
        "answer": "分钟",
        "explanation": "\"分钟\" means minute."
      },
      {
        "question": "What is the meaning of \"高兴\"?",
        "options": [
          "thing",
          "dish/vegetable",
          "good",
          "happy"
        ],
        "answer": "happy",
        "explanation": "\"高兴\" (gāoxìng) means \"happy\"."
      },
      {
        "question": "What is the pinyin for \"个\" (measure word)?",
        "options": [
          "chī",
          "diànyǐng",
          "gè",
          "hěn"
        ],
        "answer": "gè",
        "explanation": "The pinyin for \"个\" is gè."
      },
      {
        "question": "Select the character for \"job/work\":",
        "options": [
          "多",
          "高兴",
          "工作",
          "叫"
        ],
        "answer": "工作",
        "explanation": "\"工作\" means job/work."
      },
      {
        "question": "What is the meaning of \"狗\"?",
        "options": [
          "measure word for books",
          "behind",
          "to love",
          "dog"
        ],
        "answer": "dog",
        "explanation": "\"狗\" (gǒu) means \"dog\"."
      },
      {
        "question": "What is the pinyin for \"汉语\" (Chinese language)?",
        "options": [
          "gè",
          "diànnǎo",
          "Hànyǔ",
          "fēijī"
        ],
        "answer": "Hànyǔ",
        "explanation": "The pinyin for \"汉语\" is Hànyǔ."
      },
      {
        "question": "Select the character for \"good\":",
        "options": [
          "好",
          "电影",
          "茶",
          "多少"
        ],
        "answer": "好",
        "explanation": "\"好\" means good."
      },
      {
        "question": "What is the meaning of \"号\"?",
        "options": [
          "number/day of month",
          "to open/drive",
          "very",
          "behind"
        ],
        "answer": "number/day of month",
        "explanation": "\"号\" (hào) means \"number/day of month\"."
      },
      {
        "question": "What is the pinyin for \"喝\" (to drink)?",
        "options": [
          "diànnǎo",
          "hē",
          "kāi",
          "hòumiàn"
        ],
        "answer": "hē",
        "explanation": "The pinyin for \"喝\" is hē."
      },
      {
        "question": "Select the character for \"and\":",
        "options": [
          "汉语",
          "儿子",
          "和",
          "电影"
        ],
        "answer": "和",
        "explanation": "\"和\" means and."
      },
      {
        "question": "What is the meaning of \"很\"?",
        "options": [
          "tea",
          "very",
          "father",
          "big"
        ],
        "answer": "very",
        "explanation": "\"很\" (hěn) means \"very\"."
      },
      {
        "question": "What is the pinyin for \"后面\" (behind)?",
        "options": [
          "hěn",
          "fēijī",
          "hòumiàn",
          "diànshì"
        ],
        "answer": "hòumiàn",
        "explanation": "The pinyin for \"后面\" is hòumiàn."
      },
      {
        "question": "Select the character for \"how much/many\":",
        "options": [
          "多少",
          "点",
          "狗",
          "看"
        ],
        "answer": "多少",
        "explanation": "\"多少\" means how much/many."
      },
      {
        "question": "Grammar Check: Possessive particle 的 (de). Which sentence is grammatically correct based on 'Use 的 to indicate possession, similar to 's in English.'?",
        "options": [
          "我的书",
          "不我好。",
          "吗你好？",
          "我茶喝。"
        ],
        "answer": "我的书",
        "explanation": "Use 的 to indicate possession, similar to 's in English. Example: 我的书 (wǒ de shū)"
      },
      {
        "question": "Translate this grammar example to English: 我的书",
        "options": [
          "This is a book.",
          "Where are you?",
          "my book",
          "I don't know."
        ],
        "answer": "my book",
        "explanation": "我的书 means my book."
      }
    ]
  },
  {
    "id": "hsk1_day24",
    "title": "Day 24: Vocabulary Range 392-408",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Adverb 也 (yě)",
        "explanation": "也 means 'also' or 'too' and goes before the verb.",
        "examples": [
          {
            "cn": "我也去。",
            "py": "Wǒ yě qù.",
            "en": "I also go."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I also go.'",
          "words": [
            "去",
            "也",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "也",
            "去",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 24",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是回吗？",
          "py": "Nǐ hǎo! Zhè shì huí ma?",
          "en": "Hello! Is this 回?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是会。",
          "py": "Bú shì, zhè shì huì.",
          "en": "No, this is 会."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道回在哪里吗？",
          "py": "Xièxie, nǐ zhīdào huí zài nǎlǐ ma?",
          "en": "Thank you, do you know where 回 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢会吗？",
          "py": "Hǎo de. Nǐ xǐhuān huì ma?",
          "en": "Okay. Do you like 会?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"回\"?",
        "options": [
          "to return",
          "to open/drive",
          "good",
          "television"
        ],
        "answer": "to return",
        "explanation": "\"回\" (huí) means \"to return\"."
      },
      {
        "question": "What is the pinyin for \"会\" (can/will)?",
        "options": [
          "chī",
          "bú kèqi",
          "Běijīng",
          "huì"
        ],
        "answer": "huì",
        "explanation": "The pinyin for \"会\" is huì."
      },
      {
        "question": "Select the character for \"how many\":",
        "options": [
          "电视",
          "点",
          "和",
          "几"
        ],
        "answer": "几",
        "explanation": "\"几\" means how many."
      },
      {
        "question": "What is the meaning of \"家\"?",
        "options": [
          "behind",
          "job/work",
          "measure word for books",
          "family/home"
        ],
        "answer": "family/home",
        "explanation": "\"家\" (jiā) means \"family/home\"."
      },
      {
        "question": "What is the pinyin for \"叫\" (to be called)?",
        "options": [
          "jiào",
          "gāoxìng",
          "Hànyǔ",
          "hěn"
        ],
        "answer": "jiào",
        "explanation": "The pinyin for \"叫\" is jiào."
      },
      {
        "question": "Select the character for \"today\":",
        "options": [
          "开",
          "飞机",
          "今天",
          "茶"
        ],
        "answer": "今天",
        "explanation": "\"今天\" means today."
      },
      {
        "question": "What is the meaning of \"九\"?",
        "options": [
          "two",
          "nine",
          "to read",
          "possessive particle"
        ],
        "answer": "nine",
        "explanation": "\"九\" (jiǔ) means \"nine\"."
      },
      {
        "question": "What is the pinyin for \"开\" (to open/drive)?",
        "options": [
          "diǎn",
          "kāi",
          "bā",
          "cài"
        ],
        "answer": "kāi",
        "explanation": "The pinyin for \"开\" is kāi."
      },
      {
        "question": "Select the character for \"to look/read\":",
        "options": [
          "看",
          "好",
          "饭店",
          "的"
        ],
        "answer": "看",
        "explanation": "\"看\" means to look/read."
      },
      {
        "question": "What is the meaning of \"爱\"?",
        "options": [
          "cup",
          "to read",
          "today",
          "to love"
        ],
        "answer": "to love",
        "explanation": "\"爱\" (ài) means \"to love\"."
      },
      {
        "question": "What is the pinyin for \"八\" (eight)?",
        "options": [
          "dōngxi",
          "dǎ diànhuà",
          "diànnǎo",
          "bā"
        ],
        "answer": "bā",
        "explanation": "The pinyin for \"八\" is bā."
      },
      {
        "question": "Select the character for \"father\":",
        "options": [
          "叫",
          "出租车",
          "吃",
          "爸爸"
        ],
        "answer": "爸爸",
        "explanation": "\"爸爸\" means father."
      },
      {
        "question": "What is the meaning of \"杯子\"?",
        "options": [
          "airplane",
          "job/work",
          "cup",
          "restaurant"
        ],
        "answer": "cup",
        "explanation": "\"杯子\" (bēizi) means \"cup\"."
      },
      {
        "question": "What is the pinyin for \"北京\" (Beijing)?",
        "options": [
          "érzi",
          "gāoxìng",
          "Běijīng",
          "de"
        ],
        "answer": "Běijīng",
        "explanation": "The pinyin for \"北京\" is Běijīng."
      },
      {
        "question": "Select the character for \"measure word for books\":",
        "options": [
          "多",
          "叫",
          "吃",
          "本"
        ],
        "answer": "本",
        "explanation": "\"本\" means measure word for books."
      },
      {
        "question": "What is the meaning of \"不客气\"?",
        "options": [
          "you're welcome",
          "airplane",
          "to drink",
          "minute"
        ],
        "answer": "you're welcome",
        "explanation": "\"不客气\" (bú kèqi) means \"you're welcome\"."
      },
      {
        "question": "What is the pinyin for \"不\" (not)?",
        "options": [
          "běn",
          "bù",
          "dú",
          "gōngzuò"
        ],
        "answer": "bù",
        "explanation": "The pinyin for \"不\" is bù."
      },
      {
        "question": "Select the character for \"to return\":",
        "options": [
          "家",
          "出租车",
          "回",
          "不"
        ],
        "answer": "回",
        "explanation": "\"回\" means to return."
      },
      {
        "question": "Grammar Check: Adverb 也 (yě). Which sentence is grammatically correct based on '也 means 'also' or 'too' and goes before the verb.'?",
        "options": [
          "不我好。",
          "吗你好？",
          "我茶喝。",
          "我也去。"
        ],
        "answer": "我也去。",
        "explanation": "也 means 'also' or 'too' and goes before the verb. Example: 我也去。 (Wǒ yě qù.)"
      },
      {
        "question": "Translate this grammar example to English: 我也去。",
        "options": [
          "I also go.",
          "I don't know.",
          "This is a book.",
          "Where are you?"
        ],
        "answer": "I also go.",
        "explanation": "我也去。 means I also go.."
      }
    ]
  },
  {
    "id": "hsk1_day25",
    "title": "Day 25: Vocabulary Range 409-425",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      },
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Adverb 很 (hěn)",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'.",
        "examples": [
          {
            "cn": "我很好。",
            "py": "Wǒ hěn hǎo.",
            "en": "I am very good."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am very good.'",
          "words": [
            "好",
            "很",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "很",
            "好",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 25",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是菜吗？",
          "py": "Nǐ hǎo! Zhè shì cài ma?",
          "en": "Hello! Is this 菜?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是茶。",
          "py": "Bú shì, zhè shì chá.",
          "en": "No, this is 茶."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道菜在哪里吗？",
          "py": "Xièxie, nǐ zhīdào cài zài nǎlǐ ma?",
          "en": "Thank you, do you know where 菜 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢茶吗？",
          "py": "Hǎo de. Nǐ xǐhuān chá ma?",
          "en": "Okay. Do you like 茶?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"菜\"?",
        "options": [
          "can/will",
          "dish/vegetable",
          "measure word for books",
          "very"
        ],
        "answer": "dish/vegetable",
        "explanation": "\"菜\" (cài) means \"dish/vegetable\"."
      },
      {
        "question": "What is the pinyin for \"茶\" (tea)?",
        "options": [
          "èr",
          "bēizi",
          "bú kèqi",
          "chá"
        ],
        "answer": "chá",
        "explanation": "The pinyin for \"茶\" is chá."
      },
      {
        "question": "Select the character for \"to eat\":",
        "options": [
          "看",
          "吃",
          "几",
          "家"
        ],
        "answer": "吃",
        "explanation": "\"吃\" means to eat."
      },
      {
        "question": "What is the meaning of \"出租车\"?",
        "options": [
          "son",
          "family/home",
          "all/both",
          "taxi"
        ],
        "answer": "taxi",
        "explanation": "\"出租车\" (chūzūchē) means \"taxi\"."
      },
      {
        "question": "What is the pinyin for \"打电话\" (to make a phone call)?",
        "options": [
          "dōngxi",
          "dà",
          "gāoxìng",
          "dǎ diànhuà"
        ],
        "answer": "dǎ diànhuà",
        "explanation": "The pinyin for \"打电话\" is dǎ diànhuà."
      },
      {
        "question": "Select the character for \"big\":",
        "options": [
          "茶",
          "汉语",
          "大",
          "都"
        ],
        "answer": "大",
        "explanation": "\"大\" means big."
      },
      {
        "question": "What is the meaning of \"的\"?",
        "options": [
          "good",
          "possessive particle",
          "not",
          "how much/many"
        ],
        "answer": "possessive particle",
        "explanation": "\"的\" (de) means \"possessive particle\"."
      },
      {
        "question": "What is the pinyin for \"点\" (o'clock / point)?",
        "options": [
          "diǎn",
          "diànyǐng",
          "diànshì",
          "fàndiàn"
        ],
        "answer": "diǎn",
        "explanation": "The pinyin for \"点\" is diǎn."
      },
      {
        "question": "Select the character for \"computer\":",
        "options": [
          "本",
          "高兴",
          "电脑",
          "八"
        ],
        "answer": "电脑",
        "explanation": "\"电脑\" means computer."
      },
      {
        "question": "What is the meaning of \"电视\"?",
        "options": [
          "very",
          "restaurant",
          "television",
          "you're welcome"
        ],
        "answer": "television",
        "explanation": "\"电视\" (diànshì) means \"television\"."
      },
      {
        "question": "What is the pinyin for \"电影\" (movie)?",
        "options": [
          "bù",
          "diànyǐng",
          "jīntiān",
          "dǎ diànhuà"
        ],
        "answer": "diànyǐng",
        "explanation": "The pinyin for \"电影\" is diànyǐng."
      },
      {
        "question": "Select the character for \"thing\":",
        "options": [
          "飞机",
          "个",
          "吃",
          "东西"
        ],
        "answer": "东西",
        "explanation": "\"东西\" means thing."
      },
      {
        "question": "What is the meaning of \"都\"?",
        "options": [
          "minute",
          "restaurant",
          "good",
          "all/both"
        ],
        "answer": "all/both",
        "explanation": "\"都\" (dōu) means \"all/both\"."
      },
      {
        "question": "What is the pinyin for \"读\" (to read)?",
        "options": [
          "dōu",
          "dú",
          "érzi",
          "hǎo"
        ],
        "answer": "dú",
        "explanation": "The pinyin for \"读\" is dú."
      },
      {
        "question": "Select the character for \"sorry\":",
        "options": [
          "对不起",
          "电视",
          "九",
          "分钟"
        ],
        "answer": "对不起",
        "explanation": "\"对不起\" means sorry."
      },
      {
        "question": "What is the meaning of \"多\"?",
        "options": [
          "to make a phone call",
          "many/much",
          "son",
          "nine"
        ],
        "answer": "many/much",
        "explanation": "\"多\" (duō) means \"many/much\"."
      },
      {
        "question": "What is the pinyin for \"多少\" (how much/many)?",
        "options": [
          "de",
          "jǐ",
          "duōshao",
          "ài"
        ],
        "answer": "duōshao",
        "explanation": "The pinyin for \"多少\" is duōshao."
      },
      {
        "question": "Select the character for \"dish/vegetable\":",
        "options": [
          "菜",
          "分钟",
          "高兴",
          "电视"
        ],
        "answer": "菜",
        "explanation": "\"菜\" means dish/vegetable."
      },
      {
        "question": "Grammar Check: Adverb 很 (hěn). Which sentence is grammatically correct based on '很 means 'very' and is often used to link nouns to adjectives instead of 'is'.'?",
        "options": [
          "我茶喝。",
          "不我好。",
          "吗你好？",
          "我很好。"
        ],
        "answer": "我很好。",
        "explanation": "很 means 'very' and is often used to link nouns to adjectives instead of 'is'. Example: 我很好。 (Wǒ hěn hǎo.)"
      },
      {
        "question": "Translate this grammar example to English: 我很好。",
        "options": [
          "I don't know.",
          "I am very good.",
          "Where are you?",
          "This is a book."
        ],
        "answer": "I am very good.",
        "explanation": "我很好。 means I am very good.."
      }
    ]
  },
  {
    "id": "hsk1_day26",
    "title": "Day 26: Vocabulary Range 426-442",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      },
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Question Word 几 (jǐ)",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10.",
        "examples": [
          {
            "cn": "几个人？",
            "py": "Jǐ gè rén?",
            "en": "How many people?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'How many people?'",
          "words": [
            "人",
            "个",
            "几",
            "？"
          ],
          "answer": [
            "几",
            "个",
            "人",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 26",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是儿子吗？",
          "py": "Nǐ hǎo! Zhè shì érzi ma?",
          "en": "Hello! Is this 儿子?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是二。",
          "py": "Bú shì, zhè shì èr.",
          "en": "No, this is 二."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道儿子在哪里吗？",
          "py": "Xièxie, nǐ zhīdào érzi zài nǎlǐ ma?",
          "en": "Thank you, do you know where 儿子 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢二吗？",
          "py": "Hǎo de. Nǐ xǐhuān èr ma?",
          "en": "Okay. Do you like 二?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"儿子\"?",
        "options": [
          "to drink",
          "son",
          "dog",
          "cup"
        ],
        "answer": "son",
        "explanation": "\"儿子\" (érzi) means \"son\"."
      },
      {
        "question": "What is the pinyin for \"二\" (two)?",
        "options": [
          "èr",
          "hào",
          "běn",
          "Hànyǔ"
        ],
        "answer": "èr",
        "explanation": "The pinyin for \"二\" is èr."
      },
      {
        "question": "Select the character for \"restaurant\":",
        "options": [
          "饭店",
          "都",
          "好",
          "很"
        ],
        "answer": "饭店",
        "explanation": "\"饭店\" means restaurant."
      },
      {
        "question": "What is the meaning of \"飞机\"?",
        "options": [
          "how much/many",
          "thing",
          "airplane",
          "sorry"
        ],
        "answer": "airplane",
        "explanation": "\"飞机\" (fēijī) means \"airplane\"."
      },
      {
        "question": "What is the pinyin for \"分钟\" (minute)?",
        "options": [
          "huì",
          "duìbuqǐ",
          "dà",
          "fēnzhōng"
        ],
        "answer": "fēnzhōng",
        "explanation": "The pinyin for \"分钟\" is fēnzhōng."
      },
      {
        "question": "Select the character for \"happy\":",
        "options": [
          "的",
          "爸爸",
          "高兴",
          "好"
        ],
        "answer": "高兴",
        "explanation": "\"高兴\" means happy."
      },
      {
        "question": "What is the meaning of \"个\"?",
        "options": [
          "many/much",
          "Chinese language",
          "measure word",
          "good"
        ],
        "answer": "measure word",
        "explanation": "\"个\" (gè) means \"measure word\"."
      },
      {
        "question": "What is the pinyin for \"工作\" (job/work)?",
        "options": [
          "chī",
          "hé",
          "hǎo",
          "gōngzuò"
        ],
        "answer": "gōngzuò",
        "explanation": "The pinyin for \"工作\" is gōngzuò."
      },
      {
        "question": "Select the character for \"dog\":",
        "options": [
          "本",
          "今天",
          "叫",
          "狗"
        ],
        "answer": "狗",
        "explanation": "\"狗\" means dog."
      },
      {
        "question": "What is the meaning of \"汉语\"?",
        "options": [
          "behind",
          "to open/drive",
          "Chinese language",
          "to read"
        ],
        "answer": "Chinese language",
        "explanation": "\"汉语\" (Hànyǔ) means \"Chinese language\"."
      },
      {
        "question": "What is the pinyin for \"好\" (good)?",
        "options": [
          "dà",
          "jīntiān",
          "Hànyǔ",
          "hǎo"
        ],
        "answer": "hǎo",
        "explanation": "The pinyin for \"好\" is hǎo."
      },
      {
        "question": "Select the character for \"number/day of month\":",
        "options": [
          "个",
          "号",
          "电脑",
          "不客气"
        ],
        "answer": "号",
        "explanation": "\"号\" means number/day of month."
      },
      {
        "question": "What is the meaning of \"喝\"?",
        "options": [
          "father",
          "to drink",
          "today",
          "behind"
        ],
        "answer": "to drink",
        "explanation": "\"喝\" (hē) means \"to drink\"."
      },
      {
        "question": "What is the pinyin for \"和\" (and)?",
        "options": [
          "hé",
          "Běijīng",
          "chī",
          "ài"
        ],
        "answer": "hé",
        "explanation": "The pinyin for \"和\" is hé."
      },
      {
        "question": "Select the character for \"very\":",
        "options": [
          "爸爸",
          "很",
          "好",
          "二"
        ],
        "answer": "很",
        "explanation": "\"很\" means very."
      },
      {
        "question": "What is the meaning of \"后面\"?",
        "options": [
          "thing",
          "behind",
          "son",
          "dog"
        ],
        "answer": "behind",
        "explanation": "\"后面\" (hòumiàn) means \"behind\"."
      },
      {
        "question": "What is the pinyin for \"回\" (to return)?",
        "options": [
          "huí",
          "Hànyǔ",
          "běn",
          "diànshì"
        ],
        "answer": "huí",
        "explanation": "The pinyin for \"回\" is huí."
      },
      {
        "question": "Select the character for \"son\":",
        "options": [
          "菜",
          "二",
          "和",
          "儿子"
        ],
        "answer": "儿子",
        "explanation": "\"儿子\" means son."
      },
      {
        "question": "Grammar Check: Question Word 几 (jǐ). Which sentence is grammatically correct based on '几 is used to ask 'how many' for numbers typically under 10.'?",
        "options": [
          "不我好。",
          "吗你好？",
          "几个人？",
          "我茶喝。"
        ],
        "answer": "几个人？",
        "explanation": "几 is used to ask 'how many' for numbers typically under 10. Example: 几个人？ (Jǐ gè rén?)"
      },
      {
        "question": "Translate this grammar example to English: 几个人？",
        "options": [
          "How many people?",
          "I don't know.",
          "This is a book.",
          "Where are you?"
        ],
        "answer": "How many people?",
        "explanation": "几个人？ means How many people?."
      }
    ]
  },
  {
    "id": "hsk1_day27",
    "title": "Day 27: Vocabulary Range 443-459",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      },
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      },
      {
        "character": "爱",
        "pinyin": "ài",
        "meaning": "to love",
        "deconstruct": "爪 (claws) + 冖 (cover) + 心 (heart) + 友 (friend). True love involves the heart.",
        "exampleCn": "这是一个爱。",
        "examplePy": "Zhè shì yí gè ài.",
        "exampleEn": "This is a to love."
      },
      {
        "character": "八",
        "pinyin": "bā",
        "meaning": "eight",
        "deconstruct": "Represents division or separation, visually looks like dividing lines.",
        "exampleCn": "这是一个八。",
        "examplePy": "Zhè shì yí gè bā.",
        "exampleEn": "This is a eight."
      },
      {
        "character": "爸爸",
        "pinyin": "bàba",
        "meaning": "father",
        "deconstruct": "父 (Father) radical repeated. The top part represents hands holding an axe, symbolizing authority.",
        "exampleCn": "这是一个爸爸。",
        "examplePy": "Zhè shì yí gè bàba.",
        "exampleEn": "This is a father."
      },
      {
        "character": "杯子",
        "pinyin": "bēizi",
        "meaning": "cup",
        "deconstruct": "木 (Wood) + 不 (Not). Originally cups were made of wood.",
        "exampleCn": "这是一个杯子。",
        "examplePy": "Zhè shì yí gè bēizi.",
        "exampleEn": "This is a cup."
      },
      {
        "character": "北京",
        "pinyin": "Běijīng",
        "meaning": "Beijing",
        "deconstruct": "北 (North) + 京 (Capital). Literally 'Northern Capital'.",
        "exampleCn": "这是一个北京。",
        "examplePy": "Zhè shì yí gè Běijīng.",
        "exampleEn": "This is a Beijing."
      },
      {
        "character": "本",
        "pinyin": "běn",
        "meaning": "measure word for books",
        "deconstruct": "木 (tree) with a line at the base, indicating the root or foundation.",
        "exampleCn": "这是一个本。",
        "examplePy": "Zhè shì yí gè běn.",
        "exampleEn": "This is a measure word for books."
      },
      {
        "character": "不客气",
        "pinyin": "bú kèqi",
        "meaning": "you're welcome",
        "deconstruct": "不 (Not) + 客 (Guest) + 气 (Air/Spirit). Literally 'Don't be polite'.",
        "exampleCn": "这是一个不客气。",
        "examplePy": "Zhè shì yí gè bú kèqi.",
        "exampleEn": "This is a you're welcome."
      },
      {
        "character": "不",
        "pinyin": "bù",
        "meaning": "not",
        "deconstruct": "Represents a bird flying upwards, meaning 'no' or 'not' (phonetic borrowing).",
        "exampleCn": "这是一个不。",
        "examplePy": "Zhè shì yí gè bù.",
        "exampleEn": "This is a not."
      },
      {
        "character": "菜",
        "pinyin": "cài",
        "meaning": "dish/vegetable",
        "deconstruct": "艹 (Grass/Plant radical) + 采 (Pick). Plants you pick to eat.",
        "exampleCn": "这是一个菜。",
        "examplePy": "Zhè shì yí gè cài.",
        "exampleEn": "This is a dish/vegetable."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Location marker 在 (zài)",
        "explanation": "在 indicates location (at, in, on).",
        "examples": [
          {
            "cn": "我在家。",
            "py": "Wǒ zài jiā.",
            "en": "I am at home."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am at home.'",
          "words": [
            "家",
            "在",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "在",
            "家",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 27",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是会吗？",
          "py": "Nǐ hǎo! Zhè shì huì ma?",
          "en": "Hello! Is this 会?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是几。",
          "py": "Bú shì, zhè shì jǐ.",
          "en": "No, this is 几."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道会在哪里吗？",
          "py": "Xièxie, nǐ zhīdào huì zài nǎlǐ ma?",
          "en": "Thank you, do you know where 会 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢几吗？",
          "py": "Hǎo de. Nǐ xǐhuān jǐ ma?",
          "en": "Okay. Do you like 几?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"会\"?",
        "options": [
          "dish/vegetable",
          "can/will",
          "Beijing",
          "Chinese language"
        ],
        "answer": "can/will",
        "explanation": "\"会\" (huì) means \"can/will\"."
      },
      {
        "question": "What is the pinyin for \"几\" (how many)?",
        "options": [
          "gōngzuò",
          "Běijīng",
          "jǐ",
          "duōshao"
        ],
        "answer": "jǐ",
        "explanation": "The pinyin for \"几\" is jǐ."
      },
      {
        "question": "Select the character for \"family/home\":",
        "options": [
          "分钟",
          "后面",
          "家",
          "八"
        ],
        "answer": "家",
        "explanation": "\"家\" means family/home."
      },
      {
        "question": "What is the meaning of \"叫\"?",
        "options": [
          "thing",
          "to be called",
          "nine",
          "Chinese language"
        ],
        "answer": "to be called",
        "explanation": "\"叫\" (jiào) means \"to be called\"."
      },
      {
        "question": "What is the pinyin for \"今天\" (today)?",
        "options": [
          "diǎn",
          "hào",
          "jiào",
          "jīntiān"
        ],
        "answer": "jīntiān",
        "explanation": "The pinyin for \"今天\" is jīntiān."
      },
      {
        "question": "Select the character for \"nine\":",
        "options": [
          "电脑",
          "后面",
          "狗",
          "九"
        ],
        "answer": "九",
        "explanation": "\"九\" means nine."
      },
      {
        "question": "What is the meaning of \"开\"?",
        "options": [
          "to open/drive",
          "today",
          "and",
          "son"
        ],
        "answer": "to open/drive",
        "explanation": "\"开\" (kāi) means \"to open/drive\"."
      },
      {
        "question": "What is the pinyin for \"看\" (to look/read)?",
        "options": [
          "gāoxìng",
          "dǎ diànhuà",
          "kàn",
          "gǒu"
        ],
        "answer": "kàn",
        "explanation": "The pinyin for \"看\" is kàn."
      },
      {
        "question": "Select the character for \"to love\":",
        "options": [
          "电脑",
          "点",
          "爱",
          "本"
        ],
        "answer": "爱",
        "explanation": "\"爱\" means to love."
      },
      {
        "question": "What is the meaning of \"八\"?",
        "options": [
          "eight",
          "Beijing",
          "to love",
          "father"
        ],
        "answer": "eight",
        "explanation": "\"八\" (bā) means \"eight\"."
      },
      {
        "question": "What is the pinyin for \"爸爸\" (father)?",
        "options": [
          "fēijī",
          "bàba",
          "jīntiān",
          "dà"
        ],
        "answer": "bàba",
        "explanation": "The pinyin for \"爸爸\" is bàba."
      },
      {
        "question": "Select the character for \"cup\":",
        "options": [
          "杯子",
          "茶",
          "北京",
          "很"
        ],
        "answer": "杯子",
        "explanation": "\"杯子\" means cup."
      },
      {
        "question": "What is the meaning of \"北京\"?",
        "options": [
          "to make a phone call",
          "Beijing",
          "how many",
          "job/work"
        ],
        "answer": "Beijing",
        "explanation": "\"北京\" (Běijīng) means \"Beijing\"."
      },
      {
        "question": "What is the pinyin for \"本\" (measure word for books)?",
        "options": [
          "fēijī",
          "chūzūchē",
          "běn",
          "érzi"
        ],
        "answer": "běn",
        "explanation": "The pinyin for \"本\" is běn."
      },
      {
        "question": "Select the character for \"you're welcome\":",
        "options": [
          "吃",
          "喝",
          "回",
          "不客气"
        ],
        "answer": "不客气",
        "explanation": "\"不客气\" means you're welcome."
      },
      {
        "question": "What is the meaning of \"不\"?",
        "options": [
          "not",
          "airplane",
          "to make a phone call",
          "thing"
        ],
        "answer": "not",
        "explanation": "\"不\" (bù) means \"not\"."
      },
      {
        "question": "What is the pinyin for \"菜\" (dish/vegetable)?",
        "options": [
          "chūzūchē",
          "jiǔ",
          "huí",
          "cài"
        ],
        "answer": "cài",
        "explanation": "The pinyin for \"菜\" is cài."
      },
      {
        "question": "Select the character for \"can/will\":",
        "options": [
          "会",
          "东西",
          "儿子",
          "杯子"
        ],
        "answer": "会",
        "explanation": "\"会\" means can/will."
      },
      {
        "question": "Grammar Check: Location marker 在 (zài). Which sentence is grammatically correct based on '在 indicates location (at, in, on).'?",
        "options": [
          "不我好。",
          "吗你好？",
          "我茶喝。",
          "我在家。"
        ],
        "answer": "我在家。",
        "explanation": "在 indicates location (at, in, on). Example: 我在家。 (Wǒ zài jiā.)"
      },
      {
        "question": "Translate this grammar example to English: 我在家。",
        "options": [
          "Where are you?",
          "I don't know.",
          "This is a book.",
          "I am at home."
        ],
        "answer": "I am at home.",
        "explanation": "我在家。 means I am at home.."
      }
    ]
  },
  {
    "id": "hsk1_day28",
    "title": "Day 28: Vocabulary Range 460-476",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "茶",
        "pinyin": "chá",
        "meaning": "tea",
        "deconstruct": "艹 (Plant) + 人 (Person) + 木 (Wood). A person picking plants from trees.",
        "exampleCn": "这是一个茶。",
        "examplePy": "Zhè shì yí gè chá.",
        "exampleEn": "This is a tea."
      },
      {
        "character": "吃",
        "pinyin": "chī",
        "meaning": "to eat",
        "deconstruct": "口 (Mouth) + 乞 (Beg). Using the mouth.",
        "exampleCn": "这是一个吃。",
        "examplePy": "Zhè shì yí gè chī.",
        "exampleEn": "This is a to eat."
      },
      {
        "character": "出租车",
        "pinyin": "chūzūchē",
        "meaning": "taxi",
        "deconstruct": "出 (Out) + 租 (Rent) + 车 (Car). A car rented out.",
        "exampleCn": "这是一个出租车。",
        "examplePy": "Zhè shì yí gè chūzūchē.",
        "exampleEn": "This is a taxi."
      },
      {
        "character": "打电话",
        "pinyin": "dǎ diànhuà",
        "meaning": "to make a phone call",
        "deconstruct": "打 (Hit/Beat) + 电 (Electric) + 话 (Speech).",
        "exampleCn": "这是一个打电话。",
        "examplePy": "Zhè shì yí gè dǎ diànhuà.",
        "exampleEn": "This is a to make a phone call."
      },
      {
        "character": "大",
        "pinyin": "dà",
        "meaning": "big",
        "deconstruct": "A person (人) stretching out their arms, representing something large.",
        "exampleCn": "这是一个大。",
        "examplePy": "Zhè shì yí gè dà.",
        "exampleEn": "This is a big."
      },
      {
        "character": "的",
        "pinyin": "de",
        "meaning": "possessive particle",
        "deconstruct": "白 (White) + 勺 (Spoon). Used structurally.",
        "exampleCn": "这是一个的。",
        "examplePy": "Zhè shì yí gè de.",
        "exampleEn": "This is a possessive particle."
      },
      {
        "character": "点",
        "pinyin": "diǎn",
        "meaning": "o'clock / point",
        "deconstruct": "黑 (Black) over four dots (Fire). Meaning a small speck or point.",
        "exampleCn": "这是一个点。",
        "examplePy": "Zhè shì yí gè diǎn.",
        "exampleEn": "This is a o'clock / point."
      },
      {
        "character": "电脑",
        "pinyin": "diànnǎo",
        "meaning": "computer",
        "deconstruct": "电 (Electric) + 脑 (Brain). Literally 'Electric brain'.",
        "exampleCn": "这是一个电脑。",
        "examplePy": "Zhè shì yí gè diànnǎo.",
        "exampleEn": "This is a computer."
      },
      {
        "character": "电视",
        "pinyin": "diànshì",
        "meaning": "television",
        "deconstruct": "电 (Electric) + 视 (Look/See).",
        "exampleCn": "这是一个电视。",
        "examplePy": "Zhè shì yí gè diànshì.",
        "exampleEn": "This is a television."
      },
      {
        "character": "电影",
        "pinyin": "diànyǐng",
        "meaning": "movie",
        "deconstruct": "电 (Electric) + 影 (Shadow/Image). Electric shadow.",
        "exampleCn": "这是一个电影。",
        "examplePy": "Zhè shì yí gè diànyǐng.",
        "exampleEn": "This is a movie."
      },
      {
        "character": "东西",
        "pinyin": "dōngxi",
        "meaning": "thing",
        "deconstruct": "东 (East) + 西 (West). Things from everywhere.",
        "exampleCn": "这是一个东西。",
        "examplePy": "Zhè shì yí gè dōngxi.",
        "exampleEn": "This is a thing."
      },
      {
        "character": "都",
        "pinyin": "dōu",
        "meaning": "all/both",
        "deconstruct": "者 (Person) + 阝 (City). All the people in the city.",
        "exampleCn": "这是一个都。",
        "examplePy": "Zhè shì yí gè dōu.",
        "exampleEn": "This is a all/both."
      },
      {
        "character": "读",
        "pinyin": "dú",
        "meaning": "to read",
        "deconstruct": "讠 (Speech) + 卖 (Sell). Reading words aloud.",
        "exampleCn": "这是一个读。",
        "examplePy": "Zhè shì yí gè dú.",
        "exampleEn": "This is a to read."
      },
      {
        "character": "对不起",
        "pinyin": "duìbuqǐ",
        "meaning": "sorry",
        "deconstruct": "Literally 'Cannot face up to'.",
        "exampleCn": "这是一个对不起。",
        "examplePy": "Zhè shì yí gè duìbuqǐ.",
        "exampleEn": "This is a sorry."
      },
      {
        "character": "多",
        "pinyin": "duō",
        "meaning": "many/much",
        "deconstruct": "夕 (Evening) stacked twice. Evening after evening means many.",
        "exampleCn": "这是一个多。",
        "examplePy": "Zhè shì yí gè duō.",
        "exampleEn": "This is a many/much."
      },
      {
        "character": "多少",
        "pinyin": "duōshao",
        "meaning": "how much/many",
        "deconstruct": "多 (Many) + 少 (Few).",
        "exampleCn": "这是一个多少。",
        "examplePy": "Zhè shì yí gè duōshao.",
        "exampleEn": "This is a how much/many."
      },
      {
        "character": "儿子",
        "pinyin": "érzi",
        "meaning": "son",
        "deconstruct": "儿 (Child) + 子 (Child/Seed).",
        "exampleCn": "这是一个儿子。",
        "examplePy": "Zhè shì yí gè érzi.",
        "exampleEn": "This is a son."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Verb 会 (huì) for ability",
        "explanation": "会 means 'can' or 'know how to' for acquired skills.",
        "examples": [
          {
            "cn": "我会说汉语。",
            "py": "Wǒ huì shuō Hànyǔ.",
            "en": "I can speak Chinese."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I can speak Chinese.'",
          "words": [
            "汉语",
            "说",
            "会",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "会",
            "说",
            "汉语",
            "。"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 28",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是茶吗？",
          "py": "Nǐ hǎo! Zhè shì chá ma?",
          "en": "Hello! Is this 茶?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是吃。",
          "py": "Bú shì, zhè shì chī.",
          "en": "No, this is 吃."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道茶在哪里吗？",
          "py": "Xièxie, nǐ zhīdào chá zài nǎlǐ ma?",
          "en": "Thank you, do you know where 茶 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢吃吗？",
          "py": "Hǎo de. Nǐ xǐhuān chī ma?",
          "en": "Okay. Do you like 吃?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"茶\"?",
        "options": [
          "television",
          "taxi",
          "tea",
          "to eat"
        ],
        "answer": "tea",
        "explanation": "\"茶\" (chá) means \"tea\"."
      },
      {
        "question": "What is the pinyin for \"吃\" (to eat)?",
        "options": [
          "chī",
          "fàndiàn",
          "chūzūchē",
          "Hànyǔ"
        ],
        "answer": "chī",
        "explanation": "The pinyin for \"吃\" is chī."
      },
      {
        "question": "Select the character for \"taxi\":",
        "options": [
          "看",
          "叫",
          "出租车",
          "电脑"
        ],
        "answer": "出租车",
        "explanation": "\"出租车\" means taxi."
      },
      {
        "question": "What is the meaning of \"打电话\"?",
        "options": [
          "to make a phone call",
          "movie",
          "to be called",
          "all/both"
        ],
        "answer": "to make a phone call",
        "explanation": "\"打电话\" (dǎ diànhuà) means \"to make a phone call\"."
      },
      {
        "question": "What is the pinyin for \"大\" (big)?",
        "options": [
          "bēizi",
          "jǐ",
          "dà",
          "bù"
        ],
        "answer": "dà",
        "explanation": "The pinyin for \"大\" is dà."
      },
      {
        "question": "Select the character for \"possessive particle\":",
        "options": [
          "工作",
          "回",
          "后面",
          "的"
        ],
        "answer": "的",
        "explanation": "\"的\" means possessive particle."
      },
      {
        "question": "What is the meaning of \"点\"?",
        "options": [
          "to drink",
          "o'clock / point",
          "to look/read",
          "all/both"
        ],
        "answer": "o'clock / point",
        "explanation": "\"点\" (diǎn) means \"o'clock / point\"."
      },
      {
        "question": "What is the pinyin for \"电脑\" (computer)?",
        "options": [
          "gǒu",
          "diǎn",
          "diànnǎo",
          "duōshao"
        ],
        "answer": "diànnǎo",
        "explanation": "The pinyin for \"电脑\" is diànnǎo."
      },
      {
        "question": "Select the character for \"television\":",
        "options": [
          "儿子",
          "读",
          "菜",
          "电视"
        ],
        "answer": "电视",
        "explanation": "\"电视\" means television."
      },
      {
        "question": "What is the meaning of \"电影\"?",
        "options": [
          "to return",
          "to be called",
          "to love",
          "movie"
        ],
        "answer": "movie",
        "explanation": "\"电影\" (diànyǐng) means \"movie\"."
      },
      {
        "question": "What is the pinyin for \"东西\" (thing)?",
        "options": [
          "fàndiàn",
          "dōngxi",
          "jiào",
          "huí"
        ],
        "answer": "dōngxi",
        "explanation": "The pinyin for \"东西\" is dōngxi."
      },
      {
        "question": "Select the character for \"all/both\":",
        "options": [
          "都",
          "打电话",
          "出租车",
          "家"
        ],
        "answer": "都",
        "explanation": "\"都\" means all/both."
      },
      {
        "question": "What is the meaning of \"读\"?",
        "options": [
          "to read",
          "nine",
          "all/both",
          "dish/vegetable"
        ],
        "answer": "to read",
        "explanation": "\"读\" (dú) means \"to read\"."
      },
      {
        "question": "What is the pinyin for \"对不起\" (sorry)?",
        "options": [
          "huì",
          "duìbuqǐ",
          "chá",
          "kāi"
        ],
        "answer": "duìbuqǐ",
        "explanation": "The pinyin for \"对不起\" is duìbuqǐ."
      },
      {
        "question": "Select the character for \"many/much\":",
        "options": [
          "多",
          "家",
          "会",
          "出租车"
        ],
        "answer": "多",
        "explanation": "\"多\" means many/much."
      },
      {
        "question": "What is the meaning of \"多少\"?",
        "options": [
          "how much/many",
          "dog",
          "to return",
          "computer"
        ],
        "answer": "how much/many",
        "explanation": "\"多少\" (duōshao) means \"how much/many\"."
      },
      {
        "question": "What is the pinyin for \"儿子\" (son)?",
        "options": [
          "érzi",
          "fēijī",
          "bú kèqi",
          "huí"
        ],
        "answer": "érzi",
        "explanation": "The pinyin for \"儿子\" is érzi."
      },
      {
        "question": "Select the character for \"tea\":",
        "options": [
          "飞机",
          "东西",
          "茶",
          "读"
        ],
        "answer": "茶",
        "explanation": "\"茶\" means tea."
      },
      {
        "question": "Grammar Check: Verb 会 (huì) for ability. Which sentence is grammatically correct based on '会 means 'can' or 'know how to' for acquired skills.'?",
        "options": [
          "我会说汉语。",
          "吗你好？",
          "我茶喝。",
          "不我好。"
        ],
        "answer": "我会说汉语。",
        "explanation": "会 means 'can' or 'know how to' for acquired skills. Example: 我会说汉语。 (Wǒ huì shuō Hànyǔ.)"
      },
      {
        "question": "Translate this grammar example to English: 我会说汉语。",
        "options": [
          "I don't know.",
          "I can speak Chinese.",
          "Where are you?",
          "This is a book."
        ],
        "answer": "I can speak Chinese.",
        "explanation": "我会说汉语。 means I can speak Chinese.."
      }
    ]
  },
  {
    "id": "hsk1_day29",
    "title": "Day 29: Vocabulary Range 477-493",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "二",
        "pinyin": "èr",
        "meaning": "two",
        "deconstruct": "Two horizontal lines.",
        "exampleCn": "这是一个二。",
        "examplePy": "Zhè shì yí gè èr.",
        "exampleEn": "This is a two."
      },
      {
        "character": "饭店",
        "pinyin": "fàndiàn",
        "meaning": "restaurant",
        "deconstruct": "饭 (Rice/Meal) + 店 (Shop).",
        "exampleCn": "这是一个饭店。",
        "examplePy": "Zhè shì yí gè fàndiàn.",
        "exampleEn": "This is a restaurant."
      },
      {
        "character": "飞机",
        "pinyin": "fēijī",
        "meaning": "airplane",
        "deconstruct": "飞 (Fly) + 机 (Machine). Flying machine.",
        "exampleCn": "这是一个飞机。",
        "examplePy": "Zhè shì yí gè fēijī.",
        "exampleEn": "This is a airplane."
      },
      {
        "character": "分钟",
        "pinyin": "fēnzhōng",
        "meaning": "minute",
        "deconstruct": "分 (Divide/Minute) + 钟 (Clock/Bell).",
        "exampleCn": "这是一个分钟。",
        "examplePy": "Zhè shì yí gè fēnzhōng.",
        "exampleEn": "This is a minute."
      },
      {
        "character": "高兴",
        "pinyin": "gāoxìng",
        "meaning": "happy",
        "deconstruct": "高 (Tall/High) + 兴 (Excitement). High spirits.",
        "exampleCn": "这是一个高兴。",
        "examplePy": "Zhè shì yí gè gāoxìng.",
        "exampleEn": "This is a happy."
      },
      {
        "character": "个",
        "pinyin": "gè",
        "meaning": "measure word",
        "deconstruct": "人 (Person) + ｜ (Vertical line). A single unit.",
        "exampleCn": "这是一个个。",
        "examplePy": "Zhè shì yí gè gè.",
        "exampleEn": "This is a measure word."
      },
      {
        "character": "工作",
        "pinyin": "gōngzuò",
        "meaning": "job/work",
        "deconstruct": "工 (Work/Labor) + 作 (Make/Do).",
        "exampleCn": "这是一个工作。",
        "examplePy": "Zhè shì yí gè gōngzuò.",
        "exampleEn": "This is a job/work."
      },
      {
        "character": "狗",
        "pinyin": "gǒu",
        "meaning": "dog",
        "deconstruct": "犭 (Animal radical) + 句 (Phrase).",
        "exampleCn": "这是一个狗。",
        "examplePy": "Zhè shì yí gè gǒu.",
        "exampleEn": "This is a dog."
      },
      {
        "character": "汉语",
        "pinyin": "Hànyǔ",
        "meaning": "Chinese language",
        "deconstruct": "汉 (Han people) + 语 (Language).",
        "exampleCn": "这是一个汉语。",
        "examplePy": "Zhè shì yí gè Hànyǔ.",
        "exampleEn": "This is a Chinese language."
      },
      {
        "character": "好",
        "pinyin": "hǎo",
        "meaning": "good",
        "deconstruct": "女 (Woman) + 子 (Child). A woman with a child is a good thing.",
        "exampleCn": "这是一个好。",
        "examplePy": "Zhè shì yí gè hǎo.",
        "exampleEn": "This is a good."
      },
      {
        "character": "号",
        "pinyin": "hào",
        "meaning": "number/day of month",
        "deconstruct": "口 (Mouth) + 丂 (Breath). Calling out a number.",
        "exampleCn": "这是一个号。",
        "examplePy": "Zhè shì yí gè hào.",
        "exampleEn": "This is a number/day of month."
      },
      {
        "character": "喝",
        "pinyin": "hē",
        "meaning": "to drink",
        "deconstruct": "口 (Mouth) + 曷. Drinking requires the mouth.",
        "exampleCn": "这是一个喝。",
        "examplePy": "Zhè shì yí gè hē.",
        "exampleEn": "This is a to drink."
      },
      {
        "character": "和",
        "pinyin": "hé",
        "meaning": "and",
        "deconstruct": "禾 (Grain) + 口 (Mouth). Eating grain together signifies harmony and connection.",
        "exampleCn": "这是一个和。",
        "examplePy": "Zhè shì yí gè hé.",
        "exampleEn": "This is a and."
      },
      {
        "character": "很",
        "pinyin": "hěn",
        "meaning": "very",
        "deconstruct": "彳 (Step) + 艮 (Tough). Taking a tough step.",
        "exampleCn": "这是一个很。",
        "examplePy": "Zhè shì yí gè hěn.",
        "exampleEn": "This is a very."
      },
      {
        "character": "后面",
        "pinyin": "hòumiàn",
        "meaning": "behind",
        "deconstruct": "后 (Behind/Empress) + 面 (Face/Side).",
        "exampleCn": "这是一个后面。",
        "examplePy": "Zhè shì yí gè hòumiàn.",
        "exampleEn": "This is a behind."
      },
      {
        "character": "回",
        "pinyin": "huí",
        "meaning": "to return",
        "deconstruct": "A circle within a circle, representing returning to the center.",
        "exampleCn": "这是一个回。",
        "examplePy": "Zhè shì yí gè huí.",
        "exampleEn": "This is a to return."
      },
      {
        "character": "会",
        "pinyin": "huì",
        "meaning": "can/will",
        "deconstruct": "人 (Person) + 云 (Cloud). People gathering.",
        "exampleCn": "这是一个会。",
        "examplePy": "Zhè shì yí gè huì.",
        "exampleEn": "This is a can/will."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Asking 'What' with 什么 (shénme)",
        "explanation": "什么 is used to ask 'what'.",
        "examples": [
          {
            "cn": "这是什么？",
            "py": "Zhè shì shénme?",
            "en": "What is this?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'What is this?'",
          "words": [
            "什么",
            "是",
            "这",
            "？"
          ],
          "answer": [
            "这",
            "是",
            "什么",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 29",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是二吗？",
          "py": "Nǐ hǎo! Zhè shì èr ma?",
          "en": "Hello! Is this 二?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是饭店。",
          "py": "Bú shì, zhè shì fàndiàn.",
          "en": "No, this is 饭店."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道二在哪里吗？",
          "py": "Xièxie, nǐ zhīdào èr zài nǎlǐ ma?",
          "en": "Thank you, do you know where 二 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢饭店吗？",
          "py": "Hǎo de. Nǐ xǐhuān fàndiàn ma?",
          "en": "Okay. Do you like 饭店?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"二\"?",
        "options": [
          "to return",
          "two",
          "job/work",
          "and"
        ],
        "answer": "two",
        "explanation": "\"二\" (èr) means \"two\"."
      },
      {
        "question": "What is the pinyin for \"饭店\" (restaurant)?",
        "options": [
          "cài",
          "Běijīng",
          "gāoxìng",
          "fàndiàn"
        ],
        "answer": "fàndiàn",
        "explanation": "The pinyin for \"饭店\" is fàndiàn."
      },
      {
        "question": "Select the character for \"airplane\":",
        "options": [
          "飞机",
          "都",
          "个",
          "看"
        ],
        "answer": "飞机",
        "explanation": "\"飞机\" means airplane."
      },
      {
        "question": "What is the meaning of \"分钟\"?",
        "options": [
          "minute",
          "job/work",
          "taxi",
          "behind"
        ],
        "answer": "minute",
        "explanation": "\"分钟\" (fēnzhōng) means \"minute\"."
      },
      {
        "question": "What is the pinyin for \"高兴\" (happy)?",
        "options": [
          "chī",
          "diànyǐng",
          "hěn",
          "gāoxìng"
        ],
        "answer": "gāoxìng",
        "explanation": "The pinyin for \"高兴\" is gāoxìng."
      },
      {
        "question": "Select the character for \"measure word\":",
        "options": [
          "今天",
          "北京",
          "个",
          "高兴"
        ],
        "answer": "个",
        "explanation": "\"个\" means measure word."
      },
      {
        "question": "What is the meaning of \"工作\"?",
        "options": [
          "eight",
          "job/work",
          "minute",
          "tea"
        ],
        "answer": "job/work",
        "explanation": "\"工作\" (gōngzuò) means \"job/work\"."
      },
      {
        "question": "What is the pinyin for \"狗\" (dog)?",
        "options": [
          "diànyǐng",
          "kàn",
          "gǒu",
          "chī"
        ],
        "answer": "gǒu",
        "explanation": "The pinyin for \"狗\" is gǒu."
      },
      {
        "question": "Select the character for \"Chinese language\":",
        "options": [
          "汉语",
          "不",
          "多",
          "今天"
        ],
        "answer": "汉语",
        "explanation": "\"汉语\" means Chinese language."
      },
      {
        "question": "What is the meaning of \"好\"?",
        "options": [
          "to drink",
          "restaurant",
          "to read",
          "good"
        ],
        "answer": "good",
        "explanation": "\"好\" (hǎo) means \"good\"."
      },
      {
        "question": "What is the pinyin for \"号\" (number/day of month)?",
        "options": [
          "bù",
          "hào",
          "bēizi",
          "diànshì"
        ],
        "answer": "hào",
        "explanation": "The pinyin for \"号\" is hào."
      },
      {
        "question": "Select the character for \"to drink\":",
        "options": [
          "的",
          "喝",
          "电脑",
          "杯子"
        ],
        "answer": "喝",
        "explanation": "\"喝\" means to drink."
      },
      {
        "question": "What is the meaning of \"和\"?",
        "options": [
          "and",
          "Chinese language",
          "to eat",
          "number/day of month"
        ],
        "answer": "and",
        "explanation": "\"和\" (hé) means \"and\"."
      },
      {
        "question": "What is the pinyin for \"很\" (very)?",
        "options": [
          "hěn",
          "gōngzuò",
          "bā",
          "kàn"
        ],
        "answer": "hěn",
        "explanation": "The pinyin for \"很\" is hěn."
      },
      {
        "question": "Select the character for \"behind\":",
        "options": [
          "看",
          "分钟",
          "个",
          "后面"
        ],
        "answer": "后面",
        "explanation": "\"后面\" means behind."
      },
      {
        "question": "What is the meaning of \"回\"?",
        "options": [
          "number/day of month",
          "to return",
          "happy",
          "to love"
        ],
        "answer": "to return",
        "explanation": "\"回\" (huí) means \"to return\"."
      },
      {
        "question": "What is the pinyin for \"会\" (can/will)?",
        "options": [
          "jiǔ",
          "jiā",
          "cài",
          "huì"
        ],
        "answer": "huì",
        "explanation": "The pinyin for \"会\" is huì."
      },
      {
        "question": "Select the character for \"two\":",
        "options": [
          "会",
          "爱",
          "二",
          "八"
        ],
        "answer": "二",
        "explanation": "\"二\" means two."
      },
      {
        "question": "Grammar Check: Asking 'What' with 什么 (shénme). Which sentence is grammatically correct based on '什么 is used to ask 'what'.'?",
        "options": [
          "这是什么？",
          "我茶喝。",
          "不我好。",
          "吗你好？"
        ],
        "answer": "这是什么？",
        "explanation": "什么 is used to ask 'what'. Example: 这是什么？ (Zhè shì shénme?)"
      },
      {
        "question": "Translate this grammar example to English: 这是什么？",
        "options": [
          "What is this?",
          "Where are you?",
          "I don't know.",
          "This is a book."
        ],
        "answer": "What is this?",
        "explanation": "这是什么？ means What is this?."
      }
    ]
  },
  {
    "id": "hsk1_day30",
    "title": "Day 30: Vocabulary Range 494-500",
    "level": "HSK 1 (Beginner)",
    "duration": "60 min",
    "vocab": [
      {
        "character": "几",
        "pinyin": "jǐ",
        "meaning": "how many",
        "deconstruct": "Looks like a small table, used as a phonetic borrowing.",
        "exampleCn": "这是一个几。",
        "examplePy": "Zhè shì yí gè jǐ.",
        "exampleEn": "This is a how many."
      },
      {
        "character": "家",
        "pinyin": "jiā",
        "meaning": "family/home",
        "deconstruct": "宀 (Roof) + 豕 (Pig). A pig under a roof indicated a settled home in ancient times.",
        "exampleCn": "这是一个家。",
        "examplePy": "Zhè shì yí gè jiā.",
        "exampleEn": "This is a family/home."
      },
      {
        "character": "叫",
        "pinyin": "jiào",
        "meaning": "to be called",
        "deconstruct": "口 (Mouth) + 丩. Shouting or calling with the mouth.",
        "exampleCn": "这是一个叫。",
        "examplePy": "Zhè shì yí gè jiào.",
        "exampleEn": "This is a to be called."
      },
      {
        "character": "今天",
        "pinyin": "jīntiān",
        "meaning": "today",
        "deconstruct": "今 (Now) + 天 (Sky/Day). The current day.",
        "exampleCn": "这是一个今天。",
        "examplePy": "Zhè shì yí gè jīntiān.",
        "exampleEn": "This is a today."
      },
      {
        "character": "九",
        "pinyin": "jiǔ",
        "meaning": "nine",
        "deconstruct": "Ancient pictograph of an arm bending.",
        "exampleCn": "这是一个九。",
        "examplePy": "Zhè shì yí gè jiǔ.",
        "exampleEn": "This is a nine."
      },
      {
        "character": "开",
        "pinyin": "kāi",
        "meaning": "to open/drive",
        "deconstruct": "Two hands opening a door latch.",
        "exampleCn": "这是一个开。",
        "examplePy": "Zhè shì yí gè kāi.",
        "exampleEn": "This is a to open/drive."
      },
      {
        "character": "看",
        "pinyin": "kàn",
        "meaning": "to look/read",
        "deconstruct": "手 (Hand) shading the 目 (Eye). Looking into the distance.",
        "exampleCn": "这是一个看。",
        "examplePy": "Zhè shì yí gè kàn.",
        "exampleEn": "This is a to look/read."
      }
    ],
    "grammar": [
      {
        "title": "Grammar Point 1: Subject-Verb-Object",
        "explanation": "The basic sentence structure.",
        "examples": [
          {
            "cn": "我喝茶。",
            "py": "Wǒ hē chá.",
            "en": "I drink tea."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I drink tea.'",
          "words": [
            "茶",
            "喝",
            "我"
          ],
          "answer": [
            "我",
            "喝",
            "茶"
          ]
        }
      },
      {
        "title": "Grammar Point 2: Question Particle 吗 (ma)",
        "explanation": "Add 吗 at the end of a statement to make it a yes/no question.",
        "examples": [
          {
            "cn": "你好吗？",
            "py": "Nǐ hǎo ma?",
            "en": "Are you good?"
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'Are you good?'",
          "words": [
            "吗",
            "你",
            "好",
            "？"
          ],
          "answer": [
            "你",
            "好",
            "吗",
            "？"
          ]
        }
      },
      {
        "title": "Grammar Point 3: Negation with 不 (bù)",
        "explanation": "Place 不 before the verb to negate it.",
        "examples": [
          {
            "cn": "我不去。",
            "py": "Wǒ bú qù.",
            "en": "I am not going."
          }
        ],
        "practice": {
          "prompt": "Practice: Order the words to translate 'I am not going.'",
          "words": [
            "去",
            "不",
            "我",
            "。"
          ],
          "answer": [
            "我",
            "不",
            "去",
            "。"
          ]
        }
      }
    ],
    "dialogue": {
      "title": "Daily Conversation 30",
      "lines": [
        {
          "speaker": "A",
          "cn": "你好！这是几吗？",
          "py": "Nǐ hǎo! Zhè shì jǐ ma?",
          "en": "Hello! Is this 几?"
        },
        {
          "speaker": "B",
          "cn": "不是，这是家。",
          "py": "Bú shì, zhè shì jiā.",
          "en": "No, this is 家."
        },
        {
          "speaker": "A",
          "cn": "谢谢，你知道几在哪里吗？",
          "py": "Xièxie, nǐ zhīdào jǐ zài nǎlǐ ma?",
          "en": "Thank you, do you know where 几 is?"
        },
        {
          "speaker": "B",
          "cn": "在后面。",
          "py": "Zài hòumiàn.",
          "en": "It is behind."
        },
        {
          "speaker": "A",
          "cn": "太好了，我们一起去吧。",
          "py": "Tài hǎo le, wǒmen yìqǐ qù ba.",
          "en": "Great, let's go together."
        },
        {
          "speaker": "B",
          "cn": "好的。你喜欢家吗？",
          "py": "Hǎo de. Nǐ xǐhuān jiā ma?",
          "en": "Okay. Do you like 家?"
        },
        {
          "speaker": "A",
          "cn": "我很喜欢！",
          "py": "Wǒ hěn xǐhuān!",
          "en": "I like it very much!"
        },
        {
          "speaker": "B",
          "cn": "我也是。再见！",
          "py": "Wǒ yě shì. Zàijiàn!",
          "en": "Me too. Goodbye!"
        }
      ]
    },
    "quiz": [
      {
        "question": "What is the meaning of \"几\"?",
        "options": [
          "all/both",
          "job/work",
          "how many",
          "computer"
        ],
        "answer": "how many",
        "explanation": "\"几\" (jǐ) means \"how many\"."
      },
      {
        "question": "What is the pinyin for \"家\" (family/home)?",
        "options": [
          "duō",
          "fēnzhōng",
          "èr",
          "jiā"
        ],
        "answer": "jiā",
        "explanation": "The pinyin for \"家\" is jiā."
      },
      {
        "question": "Select the character for \"to be called\":",
        "options": [
          "都",
          "吃",
          "叫",
          "菜"
        ],
        "answer": "叫",
        "explanation": "\"叫\" means to be called."
      },
      {
        "question": "What is the meaning of \"今天\"?",
        "options": [
          "to look/read",
          "television",
          "restaurant",
          "today"
        ],
        "answer": "today",
        "explanation": "\"今天\" (jīntiān) means \"today\"."
      },
      {
        "question": "What is the pinyin for \"九\" (nine)?",
        "options": [
          "jiào",
          "jiǔ",
          "duō",
          "hòumiàn"
        ],
        "answer": "jiǔ",
        "explanation": "The pinyin for \"九\" is jiǔ."
      },
      {
        "question": "Select the character for \"to open/drive\":",
        "options": [
          "九",
          "开",
          "都",
          "今天"
        ],
        "answer": "开",
        "explanation": "\"开\" means to open/drive."
      },
      {
        "question": "What is the meaning of \"看\"?",
        "options": [
          "to look/read",
          "Beijing",
          "not",
          "movie"
        ],
        "answer": "to look/read",
        "explanation": "\"看\" (kàn) means \"to look/read\"."
      },
      {
        "question": "What is the pinyin for \"几\" (how many)?",
        "options": [
          "bàba",
          "Hànyǔ",
          "jǐ",
          "hào"
        ],
        "answer": "jǐ",
        "explanation": "The pinyin for \"几\" is jǐ."
      },
      {
        "question": "Select the character for \"family/home\":",
        "options": [
          "家",
          "北京",
          "几",
          "读"
        ],
        "answer": "家",
        "explanation": "\"家\" means family/home."
      },
      {
        "question": "What is the meaning of \"叫\"?",
        "options": [
          "family/home",
          "how much/many",
          "to be called",
          "happy"
        ],
        "answer": "to be called",
        "explanation": "\"叫\" (jiào) means \"to be called\"."
      },
      {
        "question": "What is the pinyin for \"今天\" (today)?",
        "options": [
          "hé",
          "bù",
          "jīntiān",
          "duō"
        ],
        "answer": "jīntiān",
        "explanation": "The pinyin for \"今天\" is jīntiān."
      },
      {
        "question": "Select the character for \"nine\":",
        "options": [
          "家",
          "北京",
          "分钟",
          "九"
        ],
        "answer": "九",
        "explanation": "\"九\" means nine."
      },
      {
        "question": "What is the meaning of \"开\"?",
        "options": [
          "to make a phone call",
          "son",
          "to open/drive",
          "very"
        ],
        "answer": "to open/drive",
        "explanation": "\"开\" (kāi) means \"to open/drive\"."
      },
      {
        "question": "What is the pinyin for \"看\" (to look/read)?",
        "options": [
          "diànnǎo",
          "kàn",
          "huì",
          "hǎo"
        ],
        "answer": "kàn",
        "explanation": "The pinyin for \"看\" is kàn."
      },
      {
        "question": "Select the character for \"how many\":",
        "options": [
          "吃",
          "和",
          "分钟",
          "几"
        ],
        "answer": "几",
        "explanation": "\"几\" means how many."
      },
      {
        "question": "What is the meaning of \"家\"?",
        "options": [
          "eight",
          "possessive particle",
          "sorry",
          "family/home"
        ],
        "answer": "family/home",
        "explanation": "\"家\" (jiā) means \"family/home\"."
      },
      {
        "question": "What is the pinyin for \"叫\" (to be called)?",
        "options": [
          "fàndiàn",
          "hē",
          "jiào",
          "diǎn"
        ],
        "answer": "jiào",
        "explanation": "The pinyin for \"叫\" is jiào."
      },
      {
        "question": "Select the character for \"today\":",
        "options": [
          "喝",
          "今天",
          "点",
          "多少"
        ],
        "answer": "今天",
        "explanation": "\"今天\" means today."
      },
      {
        "question": "Grammar Check: Subject-Verb-Object. Which sentence is grammatically correct based on 'The basic sentence structure.'?",
        "options": [
          "我茶喝。",
          "吗你好？",
          "我喝茶。",
          "不我好。"
        ],
        "answer": "我喝茶。",
        "explanation": "The basic sentence structure. Example: 我喝茶。 (Wǒ hē chá.)"
      },
      {
        "question": "Translate this grammar example to English: 我喝茶。",
        "options": [
          "This is a book.",
          "Where are you?",
          "I drink tea.",
          "I don't know."
        ],
        "answer": "I drink tea.",
        "explanation": "我喝茶。 means I drink tea.."
      }
    ]
  }
];