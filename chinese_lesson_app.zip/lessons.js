/**
 * Chinese Web Learning - HSK 3.0 Curriculum Database (4-Stage Format)
 * Integrates HSK 3.0 vocabulary into the structured 4-stage daily lesson plan.
 */

const CHINESE_LESSONS = {
  // Pre-test is kept for diagnostic purposes to place users in HSK 1, 2, or 3
  preTestQuestions: [
    { id: "q1", level: 1, type: "vocab", question: "Which of the following means 'Hello'?", options: ["谢谢", "你好", "再见", "对不起"], answer: "你好", explanation: "你好 (nǐ hǎo) means Hello." },
    { id: "q2", level: 2, type: "vocab", question: "Translate this word: '便宜'", options: ["Expensive", "Cheap", "Beautiful", "Delicious"], answer: "Cheap", explanation: "便宜 (piányi) means cheap." },
    { id: "q3", level: 3, type: "vocab", question: "Which describes 'getting sick'?", options: ["生病", "生气", "生命", "生意"], answer: "生病", explanation: "生病 (shēngbìng) means to fall ill." }
  ],

  lessons: {
    hsk1: [], // Placeholder, will be populated dynamically from hsk1_data.js
    hsk2: [
      {
        id: "hsk2_day1",
        title: "Day 1: Daily Activities (HSK 3.0)",
        level: "HSK 2 (Elementary)",
        duration: "60 min",
        vocab: [
          { character: "帮助", pinyin: "bāngzhù", meaning: "to help", deconstruct: "帮 (Help) + 助 (Assist).", exampleCn: "谢谢你的帮助。", examplePy: "Xièxie nǐ de bāngzhù.", exampleEn: "Thank you for your help." },
          { character: "报纸", pinyin: "bàozhǐ", meaning: "newspaper", deconstruct: "报 (Report) + 纸 (Paper).", exampleCn: "看报纸", examplePy: "Kàn bàozhǐ", exampleEn: "Read newspaper" },
          { character: "唱歌", pinyin: "chànggē", meaning: "to sing", deconstruct: "唱 (Sing) + 歌 (Song).", exampleCn: "我喜欢唱歌。", examplePy: "Wǒ xǐhuān chànggē.", exampleEn: "I like singing." },
          { character: "出", pinyin: "chū", meaning: "to go out", deconstruct: "Represents a plant growing out of the ground.", exampleCn: "出去", examplePy: "Chūqù", exampleEn: "Go out" },
          { character: "穿", pinyin: "chuān", meaning: "to wear", deconstruct: "穴 (Cave/Hole) + 牙 (Tooth/Tusk).", exampleCn: "穿衣服", examplePy: "Chuān yīfu", exampleEn: "Wear clothes" }
        ],
        grammar: [
          {
            title: "1. Expressing preferences with 喜欢 (xǐhuān)",
            explanation: "喜欢 is used to express liking something or liking to do something. Subject + 喜欢 + Noun/Verb.",
            examples: [
              { cn: "我喜欢唱歌。", py: "Wǒ xǐhuān chànggē.", en: "I like to sing." },
              { cn: "他喜欢看报纸。", py: "Tā xǐhuān kàn bàozhǐ.", en: "He likes reading the newspaper." }
            ],
            practice: {
              prompt: "Arrange the words to say 'I like to help people (人)'.",
              words: ["人", "我", "帮助", "喜欢"],
              answer: ["我", "喜欢", "帮助", "人"]
            }
          }
        ],
        dialogue: {
          title: "Hobbies and Free Time",
          lines: [
            { speaker: "A", cn: "你喜欢做什么？", py: "Nǐ xǐhuān zuò shénme?", en: "What do you like to do?" },
            { speaker: "B", cn: "我喜欢唱歌和看报纸。", py: "Wǒ xǐhuān chànggē hé kàn bàozhǐ.", en: "I like singing and reading newspapers." },
            { speaker: "A", cn: "很好！", py: "Hěn hǎo!", en: "Very good!" }
          ]
        },
        quiz: [
          { question: "What does '唱歌 (chànggē)' mean?", options: ["To dance", "To sing", "To eat", "To write"], answer: "To sing", explanation: "唱歌 means to sing a song." },
          { question: "How do you say 'newspaper'?", options: ["帮助", "穿", "出", "报纸"], answer: "报纸", explanation: "报纸 (bàozhǐ) is newspaper." },
          { question: "Fill in the blank: 我___看报纸。 (I like reading newspapers)", options: ["去", "喜欢", "出", "穿"], answer: "喜欢", explanation: "喜欢 (xǐhuān) means to like." },
          { question: "Translate 'to wear':", options: ["穿", "出", "帮", "唱"], answer: "穿", explanation: "穿 (chuān) means to wear (clothes)." }
        ]
      }
    ],
    hsk3: [
      {
        id: "hsk3_day1",
        title: "Day 1: Expressions & Emotion (HSK 3.0)",
        level: "HSK 3 (Intermediate)",
        duration: "60 min",
        vocab: [
          { character: "阿姨", pinyin: "āyí", meaning: "aunt / stepmother / maid", deconstruct: "阿 (Prefix) + 姨 (Aunt).", exampleCn: "阿姨，您好。", examplePy: "Āyí, nín hǎo.", exampleEn: "Hello, aunt." },
          { character: "啊", pinyin: "a", meaning: "ah / particle showing elation, doubt", deconstruct: "口 (Mouth) + 阿. Used for exclamation.", exampleCn: "好啊！", examplePy: "Hǎo a!", exampleEn: "Okay! / Great!" },
          { character: "矮", pinyin: "ǎi", meaning: "short (height)", deconstruct: "矢 (Arrow) + 委 (Entrust). Indicates shortness.", exampleCn: "他很矮。", examplePy: "Tā hěn ǎi.", exampleEn: "He is short." },
          { character: "安静", pinyin: "ānjìng", meaning: "quiet / peaceful", deconstruct: "安 (Safe) + 静 (Quiet).", exampleCn: "这里很安静。", examplePy: "Zhèlǐ hěn ānjìng.", exampleEn: "It is very quiet here." },
          { character: "把", pinyin: "bǎ", meaning: "to hold / particle marking object", deconstruct: "扌 (Hand) + 巴.", exampleCn: "把书给我。", examplePy: "Bǎ shū gěi wǒ.", exampleEn: "Give the book to me." }
        ],
        grammar: [
          {
            title: "1. The 把 (bǎ) Sentence Structure",
            explanation: "The 把 structure is used to focus on the result or influence of an action on an object. Subject + 把 + Object + Verb + Result/Direction.",
            examples: [
              { cn: "请把书给我。", py: "Qǐng bǎ shū gěi wǒ.", en: "Please give the book to me. (lit. Please take the book and give it to me.)" },
              { cn: "他把水喝了。", py: "Tā bǎ shuǐ hē le.", en: "He drank the water." }
            ],
            practice: {
              prompt: "Arrange the words to say 'He drank (喝了) the tea (茶)'.",
              words: ["茶", "把", "他", "喝了"],
              answer: ["他", "把", "茶", "喝了"]
            }
          }
        ],
        dialogue: {
          title: "Asking for Quiet",
          lines: [
            { speaker: "A", cn: "请安静！", py: "Qǐng ānjìng!", en: "Please be quiet!" },
            { speaker: "B", cn: "对不起，阿姨。", py: "Duìbuqǐ, āyí.", en: "Sorry, auntie." },
            { speaker: "A", cn: "把门关上。谢谢。", py: "Bǎ mén guān shàng. Xièxie.", en: "Close the door. Thank you." },
            { speaker: "B", cn: "好啊。", py: "Hǎo a.", en: "Okay." }
          ]
        },
        quiz: [
          { question: "What does '安静 (ānjìng)' mean?", options: ["Angry", "Quiet", "Short", "Beautiful"], answer: "Quiet", explanation: "安静 means quiet or peaceful." },
          { question: "Which particle is used to mark the object receiving an action?", options: ["的", "了", "啊", "把"], answer: "把", explanation: "把 (bǎ) is the object marker." },
          { question: "How do you address an older woman respectfully?", options: ["妹妹", "阿姨", "妈妈", "妈妈"], answer: "阿姨", explanation: "阿姨 (āyí) is a polite term for aunt or older woman." },
          { question: "What does '矮 (ǎi)' mean?", options: ["Tall", "Short", "Fat", "Thin"], answer: "Short", explanation: "矮 means short in height." }
        ]
      }
    ]
  }
};

// Merge dynamically generated HSK 1 Curriculum (500 words over 30 days)
if (typeof window !== 'undefined' && window.HSK1_CURRICULUM) {
  CHINESE_LESSONS.lessons.hsk1 = window.HSK1_CURRICULUM;
}
