const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const PROGRESS_FILE = path.join(__dirname, 'student_progress.json');

// Helper to send JSON response
function sendJSON(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(data));
}

// Serve static files
function serveStaticFile(res, filePath, contentType) {
  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end(`500 Internal Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
}

const MIME_TYPES = {
  '.html': 'text/html',
  '.css': 'text/css',
  '.js': 'application/javascript',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml'
};

const server = http.createServer((req, res) => {
  // Parse URL safely
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;
  
  // API endpoints
  if (pathname === '/api/progress') {
    if (req.method === 'GET') {
      fs.readFile(PROGRESS_FILE, 'utf8', (err, data) => {
        if (err) {
          if (err.code === 'ENOENT') {
            // Send empty/default progress
            return sendJSON(res, 200, {});
          }
          return sendJSON(res, 500, { error: 'Failed to read progress' });
        }
        try {
          const json = JSON.parse(data);
          sendJSON(res, 200, json);
        } catch (e) {
          sendJSON(res, 500, { error: 'Invalid progress JSON file' });
        }
      });
    } else if (req.method === 'POST') {
      let body = '';
      req.on('data', chunk => {
        body += chunk.toString();
      });
      req.on('end', () => {
        try {
          const progress = JSON.parse(body);
          fs.writeFile(PROGRESS_FILE, JSON.stringify(progress, null, 2), 'utf8', err => {
            if (err) {
              return sendJSON(res, 500, { error: 'Failed to write progress' });
            }
            sendJSON(res, 200, { success: true });
          });
        } catch (e) {
          sendJSON(res, 400, { error: 'Invalid JSON body' });
        }
      });
    } else {
      res.writeHead(405, { 'Content-Type': 'text/plain' });
      res.end('Method Not Allowed');
    }
    return;
  }
  
  // Default routing to index.html for root path
  let relativePath = pathname === '/' ? 'index.html' : pathname;
  let filePath = path.join(__dirname, relativePath);
  
  // Security check: ensure path is within directory
  if (!filePath.startsWith(__dirname)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('Forbidden');
    return;
  }
  
  const ext = path.extname(filePath);
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';
  serveStaticFile(res, filePath, contentType);
});

server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});
